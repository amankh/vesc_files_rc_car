# VESC Configurations

For older VESC versions (i.e. everything except for VESC-X), the 6.141 team recommends using the `6.141_bldc_old_hw_30k_erpm.xml` VESC config.

For the VESC-X, the 6.141 team recommends the `6.141_bldc_VESC_X_hw_30k_erpm.xml` VESC config.

The `traxxas_*` VESC config files are older VESC config versions that were used in previous versions of 6.141.