/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "mrichtextedit.h"
#include "qcustomplot.h"
#include "rtdatawidget.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_6;
    QTabWidget *tabWidget;
    QWidget *tab_11;
    QVBoxLayout *verticalLayout_31;
    QTabWidget *tabWidget_4;
    QWidget *tab_12;
    QVBoxLayout *verticalLayout_24;
    QGroupBox *groupBox_29;
    QHBoxLayout *horizontalLayout_34;
    QRadioButton *mcconfTypeBldcButton;
    QRadioButton *mcconfTypeDcButton;
    QRadioButton *mcconfTypeFocButton;
    QSpacerItem *horizontalSpacer_15;
    QGridLayout *gridLayout_24;
    QGroupBox *groupBox_8;
    QHBoxLayout *horizontalLayout_18;
    QGridLayout *gridLayout_9;
    QLabel *label_19;
    QLabel *label_20;
    QDoubleSpinBox *mcconfLimCurrentInMinBox;
    QLabel *label_18;
    QLabel *label_17;
    QDoubleSpinBox *mcconfLimCurrentAbsMaxBox;
    QDoubleSpinBox *mcconfLimCurrentMinBox;
    QDoubleSpinBox *mcconfLimCurrentInMaxBox;
    QLabel *label_16;
    QDoubleSpinBox *mcconfLimCurrentMaxBox;
    QCheckBox *mcconfLimCurrentSlowAbsMaxBox;
    QGroupBox *groupBox_9;
    QHBoxLayout *horizontalLayout_19;
    QGridLayout *gridLayout_10;
    QLabel *label_21;
    QDoubleSpinBox *mcconfLimMaxErpmBox;
    QDoubleSpinBox *mcconfLimMaxErpmFbrakeBox;
    QDoubleSpinBox *mcconfLimMinErpmBox;
    QLabel *label_22;
    QLabel *label_23;
    QCheckBox *mcconfLimErpmLimitNegTorqueBox;
    QSpacerItem *verticalSpacer_11;
    QLabel *label_62;
    QDoubleSpinBox *mcconfLimMaxErpmFbrakeCcBox;
    QGroupBox *groupBox_27;
    QGridLayout *gridLayout_23;
    QLabel *label_57;
    QDoubleSpinBox *mcconfLimTempFetStartBox;
    QLabel *label_58;
    QDoubleSpinBox *mcconfLimTempFetEndBox;
    QLabel *label_59;
    QDoubleSpinBox *mcconfLimTempMotorStartBox;
    QLabel *label_60;
    QDoubleSpinBox *mcconfLimTempMotorEndBox;
    QGroupBox *groupBox_10;
    QHBoxLayout *horizontalLayout_20;
    QGridLayout *gridLayout_11;
    QLabel *label_86;
    QLabel *label_25;
    QLabel *label_24;
    QDoubleSpinBox *mcconfLimMinVinBox;
    QDoubleSpinBox *mcconfLimMaxVinBox;
    QLabel *label_87;
    QDoubleSpinBox *mcconfLimBatteryCutStartBox;
    QDoubleSpinBox *mcconfLimBatteryCutEndBox;
    QGroupBox *groupBox_38;
    QGridLayout *gridLayout_36;
    QLabel *label_83;
    QLabel *label_84;
    QDoubleSpinBox *mcconfLimMaxDutyBox;
    QDoubleSpinBox *mcconfLimMinDutyBox;
    QSpacerItem *verticalSpacer_4;
    QWidget *tab_13;
    QVBoxLayout *verticalLayout_23;
    QGroupBox *groupBox_34;
    QHBoxLayout *horizontalLayout_43;
    QRadioButton *mcconfSensorModeSensorlessButton;
    QRadioButton *mcconfSensorModeSensoredButton;
    QRadioButton *mcconfSensorModeHybridButton;
    QSpacerItem *horizontalSpacer_20;
    QHBoxLayout *horizontalLayout_21;
    QGroupBox *mcconfSlBox;
    QGridLayout *gridLayout_12;
    QLabel *label_26;
    QDoubleSpinBox *mcconfSlMinErpmBox;
    QLabel *label_30;
    QDoubleSpinBox *mcconfSlBrErpmBox;
    QLabel *label_29;
    QDoubleSpinBox *mcconfSlIntLimScaleBrBox;
    QLabel *label_61;
    QDoubleSpinBox *mcconfSlMaxFbCurrBox;
    QGroupBox *groupBox_16;
    QGridLayout *gridLayout_46;
    QLabel *label_100;
    QRadioButton *mcconfCommIntButton;
    QRadioButton *mcconfCommDelayButton;
    QLabel *label_28;
    QDoubleSpinBox *mcconfSlIntLimBox;
    QLabel *label_27;
    QDoubleSpinBox *mcconfSlMinErpmIlBox;
    QLabel *label_41;
    QDoubleSpinBox *mcconfSlBemfKBox;
    QGroupBox *groupBox_12;
    QVBoxLayout *verticalLayout_20;
    QHBoxLayout *horizontalLayout_22;
    QLabel *label_31;
    QSpinBox *mcconfHallTab0Box;
    QSpinBox *mcconfHallTab1Box;
    QSpinBox *mcconfHallTab2Box;
    QSpinBox *mcconfHallTab3Box;
    QSpinBox *mcconfHallTab4Box;
    QSpinBox *mcconfHallTab5Box;
    QSpinBox *mcconfHallTab6Box;
    QSpinBox *mcconfHallTab7Box;
    QLabel *label_32;
    QDoubleSpinBox *mcconfHallSlErpmBox;
    QSpacerItem *horizontalSpacer_8;
    QSpacerItem *verticalSpacer_7;
    QGroupBox *groupBox_11;
    QHBoxLayout *horizontalLayout_24;
    QGridLayout *gridLayout_47;
    QPushButton *mcconfDetectMotorParamButton;
    QSpacerItem *verticalSpacer_5;
    QPushButton *mcconfDetectApplyButton;
    QGridLayout *gridLayout_7;
    QDoubleSpinBox *mcconfDetectCurrentBox;
    QLabel *label_44;
    QDoubleSpinBox *mcconfDetectErpmBox;
    QLabel *label_42;
    QDoubleSpinBox *mcconfDetectLowDutyBox;
    QLabel *label_43;
    QTextBrowser *mcconfDetectResultBrowser;
    QWidget *tab_24;
    QVBoxLayout *verticalLayout_29;
    QGridLayout *gridLayout_42;
    QGroupBox *groupBox_39;
    QGridLayout *gridLayout_39;
    QDoubleSpinBox *mcconfFocEncoderRatioBox;
    QLabel *label_89;
    QDoubleSpinBox *mcconfFocCurrKpBox;
    QDoubleSpinBox *mcconfFocCurrKiBox;
    QLabel *label_92;
    QDoubleSpinBox *mcconfFocEncoderOffsetBox;
    QLabel *label_101;
    QCheckBox *mcconfFocEncoderInvertedBox;
    QHBoxLayout *horizontalLayout_26;
    QRadioButton *mcconfFocModeEncoderButton;
    QRadioButton *mcconfFocModeHallButton;
    QRadioButton *mcconfFocModeSensorlessButton;
    QDoubleSpinBox *mcconfFocSlErpmBox;
    QLabel *label_96;
    QGroupBox *groupBox_41;
    QGridLayout *gridLayout_40;
    QLabel *label_104;
    QDoubleSpinBox *mcconfFocPllKpBox;
    QDoubleSpinBox *mcconfFocDutyDownrampKiBox;
    QLabel *label_103;
    QDoubleSpinBox *mcconfFocPllKiBox;
    QLabel *label_90;
    QDoubleSpinBox *mcconfFocOpenloopRpmBox;
    QDoubleSpinBox *mcconfFocDutyDownrampKpBox;
    QSpinBox *mcconfFocFSwBox;
    QLabel *label_94;
    QDoubleSpinBox *mcconfFocDtCompBox;
    QGroupBox *groupBox_40;
    QGridLayout *gridLayout_41;
    QDoubleSpinBox *mcconfFocObserverGainBox;
    QLabel *label_98;
    QPushButton *mcconfFocObserverGainCalcButton;
    QDoubleSpinBox *mcconfFocMotorRBox;
    QDoubleSpinBox *mcconfFocMotorLBox;
    QDoubleSpinBox *mcconfFocMotorLinkageBox;
    QGroupBox *groupBox_43;
    QGridLayout *gridLayout_44;
    QDoubleSpinBox *mcconfFocDCurrentFactorBox;
    QDoubleSpinBox *mcconfFocSlOpenloopHystBox;
    QLabel *label_105;
    QLabel *label_107;
    QDoubleSpinBox *mcconfFocDCurrentDutyBox;
    QDoubleSpinBox *mcconfFocSlOpenloopTimeBox;
    QGroupBox *groupBox_46;
    QHBoxLayout *horizontalLayout_45;
    QLabel *label_95;
    QSpinBox *mcconfFocHallTab0Box;
    QSpinBox *mcconfFocHallTab1Box;
    QSpinBox *mcconfFocHallTab2Box;
    QSpinBox *mcconfFocHallTab3Box;
    QSpinBox *mcconfFocHallTab4Box;
    QSpinBox *mcconfFocHallTab5Box;
    QSpinBox *mcconfFocHallTab6Box;
    QSpinBox *mcconfFocHallTab7Box;
    QSpacerItem *horizontalSpacer_23;
    QSpacerItem *verticalSpacer_17;
    QGroupBox *groupBox_44;
    QGridLayout *gridLayout_45;
    QSpacerItem *horizontalSpacer_29;
    QDoubleSpinBox *mcconfFocCalcCCTcBox;
    QPushButton *mcconfFocMeasureLinkageButton;
    QPushButton *mcconfFocMeasureRLButton;
    QDoubleSpinBox *mcconfFocDetectRBox;
    QDoubleSpinBox *mcconfFocDetectLBox;
    QPushButton *mcconfFocApplyRLLambdaButton;
    QPushButton *mcconfFocCalcCCButton;
    QPushButton *mcconfFocCalcCCApplyButton;
    QDoubleSpinBox *mcconfFocDetectLinkageBox;
    QDoubleSpinBox *mcconfFocCalcKiBox;
    QDoubleSpinBox *mcconfFocCalcKpBox;
    QDoubleSpinBox *mcconfFocDetectCurrentBox;
    QDoubleSpinBox *mcconfFocDetectDutyBox;
    QDoubleSpinBox *mcconfFocDetectMinRpmBox;
    QLabel *label_93;
    QGroupBox *groupBox_42;
    QHBoxLayout *horizontalLayout_25;
    QPushButton *mcconfFocMeasureEncoderButton;
    QDoubleSpinBox *mcconfFocMeasureEncoderCurrentBox;
    QSpacerItem *horizontalSpacer_26;
    QDoubleSpinBox *mcconfFocMeasureEncoderOffsetBox;
    QDoubleSpinBox *mcconfFocMeasureEncoderRatioBox;
    QCheckBox *mcconfFocMeasureEncoderInvertedBox;
    QSpacerItem *horizontalSpacer_27;
    QPushButton *mcconfFocMeasureEncoderApplyButton;
    QGroupBox *groupBox_45;
    QHBoxLayout *horizontalLayout_38;
    QPushButton *mcconfFocMeasureHallButton;
    QDoubleSpinBox *mcconfFocMeasureHallCurrentBox;
    QSpacerItem *horizontalSpacer_25;
    QSpinBox *mcconfFocMeasureHallTab0Box;
    QSpinBox *mcconfFocMeasureHallTab1Box;
    QSpinBox *mcconfFocMeasureHallTab2Box;
    QSpinBox *mcconfFocMeasureHallTab3Box;
    QSpinBox *mcconfFocMeasureHallTab4Box;
    QSpinBox *mcconfFocMeasureHallTab5Box;
    QSpinBox *mcconfFocMeasureHallTab6Box;
    QSpinBox *mcconfFocMeasureHallTab7Box;
    QSpacerItem *horizontalSpacer_24;
    QPushButton *mcconfFocMeasureHallApplyButton;
    QWidget *tab_14;
    QVBoxLayout *verticalLayout_27;
    QGroupBox *groupBox_13;
    QHBoxLayout *horizontalLayout_44;
    QRadioButton *mcconfPwmModeSyncButton;
    QRadioButton *mcconfPwmModeBipolarButton;
    QRadioButton *mcconfPwmModeNonsyncHiswButton;
    QSpacerItem *horizontalSpacer_21;
    QHBoxLayout *horizontalLayout_23;
    QGroupBox *groupBox_14;
    QGridLayout *gridLayout_14;
    QLabel *label_34;
    QDoubleSpinBox *mcconfCcBoostBox;
    QLabel *label_35;
    QDoubleSpinBox *mcconfCcMinBox;
    QLabel *label_36;
    QDoubleSpinBox *mcconfCcGainBox;
    QSpacerItem *verticalSpacer_16;
    QGroupBox *groupBox_37;
    QGridLayout *gridLayout_37;
    QLabel *label_3;
    QDoubleSpinBox *mcconfMDutyRampStepBox;
    QLabel *label_69;
    QDoubleSpinBox *mcconfCcMaxRampStepBox;
    QLabel *label_85;
    QDoubleSpinBox *mcconfMCurrentBackoffGainBox;
    QLabel *label_33;
    QDoubleSpinBox *mcconfMDutyRampStepSpeedLimBox;
    QHBoxLayout *horizontalLayout_39;
    QGroupBox *groupBox_15;
    QGridLayout *gridLayout_15;
    QLabel *label_37;
    QDoubleSpinBox *mcconfSpidKpBox;
    QLabel *label_38;
    QDoubleSpinBox *mcconfSpidKiBox;
    QLabel *label_39;
    QDoubleSpinBox *mcconfSpidKdBox;
    QLabel *label_40;
    QDoubleSpinBox *mcconfSpidMinRpmBox;
    QGroupBox *groupBox_30;
    QGridLayout *gridLayout_26;
    QLabel *label_68;
    QDoubleSpinBox *mcconfPpidKiBox;
    QLabel *label_70;
    QDoubleSpinBox *mcconfPpidKdBox;
    QLabel *label_71;
    QDoubleSpinBox *mcconfPpidKpBox;
    QLabel *label_11;
    QDoubleSpinBox *mcconfPpidAngDivBox;
    QHBoxLayout *horizontalLayout_53;
    QGroupBox *groupBox_17;
    QGridLayout *gridLayout_38;
    QLabel *label_4;
    QSpinBox *mcconfMEncoderCountBox;
    QSpinBox *mcconfMFaultStopTimeBox;
    QLabel *label_91;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_43;
    QRadioButton *mcconfMSensorHallButton;
    QRadioButton *mcconfMSensorAsSpiButton;
    QRadioButton *mcconfMSensorAbiButton;
    QSpacerItem *horizontalSpacer_22;
    QSpacerItem *verticalSpacer_8;
    QWidget *tab_4;
    QVBoxLayout *verticalLayout_25;
    MRichTextEdit *mcconfDescEdit;
    QHBoxLayout *horizontalLayout_17;
    QPushButton *mcconfReadButton;
    QPushButton *mcconfReadDefaultButton;
    QPushButton *mcconfWriteButton;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *mcconfLoadXmlButton;
    QPushButton *mcconfSaveXmlButton;
    QWidget *tab_5;
    QVBoxLayout *verticalLayout_33;
    QTabWidget *tabWidget_3;
    QWidget *tab_16;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_5;
    QGroupBox *groupBox_28;
    QGridLayout *gridLayout_29;
    QLabel *label_65;
    QSpinBox *appconfControllerIdBox;
    QGroupBox *appconfSendCanStatusBox;
    QGridLayout *gridLayout_25;
    QLabel *label_12;
    QSpinBox *appconfSendCanStatusRateBox;
    QGroupBox *groupBox_18;
    QHBoxLayout *horizontalLayout_33;
    QGridLayout *gridLayout_22;
    QRadioButton *appconfUseUartButton;
    QRadioButton *appconfUsePpmUartButton;
    QRadioButton *appconfUseCustomButton;
    QRadioButton *appconfUseNoAppButton;
    QRadioButton *appconfUseNrfButton;
    QRadioButton *appconfUseNunchukButton;
    QRadioButton *appconfUsePpmButton;
    QRadioButton *appconfUseAdcButton;
    QRadioButton *appconfUseAdcUartButton;
    QSpacerItem *horizontalSpacer_12;
    QGroupBox *groupBox_22;
    QGridLayout *gridLayout_18;
    QLabel *label_52;
    QSpinBox *appconfTimeoutBox;
    QLabel *label_53;
    QDoubleSpinBox *appconfTimeoutBrakeCurrentBox;
    QSpacerItem *verticalSpacer_3;
    QWidget *tab_17;
    QVBoxLayout *verticalLayout_35;
    QGroupBox *groupBox_19;
    QHBoxLayout *horizontalLayout_28;
    QGridLayout *gridLayout_13;
    QRadioButton *appconfPpmDutyNorevButton;
    QRadioButton *appconfPpmDutyButton;
    QRadioButton *appconfPpmDisabledButton;
    QRadioButton *appconfPpmPidNorevButton;
    QRadioButton *appconfPpmCurrentNorevBrakeButton;
    QRadioButton *appconfPpmCurrentButton;
    QRadioButton *appconfPpmCurrentNorevButton;
    QRadioButton *appconfPpmPidButton;
    QSpacerItem *horizontalSpacer_10;
    QGroupBox *groupBox_20;
    QGridLayout *gridLayout_17;
    QCheckBox *appconfPpmMedianFilterBox;
    QLabel *label_51;
    QDoubleSpinBox *appconfPpmPidMaxErpmBox;
    QLabel *label_49;
    QDoubleSpinBox *appconfPpmPulseStartBox;
    QLabel *label_50;
    QDoubleSpinBox *appconfPpmPulseWidthBox;
    QLabel *label_45;
    QDoubleSpinBox *appconfPpmHystBox;
    QCheckBox *appconfPpmSafeStartBox;
    QGroupBox *appconfPpmRpmLimBox;
    QGridLayout *gridLayout_20;
    QDoubleSpinBox *appconfPpmRpmLimStartBox;
    QLabel *label_47;
    QLabel *label_48;
    QDoubleSpinBox *appconfPpmRpmLimEndBox;
    QGroupBox *appconfPpmMultiGroup;
    QHBoxLayout *horizontalLayout_37;
    QCheckBox *appconfPpmTcBox;
    QSpacerItem *horizontalSpacer_14;
    QLabel *label_67;
    QDoubleSpinBox *appconfPpmTcErpmBox;
    QGroupBox *appconfUpdatePpmBox;
    QGridLayout *gridLayout_19;
    QProgressBar *appconfDecodedPpmBar;
    QLCDNumber *appconfPpmPulsewidthNumber;
    QLabel *label_80;
    QSpacerItem *verticalSpacer_6;
    QWidget *tab_22;
    QVBoxLayout *verticalLayout_16;
    QGroupBox *groupBox_31;
    QHBoxLayout *horizontalLayout_40;
    QGridLayout *gridLayout_30;
    QRadioButton *appconfAdcCurrentButtonButton;
    QRadioButton *appconfAdcDisabledButton;
    QRadioButton *appconfAdcCurrentNorevCenterButton;
    QRadioButton *appconfAdcCurrentNorevButtonButton;
    QRadioButton *appconfAdcCurrentButton;
    QRadioButton *appconfAdcCurrentCenterButton;
    QRadioButton *appconfAdcDutyCycleButtonButton;
    QRadioButton *appconfAdcDutyCycleCenterButton;
    QRadioButton *appconfAdcDutyCycleButton;
    QRadioButton *appconfAdcCurrentNorevAdcButton;
    QSpacerItem *horizontalSpacer_16;
    QGroupBox *groupBox_33;
    QGridLayout *gridLayout_33;
    QSpinBox *appconfAdcUpdateRateBox;
    QDoubleSpinBox *appconfAdcHystBox;
    QLabel *label_78;
    QCheckBox *appconfAdcFilterBox;
    QLabel *label_76;
    QCheckBox *appconfAdcSafeStartBox;
    QWidget *widget;
    QSpacerItem *horizontalSpacer_18;
    QDoubleSpinBox *appconfAdcVoltageStartBox;
    QLabel *label_77;
    QLabel *label_75;
    QDoubleSpinBox *appconfAdcVoltageEndBox;
    QCheckBox *appconfAdcInvertVoltageBox;
    QGroupBox *groupBox_36;
    QGridLayout *gridLayout_35;
    QCheckBox *appconfAdcInvertRevButtonBox;
    QCheckBox *appconfAdcInvertCcButtonBox;
    QSpacerItem *verticalSpacer_12;
    QTextBrowser *textBrowser_2;
    QGroupBox *appconfAdcRpmLimBox;
    QGridLayout *gridLayout_32;
    QDoubleSpinBox *appconfAdcRpmLimStartBox;
    QLabel *label_73;
    QDoubleSpinBox *appconfAdcRpmLimEndBox;
    QLabel *label_74;
    QSpacerItem *horizontalSpacer_28;
    QGroupBox *appconfAdcMultiGroup;
    QHBoxLayout *horizontalLayout_41;
    QCheckBox *appconfAdcTcBox;
    QSpacerItem *horizontalSpacer_17;
    QLabel *label_72;
    QDoubleSpinBox *appconfAdcTcErpmBox;
    QGroupBox *appconfAdcUpdateBox;
    QGridLayout *gridLayout_31;
    QProgressBar *appconfAdcDecodedBar;
    QLCDNumber *appconfAdcVoltageNumber;
    QLabel *label_79;
    QProgressBar *appconfAdcDecodedBar2;
    QLabel *lblVoltage2;
    QLCDNumber *appconfAdcVoltageNumber2;
    QSpacerItem *verticalSpacer_14;
    QWidget *tab_18;
    QVBoxLayout *verticalLayout_36;
    QGroupBox *groupBox_21;
    QGridLayout *gridLayout_16;
    QLabel *label_46;
    QSpinBox *appconfUartBaudBox;
    QSpacerItem *verticalSpacer_10;
    QWidget *tab_21;
    QVBoxLayout *verticalLayout_32;
    QGroupBox *groupBox_24;
    QHBoxLayout *horizontalLayout_31;
    QHBoxLayout *horizontalLayout_35;
    QRadioButton *appconfChukDisabledButton;
    QRadioButton *appconfChukCurrentNorevButton;
    QRadioButton *appconfChukCurrentButton;
    QSpacerItem *horizontalSpacer_11;
    QGroupBox *groupBox_25;
    QGridLayout *gridLayout_21;
    QLabel *label_54;
    QDoubleSpinBox *appconfChukHystBox;
    QLabel *label_63;
    QDoubleSpinBox *appconfChukRampTimePosBox;
    QLabel *label_56;
    QDoubleSpinBox *appconfChukRpmLimStartBox;
    QLabel *label_64;
    QDoubleSpinBox *appconfChukRampTimeNegBox;
    QLabel *label_55;
    QDoubleSpinBox *appconfChukRpmLimEndBox;
    QLabel *label_88;
    QDoubleSpinBox *appconfChukErpmPerSBox;
    QGroupBox *appconfChukMultiGroup;
    QHBoxLayout *horizontalLayout_36;
    QCheckBox *appconfChukTcBox;
    QSpacerItem *horizontalSpacer_13;
    QLabel *label_66;
    QDoubleSpinBox *appconfChukTcErpmBox;
    QGroupBox *appconfUpdateChukBox;
    QHBoxLayout *horizontalLayout_32;
    QProgressBar *appconfDecodedChukBar;
    QTextBrowser *textBrowser;
    QWidget *tab_25;
    QVBoxLayout *verticalLayout_37;
    QGroupBox *groupBox_47;
    QHBoxLayout *horizontalLayout_46;
    QRadioButton *appconfNrfSpeed250kButton;
    QRadioButton *appconfNrfSpeed1mButton;
    QRadioButton *appconfNrfSpeed2mButton;
    QSpacerItem *horizontalSpacer_33;
    QGroupBox *groupBox_48;
    QHBoxLayout *horizontalLayout_47;
    QRadioButton *appconfNrfPowerM18Button;
    QRadioButton *appconfNrfPowerM12Button;
    QRadioButton *appconfNrfPowerM6Button;
    QRadioButton *appconfNrfPower0Button;
    QSpacerItem *horizontalSpacer_31;
    QGroupBox *groupBox_50;
    QHBoxLayout *horizontalLayout_49;
    QRadioButton *appconfNrfCrc1BButton;
    QRadioButton *appconfNrfCrc2BButton;
    QSpacerItem *horizontalSpacer_32;
    QGroupBox *groupBox_49;
    QHBoxLayout *horizontalLayout_48;
    QCheckBox *appconfNrfUseAckBox;
    QLabel *label_97;
    QSpinBox *appconfNrfRetrBox;
    QLabel *label_99;
    QComboBox *appconfNrfRetrDelayBox;
    QSpacerItem *horizontalSpacer_30;
    QGroupBox *groupBox_51;
    QHBoxLayout *horizontalLayout_50;
    QSpinBox *appconfNrfChannelBox;
    QSpacerItem *horizontalSpacer_34;
    QGroupBox *groupBox_52;
    QHBoxLayout *horizontalLayout_51;
    QSpinBox *appconfNrfAddrB0Box;
    QSpinBox *appconfNrfAddrB1Box;
    QSpinBox *appconfNrfAddrB2Box;
    QSpacerItem *horizontalSpacer_35;
    QSpacerItem *verticalSpacer_18;
    QHBoxLayout *horizontalLayout_27;
    QPushButton *appconfReadButton;
    QPushButton *appconfReadDefaultButton;
    QPushButton *appconfWriteButton;
    QSpacerItem *horizontalSpacer_9;
    QWidget *tab_6;
    QVBoxLayout *verticalLayout_17;
    QTabWidget *tabWidget_5;
    QWidget *tab_19;
    QHBoxLayout *horizontalLayout_29;
    QCustomPlot *realtimePlotRest;
    QWidget *tab_20;
    QHBoxLayout *horizontalLayout_30;
    QCustomPlot *realtimePlotTemperature;
    QWidget *tab_28;
    QHBoxLayout *horizontalLayout_52;
    QCustomPlot *realtimePlotRpm;
    RtDataWidget *rtDataWidget;
    QHBoxLayout *horizontalLayout_16;
    QCheckBox *realtimeAutoScaleBox;
    QCheckBox *realtimeActivateBox;
    QSpacerItem *horizontalSpacer_7;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout_10;
    QCustomPlot *voltagePlot;
    QHBoxLayout *horizontalLayout_4;
    QCheckBox *showPh1Box;
    QCheckBox *showPh2Box;
    QCheckBox *showPh3Box;
    QCheckBox *showVirtualGndBox;
    QCheckBox *showPosVoltageBox;
    QSpacerItem *horizontalSpacer_2;
    QCheckBox *truncateBox;
    QWidget *tab;
    QVBoxLayout *verticalLayout_19;
    QTabWidget *tabWidget_2;
    QWidget *tab_7;
    QVBoxLayout *verticalLayout_8;
    QCustomPlot *currentPlot;
    QHBoxLayout *horizontalLayout_14;
    QCheckBox *showCurrent1Box;
    QCheckBox *showCurrent2Box;
    QCheckBox *showCurrent3Box;
    QCheckBox *showTotalCurrentBox;
    QCheckBox *showMcTotalCurrentBox;
    QCheckBox *showPosCurrentBox;
    QSpacerItem *horizontalSpacer_3;
    QRadioButton *currentTimeButton;
    QRadioButton *currentSpectrumButton;
    QWidget *tab_8;
    QVBoxLayout *verticalLayout_12;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_7;
    QCustomPlot *filterResponsePlot;
    QCheckBox *filterLogScaleBox;
    QWidget *layoutWidget_12;
    QVBoxLayout *verticalLayout_9;
    QCustomPlot *filterPlot;
    QCheckBox *filterScatterBox;
    QWidget *tab_9;
    QVBoxLayout *verticalLayout_15;
    QSplitter *splitter_2;
    QWidget *layoutWidget_10;
    QVBoxLayout *verticalLayout_13;
    QCustomPlot *filterResponsePlot2;
    QCheckBox *filterLogScaleBox2;
    QWidget *layoutWidget2_2;
    QVBoxLayout *verticalLayout_14;
    QCustomPlot *filterPlot2;
    QCheckBox *filterScatterBox2;
    QHBoxLayout *horizontalLayout_3;
    QGroupBox *groupBox_4;
    QGridLayout *gridLayout_4;
    QCheckBox *currentFilterActiveBox;
    QHBoxLayout *horizontalLayout_6;
    QRadioButton *firRadioButton;
    QRadioButton *meanRadioButton;
    QCheckBox *compDelayBox;
    QGridLayout *gridLayout_3;
    QLabel *label_6;
    QDoubleSpinBox *currentFilterFreqBox;
    QLabel *label_7;
    QSpinBox *currentFilterTapBox;
    QCheckBox *hammingBox;
    QGroupBox *groupBox_7;
    QGridLayout *gridLayout_5;
    QCheckBox *currentFilterActiveBox2;
    QHBoxLayout *horizontalLayout_11;
    QRadioButton *firRadioButton2;
    QRadioButton *meanRadioButton2;
    QGridLayout *gridLayout_6;
    QLabel *label_8;
    QDoubleSpinBox *currentFilterFreqBox2;
    QLabel *label_9;
    QSpinBox *currentFilterTapBox2;
    QCheckBox *hammingBox2;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_10;
    QSpinBox *decimationSpinBox;
    QHBoxLayout *horizontalLayout_10;
    QSpacerItem *horizontalSpacer;
    QWidget *tab_15;
    QVBoxLayout *verticalLayout_21;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout_4;
    QTextBrowser *terminalBrowser;
    QHBoxLayout *horizontalLayout_15;
    QLineEdit *terminalEdit;
    QPushButton *sendTerminalButton;
    QPushButton *clearTerminalButton;
    QWidget *tab_23;
    QVBoxLayout *verticalLayout_18;
    QGroupBox *groupBox_23;
    QGridLayout *gridLayout_34;
    QLabel *label_81;
    QPushButton *firmwareUploadButton;
    QLabel *firmwareUploadStatusLabel;
    QProgressBar *firmwareBar;
    QLineEdit *firmwareEdit;
    QPushButton *firmwareCancelButton;
    QPushButton *firmwareChooseButton;
    QGroupBox *groupBox_26;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_82;
    QLabel *firmwareVersionLabel;
    QSpacerItem *horizontalSpacer_19;
    QPushButton *firmwareVersionReadButton;
    QGroupBox *groupBox_32;
    QHBoxLayout *horizontalLayout_42;
    QLabel *firmwareSupportedLabel;
    QSpacerItem *verticalSpacer_15;
    QWidget *tab_3;
    QVBoxLayout *verticalLayout_5;
    QGridLayout *gridLayout_8;
    QPushButton *detectButton;
    QPushButton *stopDetectButton;
    QPushButton *detectPidPosErrorButton;
    QPushButton *detectEncoderButton;
    QPushButton *detectObserverButton;
    QPushButton *detectEncoderObserverErrorButton;
    QSpacerItem *horizontalSpacer_36;
    QPushButton *detectPidPosButton;
    QProgressBar *rotorPosBar;
    QCustomPlot *realtimePlotPosition;
    QWidget *tab_10;
    QVBoxLayout *verticalLayout_22;
    QHBoxLayout *horizontalLayout_7;
    QLabel *experimentSampleLabel;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *experimentClearSamplesButton;
    QPushButton *experimentSaveSamplesButton;
    QTextBrowser *experimentBrowser;
    QGroupBox *groupBox_6;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_13;
    QLabel *label_14;
    QLineEdit *experimentPathEdit;
    QHBoxLayout *horizontalLayout_8;
    QCheckBox *experimentAutosaveBox;
    QSpacerItem *horizontalSpacer_5;
    QLabel *label_13;
    QSpinBox *experimentAutosaveIntervalBox;
    QLabel *label_15;
    QGroupBox *groupBox_35;
    QHBoxLayout *horizontalLayout_2;
    QSlider *servoOutputSlider;
    QLCDNumber *servoOutputNumber;
    QWidget *widget2;
    QVBoxLayout *verticalLayout_26;
    QToolBox *toolBox;
    QWidget *page;
    QGridLayout *gridLayout_49;
    QComboBox *serialCombobox;
    QPushButton *refreshButton;
    QPushButton *serialConnectButton;
    QWidget *page_2;
    QGridLayout *gridLayout_50;
    QLineEdit *udpIpEdit;
    QPushButton *udpConnectButton;
    QGridLayout *gridLayout_28;
    QPushButton *disconnectButton;
    QPushButton *appconfRebootButton;
    QSpinBox *canIdBox;
    QCheckBox *canFwdBox;
    QSpacerItem *verticalSpacer;
    QTabWidget *tabWidget_6;
    QWidget *tab_26;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_2;
    QDoubleSpinBox *dutyBox;
    QPushButton *dutyButton;
    QSpinBox *rpmBox;
    QPushButton *rpmButton;
    QDoubleSpinBox *currentBox;
    QPushButton *currentButton;
    QPushButton *currentBrakeButton;
    QPushButton *posCtrlButton;
    QDoubleSpinBox *currentBrakeBox;
    QDoubleSpinBox *posCtrlBox;
    QCheckBox *overrideKbBox;
    QDoubleSpinBox *arrowCurrentBox;
    QPushButton *offBrakeButton;
    QWidget *tab_27;
    QVBoxLayout *verticalLayout_38;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout;
    QLabel *label;
    QLabel *label_2;
    QSpinBox *sampleNumBox;
    QSpinBox *sampleFreqBox;
    QSpinBox *sampleIntBox;
    QLabel *label_5;
    QPushButton *getDataButton;
    QPushButton *getDataStartButton;
    QGroupBox *groupBox_5;
    QGridLayout *gridLayout_27;
    QCheckBox *horizontalZoomBox;
    QCheckBox *verticalZoomBox;
    QPushButton *rescaleButton;
    QPushButton *replotButton;
    QSpacerItem *verticalSpacer_19;
    QPushButton *offButton;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1340, 795);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        horizontalLayout = new QHBoxLayout(centralWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(1);
        sizePolicy1.setHeightForWidth(tabWidget->sizePolicy().hasHeightForWidth());
        tabWidget->setSizePolicy(sizePolicy1);
        tabWidget->setTabPosition(QTabWidget::North);
        tab_11 = new QWidget();
        tab_11->setObjectName(QStringLiteral("tab_11"));
        verticalLayout_31 = new QVBoxLayout(tab_11);
        verticalLayout_31->setSpacing(6);
        verticalLayout_31->setContentsMargins(11, 11, 11, 11);
        verticalLayout_31->setObjectName(QStringLiteral("verticalLayout_31"));
        tabWidget_4 = new QTabWidget(tab_11);
        tabWidget_4->setObjectName(QStringLiteral("tabWidget_4"));
        tabWidget_4->setTabPosition(QTabWidget::West);
        tab_12 = new QWidget();
        tab_12->setObjectName(QStringLiteral("tab_12"));
        verticalLayout_24 = new QVBoxLayout(tab_12);
        verticalLayout_24->setSpacing(6);
        verticalLayout_24->setContentsMargins(11, 11, 11, 11);
        verticalLayout_24->setObjectName(QStringLiteral("verticalLayout_24"));
        groupBox_29 = new QGroupBox(tab_12);
        groupBox_29->setObjectName(QStringLiteral("groupBox_29"));
        horizontalLayout_34 = new QHBoxLayout(groupBox_29);
        horizontalLayout_34->setSpacing(6);
        horizontalLayout_34->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_34->setObjectName(QStringLiteral("horizontalLayout_34"));
        mcconfTypeBldcButton = new QRadioButton(groupBox_29);
        mcconfTypeBldcButton->setObjectName(QStringLiteral("mcconfTypeBldcButton"));
        mcconfTypeBldcButton->setChecked(true);

        horizontalLayout_34->addWidget(mcconfTypeBldcButton);

        mcconfTypeDcButton = new QRadioButton(groupBox_29);
        mcconfTypeDcButton->setObjectName(QStringLiteral("mcconfTypeDcButton"));

        horizontalLayout_34->addWidget(mcconfTypeDcButton);

        mcconfTypeFocButton = new QRadioButton(groupBox_29);
        mcconfTypeFocButton->setObjectName(QStringLiteral("mcconfTypeFocButton"));

        horizontalLayout_34->addWidget(mcconfTypeFocButton);

        horizontalSpacer_15 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_34->addItem(horizontalSpacer_15);


        verticalLayout_24->addWidget(groupBox_29);

        gridLayout_24 = new QGridLayout();
        gridLayout_24->setSpacing(6);
        gridLayout_24->setObjectName(QStringLiteral("gridLayout_24"));
        groupBox_8 = new QGroupBox(tab_12);
        groupBox_8->setObjectName(QStringLiteral("groupBox_8"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(groupBox_8->sizePolicy().hasHeightForWidth());
        groupBox_8->setSizePolicy(sizePolicy2);
        horizontalLayout_18 = new QHBoxLayout(groupBox_8);
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        gridLayout_9 = new QGridLayout();
        gridLayout_9->setSpacing(6);
        gridLayout_9->setObjectName(QStringLiteral("gridLayout_9"));
        label_19 = new QLabel(groupBox_8);
        label_19->setObjectName(QStringLiteral("label_19"));

        gridLayout_9->addWidget(label_19, 3, 0, 1, 1);

        label_20 = new QLabel(groupBox_8);
        label_20->setObjectName(QStringLiteral("label_20"));

        gridLayout_9->addWidget(label_20, 4, 0, 1, 1);

        mcconfLimCurrentInMinBox = new QDoubleSpinBox(groupBox_8);
        mcconfLimCurrentInMinBox->setObjectName(QStringLiteral("mcconfLimCurrentInMinBox"));
        mcconfLimCurrentInMinBox->setMinimum(-200);
        mcconfLimCurrentInMinBox->setMaximum(0);

        gridLayout_9->addWidget(mcconfLimCurrentInMinBox, 3, 1, 1, 1);

        label_18 = new QLabel(groupBox_8);
        label_18->setObjectName(QStringLiteral("label_18"));

        gridLayout_9->addWidget(label_18, 2, 0, 1, 1);

        label_17 = new QLabel(groupBox_8);
        label_17->setObjectName(QStringLiteral("label_17"));

        gridLayout_9->addWidget(label_17, 1, 0, 1, 1);

        mcconfLimCurrentAbsMaxBox = new QDoubleSpinBox(groupBox_8);
        mcconfLimCurrentAbsMaxBox->setObjectName(QStringLiteral("mcconfLimCurrentAbsMaxBox"));
        mcconfLimCurrentAbsMaxBox->setMaximum(240);

        gridLayout_9->addWidget(mcconfLimCurrentAbsMaxBox, 4, 1, 1, 1);

        mcconfLimCurrentMinBox = new QDoubleSpinBox(groupBox_8);
        mcconfLimCurrentMinBox->setObjectName(QStringLiteral("mcconfLimCurrentMinBox"));
        mcconfLimCurrentMinBox->setMinimum(-200);
        mcconfLimCurrentMinBox->setMaximum(0);

        gridLayout_9->addWidget(mcconfLimCurrentMinBox, 1, 1, 1, 1);

        mcconfLimCurrentInMaxBox = new QDoubleSpinBox(groupBox_8);
        mcconfLimCurrentInMaxBox->setObjectName(QStringLiteral("mcconfLimCurrentInMaxBox"));
        mcconfLimCurrentInMaxBox->setMaximum(200);

        gridLayout_9->addWidget(mcconfLimCurrentInMaxBox, 2, 1, 1, 1);

        label_16 = new QLabel(groupBox_8);
        label_16->setObjectName(QStringLiteral("label_16"));

        gridLayout_9->addWidget(label_16, 0, 0, 1, 1);

        mcconfLimCurrentMaxBox = new QDoubleSpinBox(groupBox_8);
        mcconfLimCurrentMaxBox->setObjectName(QStringLiteral("mcconfLimCurrentMaxBox"));
        mcconfLimCurrentMaxBox->setMaximum(200);

        gridLayout_9->addWidget(mcconfLimCurrentMaxBox, 0, 1, 1, 1);

        mcconfLimCurrentSlowAbsMaxBox = new QCheckBox(groupBox_8);
        mcconfLimCurrentSlowAbsMaxBox->setObjectName(QStringLiteral("mcconfLimCurrentSlowAbsMaxBox"));

        gridLayout_9->addWidget(mcconfLimCurrentSlowAbsMaxBox, 5, 0, 1, 1);


        horizontalLayout_18->addLayout(gridLayout_9);


        gridLayout_24->addWidget(groupBox_8, 0, 0, 1, 1);

        groupBox_9 = new QGroupBox(tab_12);
        groupBox_9->setObjectName(QStringLiteral("groupBox_9"));
        sizePolicy2.setHeightForWidth(groupBox_9->sizePolicy().hasHeightForWidth());
        groupBox_9->setSizePolicy(sizePolicy2);
        horizontalLayout_19 = new QHBoxLayout(groupBox_9);
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        gridLayout_10 = new QGridLayout();
        gridLayout_10->setSpacing(6);
        gridLayout_10->setObjectName(QStringLiteral("gridLayout_10"));
        label_21 = new QLabel(groupBox_9);
        label_21->setObjectName(QStringLiteral("label_21"));

        gridLayout_10->addWidget(label_21, 1, 0, 1, 1);

        mcconfLimMaxErpmBox = new QDoubleSpinBox(groupBox_9);
        mcconfLimMaxErpmBox->setObjectName(QStringLiteral("mcconfLimMaxErpmBox"));
        mcconfLimMaxErpmBox->setMaximum(200000);
        mcconfLimMaxErpmBox->setSingleStep(100);

        gridLayout_10->addWidget(mcconfLimMaxErpmBox, 2, 1, 1, 1);

        mcconfLimMaxErpmFbrakeBox = new QDoubleSpinBox(groupBox_9);
        mcconfLimMaxErpmFbrakeBox->setObjectName(QStringLiteral("mcconfLimMaxErpmFbrakeBox"));
        mcconfLimMaxErpmFbrakeBox->setMaximum(100000);
        mcconfLimMaxErpmFbrakeBox->setSingleStep(100);

        gridLayout_10->addWidget(mcconfLimMaxErpmFbrakeBox, 3, 1, 1, 1);

        mcconfLimMinErpmBox = new QDoubleSpinBox(groupBox_9);
        mcconfLimMinErpmBox->setObjectName(QStringLiteral("mcconfLimMinErpmBox"));
        mcconfLimMinErpmBox->setMinimum(-200000);
        mcconfLimMinErpmBox->setMaximum(0);
        mcconfLimMinErpmBox->setSingleStep(100);

        gridLayout_10->addWidget(mcconfLimMinErpmBox, 1, 1, 1, 1);

        label_22 = new QLabel(groupBox_9);
        label_22->setObjectName(QStringLiteral("label_22"));

        gridLayout_10->addWidget(label_22, 2, 0, 1, 1);

        label_23 = new QLabel(groupBox_9);
        label_23->setObjectName(QStringLiteral("label_23"));

        gridLayout_10->addWidget(label_23, 3, 0, 1, 1);

        mcconfLimErpmLimitNegTorqueBox = new QCheckBox(groupBox_9);
        mcconfLimErpmLimitNegTorqueBox->setObjectName(QStringLiteral("mcconfLimErpmLimitNegTorqueBox"));

        gridLayout_10->addWidget(mcconfLimErpmLimitNegTorqueBox, 0, 0, 1, 1);

        verticalSpacer_11 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_10->addItem(verticalSpacer_11, 5, 0, 1, 1);

        label_62 = new QLabel(groupBox_9);
        label_62->setObjectName(QStringLiteral("label_62"));

        gridLayout_10->addWidget(label_62, 4, 0, 1, 1);

        mcconfLimMaxErpmFbrakeCcBox = new QDoubleSpinBox(groupBox_9);
        mcconfLimMaxErpmFbrakeCcBox->setObjectName(QStringLiteral("mcconfLimMaxErpmFbrakeCcBox"));
        mcconfLimMaxErpmFbrakeCcBox->setMaximum(100000);
        mcconfLimMaxErpmFbrakeCcBox->setSingleStep(100);

        gridLayout_10->addWidget(mcconfLimMaxErpmFbrakeCcBox, 4, 1, 1, 1);


        horizontalLayout_19->addLayout(gridLayout_10);


        gridLayout_24->addWidget(groupBox_9, 0, 1, 1, 1);

        groupBox_27 = new QGroupBox(tab_12);
        groupBox_27->setObjectName(QStringLiteral("groupBox_27"));
        gridLayout_23 = new QGridLayout(groupBox_27);
        gridLayout_23->setSpacing(6);
        gridLayout_23->setContentsMargins(11, 11, 11, 11);
        gridLayout_23->setObjectName(QStringLiteral("gridLayout_23"));
        label_57 = new QLabel(groupBox_27);
        label_57->setObjectName(QStringLiteral("label_57"));

        gridLayout_23->addWidget(label_57, 0, 0, 1, 1);

        mcconfLimTempFetStartBox = new QDoubleSpinBox(groupBox_27);
        mcconfLimTempFetStartBox->setObjectName(QStringLiteral("mcconfLimTempFetStartBox"));
        mcconfLimTempFetStartBox->setMinimum(-100);
        mcconfLimTempFetStartBox->setMaximum(300);
        mcconfLimTempFetStartBox->setSingleStep(5);

        gridLayout_23->addWidget(mcconfLimTempFetStartBox, 0, 1, 1, 1);

        label_58 = new QLabel(groupBox_27);
        label_58->setObjectName(QStringLiteral("label_58"));

        gridLayout_23->addWidget(label_58, 1, 0, 1, 1);

        mcconfLimTempFetEndBox = new QDoubleSpinBox(groupBox_27);
        mcconfLimTempFetEndBox->setObjectName(QStringLiteral("mcconfLimTempFetEndBox"));
        mcconfLimTempFetEndBox->setMinimum(-100);
        mcconfLimTempFetEndBox->setMaximum(300);
        mcconfLimTempFetEndBox->setSingleStep(5);

        gridLayout_23->addWidget(mcconfLimTempFetEndBox, 1, 1, 1, 1);

        label_59 = new QLabel(groupBox_27);
        label_59->setObjectName(QStringLiteral("label_59"));

        gridLayout_23->addWidget(label_59, 2, 0, 1, 1);

        mcconfLimTempMotorStartBox = new QDoubleSpinBox(groupBox_27);
        mcconfLimTempMotorStartBox->setObjectName(QStringLiteral("mcconfLimTempMotorStartBox"));
        mcconfLimTempMotorStartBox->setMinimum(-100);
        mcconfLimTempMotorStartBox->setMaximum(300);
        mcconfLimTempMotorStartBox->setSingleStep(5);

        gridLayout_23->addWidget(mcconfLimTempMotorStartBox, 2, 1, 1, 1);

        label_60 = new QLabel(groupBox_27);
        label_60->setObjectName(QStringLiteral("label_60"));

        gridLayout_23->addWidget(label_60, 3, 0, 1, 1);

        mcconfLimTempMotorEndBox = new QDoubleSpinBox(groupBox_27);
        mcconfLimTempMotorEndBox->setObjectName(QStringLiteral("mcconfLimTempMotorEndBox"));
        mcconfLimTempMotorEndBox->setMinimum(-100);
        mcconfLimTempMotorEndBox->setMaximum(300);
        mcconfLimTempMotorEndBox->setSingleStep(5);

        gridLayout_23->addWidget(mcconfLimTempMotorEndBox, 3, 1, 1, 1);


        gridLayout_24->addWidget(groupBox_27, 1, 0, 1, 1);

        groupBox_10 = new QGroupBox(tab_12);
        groupBox_10->setObjectName(QStringLiteral("groupBox_10"));
        horizontalLayout_20 = new QHBoxLayout(groupBox_10);
        horizontalLayout_20->setSpacing(6);
        horizontalLayout_20->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        gridLayout_11 = new QGridLayout();
        gridLayout_11->setSpacing(6);
        gridLayout_11->setObjectName(QStringLiteral("gridLayout_11"));
        label_86 = new QLabel(groupBox_10);
        label_86->setObjectName(QStringLiteral("label_86"));

        gridLayout_11->addWidget(label_86, 2, 0, 1, 1);

        label_25 = new QLabel(groupBox_10);
        label_25->setObjectName(QStringLiteral("label_25"));

        gridLayout_11->addWidget(label_25, 1, 0, 1, 1);

        label_24 = new QLabel(groupBox_10);
        label_24->setObjectName(QStringLiteral("label_24"));

        gridLayout_11->addWidget(label_24, 0, 0, 1, 1);

        mcconfLimMinVinBox = new QDoubleSpinBox(groupBox_10);
        mcconfLimMinVinBox->setObjectName(QStringLiteral("mcconfLimMinVinBox"));
        mcconfLimMinVinBox->setMinimum(6);
        mcconfLimMinVinBox->setMaximum(60);

        gridLayout_11->addWidget(mcconfLimMinVinBox, 0, 1, 1, 1);

        mcconfLimMaxVinBox = new QDoubleSpinBox(groupBox_10);
        mcconfLimMaxVinBox->setObjectName(QStringLiteral("mcconfLimMaxVinBox"));
        mcconfLimMaxVinBox->setMinimum(6);
        mcconfLimMaxVinBox->setMaximum(60);

        gridLayout_11->addWidget(mcconfLimMaxVinBox, 1, 1, 1, 1);

        label_87 = new QLabel(groupBox_10);
        label_87->setObjectName(QStringLiteral("label_87"));

        gridLayout_11->addWidget(label_87, 3, 0, 1, 1);

        mcconfLimBatteryCutStartBox = new QDoubleSpinBox(groupBox_10);
        mcconfLimBatteryCutStartBox->setObjectName(QStringLiteral("mcconfLimBatteryCutStartBox"));

        gridLayout_11->addWidget(mcconfLimBatteryCutStartBox, 2, 1, 1, 1);

        mcconfLimBatteryCutEndBox = new QDoubleSpinBox(groupBox_10);
        mcconfLimBatteryCutEndBox->setObjectName(QStringLiteral("mcconfLimBatteryCutEndBox"));

        gridLayout_11->addWidget(mcconfLimBatteryCutEndBox, 3, 1, 1, 1);


        horizontalLayout_20->addLayout(gridLayout_11);


        gridLayout_24->addWidget(groupBox_10, 1, 1, 1, 1);


        verticalLayout_24->addLayout(gridLayout_24);

        groupBox_38 = new QGroupBox(tab_12);
        groupBox_38->setObjectName(QStringLiteral("groupBox_38"));
        gridLayout_36 = new QGridLayout(groupBox_38);
        gridLayout_36->setSpacing(6);
        gridLayout_36->setContentsMargins(11, 11, 11, 11);
        gridLayout_36->setObjectName(QStringLiteral("gridLayout_36"));
        label_83 = new QLabel(groupBox_38);
        label_83->setObjectName(QStringLiteral("label_83"));

        gridLayout_36->addWidget(label_83, 0, 0, 2, 2);

        label_84 = new QLabel(groupBox_38);
        label_84->setObjectName(QStringLiteral("label_84"));

        gridLayout_36->addWidget(label_84, 0, 2, 2, 1);

        mcconfLimMaxDutyBox = new QDoubleSpinBox(groupBox_38);
        mcconfLimMaxDutyBox->setObjectName(QStringLiteral("mcconfLimMaxDutyBox"));
        mcconfLimMaxDutyBox->setDecimals(3);
        mcconfLimMaxDutyBox->setMinimum(0.01);
        mcconfLimMaxDutyBox->setMaximum(0.95);
        mcconfLimMaxDutyBox->setSingleStep(0.01);
        mcconfLimMaxDutyBox->setValue(0.95);

        gridLayout_36->addWidget(mcconfLimMaxDutyBox, 0, 3, 2, 1);

        mcconfLimMinDutyBox = new QDoubleSpinBox(groupBox_38);
        mcconfLimMinDutyBox->setObjectName(QStringLiteral("mcconfLimMinDutyBox"));
        mcconfLimMinDutyBox->setDecimals(3);
        mcconfLimMinDutyBox->setMinimum(0.005);
        mcconfLimMinDutyBox->setMaximum(0.5);
        mcconfLimMinDutyBox->setSingleStep(0.005);

        gridLayout_36->addWidget(mcconfLimMinDutyBox, 1, 1, 1, 1);


        verticalLayout_24->addWidget(groupBox_38);

        verticalSpacer_4 = new QSpacerItem(17, 172, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_24->addItem(verticalSpacer_4);

        tabWidget_4->addTab(tab_12, QString());
        tab_13 = new QWidget();
        tab_13->setObjectName(QStringLiteral("tab_13"));
        verticalLayout_23 = new QVBoxLayout(tab_13);
        verticalLayout_23->setSpacing(6);
        verticalLayout_23->setContentsMargins(11, 11, 11, 11);
        verticalLayout_23->setObjectName(QStringLiteral("verticalLayout_23"));
        groupBox_34 = new QGroupBox(tab_13);
        groupBox_34->setObjectName(QStringLiteral("groupBox_34"));
        horizontalLayout_43 = new QHBoxLayout(groupBox_34);
        horizontalLayout_43->setSpacing(6);
        horizontalLayout_43->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_43->setObjectName(QStringLiteral("horizontalLayout_43"));
        mcconfSensorModeSensorlessButton = new QRadioButton(groupBox_34);
        mcconfSensorModeSensorlessButton->setObjectName(QStringLiteral("mcconfSensorModeSensorlessButton"));
        mcconfSensorModeSensorlessButton->setChecked(true);

        horizontalLayout_43->addWidget(mcconfSensorModeSensorlessButton);

        mcconfSensorModeSensoredButton = new QRadioButton(groupBox_34);
        mcconfSensorModeSensoredButton->setObjectName(QStringLiteral("mcconfSensorModeSensoredButton"));

        horizontalLayout_43->addWidget(mcconfSensorModeSensoredButton);

        mcconfSensorModeHybridButton = new QRadioButton(groupBox_34);
        mcconfSensorModeHybridButton->setObjectName(QStringLiteral("mcconfSensorModeHybridButton"));

        horizontalLayout_43->addWidget(mcconfSensorModeHybridButton);

        horizontalSpacer_20 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_43->addItem(horizontalSpacer_20);


        verticalLayout_23->addWidget(groupBox_34);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        mcconfSlBox = new QGroupBox(tab_13);
        mcconfSlBox->setObjectName(QStringLiteral("mcconfSlBox"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(mcconfSlBox->sizePolicy().hasHeightForWidth());
        mcconfSlBox->setSizePolicy(sizePolicy3);
        mcconfSlBox->setCheckable(false);
        mcconfSlBox->setChecked(false);
        gridLayout_12 = new QGridLayout(mcconfSlBox);
        gridLayout_12->setSpacing(6);
        gridLayout_12->setContentsMargins(11, 11, 11, 11);
        gridLayout_12->setObjectName(QStringLiteral("gridLayout_12"));
        label_26 = new QLabel(mcconfSlBox);
        label_26->setObjectName(QStringLiteral("label_26"));

        gridLayout_12->addWidget(label_26, 0, 0, 1, 1);

        mcconfSlMinErpmBox = new QDoubleSpinBox(mcconfSlBox);
        mcconfSlMinErpmBox->setObjectName(QStringLiteral("mcconfSlMinErpmBox"));
        mcconfSlMinErpmBox->setMaximum(100000);
        mcconfSlMinErpmBox->setSingleStep(10);

        gridLayout_12->addWidget(mcconfSlMinErpmBox, 0, 1, 1, 1);

        label_30 = new QLabel(mcconfSlBox);
        label_30->setObjectName(QStringLiteral("label_30"));

        gridLayout_12->addWidget(label_30, 1, 0, 1, 1);

        mcconfSlBrErpmBox = new QDoubleSpinBox(mcconfSlBox);
        mcconfSlBrErpmBox->setObjectName(QStringLiteral("mcconfSlBrErpmBox"));
        mcconfSlBrErpmBox->setMaximum(200000);
        mcconfSlBrErpmBox->setSingleStep(100);

        gridLayout_12->addWidget(mcconfSlBrErpmBox, 1, 1, 1, 1);

        label_29 = new QLabel(mcconfSlBox);
        label_29->setObjectName(QStringLiteral("label_29"));

        gridLayout_12->addWidget(label_29, 2, 0, 1, 1);

        mcconfSlIntLimScaleBrBox = new QDoubleSpinBox(mcconfSlBox);
        mcconfSlIntLimScaleBrBox->setObjectName(QStringLiteral("mcconfSlIntLimScaleBrBox"));
        mcconfSlIntLimScaleBrBox->setMaximum(1);
        mcconfSlIntLimScaleBrBox->setSingleStep(0.1);

        gridLayout_12->addWidget(mcconfSlIntLimScaleBrBox, 2, 1, 1, 1);

        label_61 = new QLabel(mcconfSlBox);
        label_61->setObjectName(QStringLiteral("label_61"));

        gridLayout_12->addWidget(label_61, 3, 0, 1, 1);

        mcconfSlMaxFbCurrBox = new QDoubleSpinBox(mcconfSlBox);
        mcconfSlMaxFbCurrBox->setObjectName(QStringLiteral("mcconfSlMaxFbCurrBox"));
        mcconfSlMaxFbCurrBox->setMaximum(300);

        gridLayout_12->addWidget(mcconfSlMaxFbCurrBox, 3, 1, 1, 1);


        horizontalLayout_21->addWidget(mcconfSlBox);

        groupBox_16 = new QGroupBox(tab_13);
        groupBox_16->setObjectName(QStringLiteral("groupBox_16"));
        gridLayout_46 = new QGridLayout(groupBox_16);
        gridLayout_46->setSpacing(6);
        gridLayout_46->setContentsMargins(11, 11, 11, 11);
        gridLayout_46->setObjectName(QStringLiteral("gridLayout_46"));
        label_100 = new QLabel(groupBox_16);
        label_100->setObjectName(QStringLiteral("label_100"));

        gridLayout_46->addWidget(label_100, 0, 0, 1, 1);

        mcconfCommIntButton = new QRadioButton(groupBox_16);
        mcconfCommIntButton->setObjectName(QStringLiteral("mcconfCommIntButton"));
        mcconfCommIntButton->setChecked(true);

        gridLayout_46->addWidget(mcconfCommIntButton, 0, 1, 1, 1);

        mcconfCommDelayButton = new QRadioButton(groupBox_16);
        mcconfCommDelayButton->setObjectName(QStringLiteral("mcconfCommDelayButton"));

        gridLayout_46->addWidget(mcconfCommDelayButton, 0, 2, 1, 1);

        label_28 = new QLabel(groupBox_16);
        label_28->setObjectName(QStringLiteral("label_28"));

        gridLayout_46->addWidget(label_28, 1, 0, 1, 1);

        mcconfSlIntLimBox = new QDoubleSpinBox(groupBox_16);
        mcconfSlIntLimBox->setObjectName(QStringLiteral("mcconfSlIntLimBox"));
        mcconfSlIntLimBox->setMaximum(2000);
        mcconfSlIntLimBox->setSingleStep(1);

        gridLayout_46->addWidget(mcconfSlIntLimBox, 1, 1, 1, 2);

        label_27 = new QLabel(groupBox_16);
        label_27->setObjectName(QStringLiteral("label_27"));

        gridLayout_46->addWidget(label_27, 2, 0, 1, 1);

        mcconfSlMinErpmIlBox = new QDoubleSpinBox(groupBox_16);
        mcconfSlMinErpmIlBox->setObjectName(QStringLiteral("mcconfSlMinErpmIlBox"));
        mcconfSlMinErpmIlBox->setMaximum(10000);
        mcconfSlMinErpmIlBox->setSingleStep(10);

        gridLayout_46->addWidget(mcconfSlMinErpmIlBox, 2, 1, 1, 2);

        label_41 = new QLabel(groupBox_16);
        label_41->setObjectName(QStringLiteral("label_41"));

        gridLayout_46->addWidget(label_41, 3, 0, 1, 1);

        mcconfSlBemfKBox = new QDoubleSpinBox(groupBox_16);
        mcconfSlBemfKBox->setObjectName(QStringLiteral("mcconfSlBemfKBox"));
        mcconfSlBemfKBox->setMaximum(5000);
        mcconfSlBemfKBox->setSingleStep(10);

        gridLayout_46->addWidget(mcconfSlBemfKBox, 3, 1, 1, 2);


        horizontalLayout_21->addWidget(groupBox_16);


        verticalLayout_23->addLayout(horizontalLayout_21);

        groupBox_12 = new QGroupBox(tab_13);
        groupBox_12->setObjectName(QStringLiteral("groupBox_12"));
        verticalLayout_20 = new QVBoxLayout(groupBox_12);
        verticalLayout_20->setSpacing(6);
        verticalLayout_20->setContentsMargins(11, 11, 11, 11);
        verticalLayout_20->setObjectName(QStringLiteral("verticalLayout_20"));
        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setSpacing(6);
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        label_31 = new QLabel(groupBox_12);
        label_31->setObjectName(QStringLiteral("label_31"));

        horizontalLayout_22->addWidget(label_31);

        mcconfHallTab0Box = new QSpinBox(groupBox_12);
        mcconfHallTab0Box->setObjectName(QStringLiteral("mcconfHallTab0Box"));
        mcconfHallTab0Box->setMinimum(-1);
        mcconfHallTab0Box->setMaximum(6);

        horizontalLayout_22->addWidget(mcconfHallTab0Box);

        mcconfHallTab1Box = new QSpinBox(groupBox_12);
        mcconfHallTab1Box->setObjectName(QStringLiteral("mcconfHallTab1Box"));
        mcconfHallTab1Box->setMinimum(-1);
        mcconfHallTab1Box->setMaximum(6);

        horizontalLayout_22->addWidget(mcconfHallTab1Box);

        mcconfHallTab2Box = new QSpinBox(groupBox_12);
        mcconfHallTab2Box->setObjectName(QStringLiteral("mcconfHallTab2Box"));
        mcconfHallTab2Box->setMinimum(-1);
        mcconfHallTab2Box->setMaximum(6);

        horizontalLayout_22->addWidget(mcconfHallTab2Box);

        mcconfHallTab3Box = new QSpinBox(groupBox_12);
        mcconfHallTab3Box->setObjectName(QStringLiteral("mcconfHallTab3Box"));
        mcconfHallTab3Box->setMinimum(-1);
        mcconfHallTab3Box->setMaximum(6);

        horizontalLayout_22->addWidget(mcconfHallTab3Box);

        mcconfHallTab4Box = new QSpinBox(groupBox_12);
        mcconfHallTab4Box->setObjectName(QStringLiteral("mcconfHallTab4Box"));
        mcconfHallTab4Box->setMinimum(-1);
        mcconfHallTab4Box->setMaximum(6);

        horizontalLayout_22->addWidget(mcconfHallTab4Box);

        mcconfHallTab5Box = new QSpinBox(groupBox_12);
        mcconfHallTab5Box->setObjectName(QStringLiteral("mcconfHallTab5Box"));
        mcconfHallTab5Box->setMinimum(-1);
        mcconfHallTab5Box->setMaximum(6);

        horizontalLayout_22->addWidget(mcconfHallTab5Box);

        mcconfHallTab6Box = new QSpinBox(groupBox_12);
        mcconfHallTab6Box->setObjectName(QStringLiteral("mcconfHallTab6Box"));
        mcconfHallTab6Box->setMinimum(-1);
        mcconfHallTab6Box->setMaximum(6);

        horizontalLayout_22->addWidget(mcconfHallTab6Box);

        mcconfHallTab7Box = new QSpinBox(groupBox_12);
        mcconfHallTab7Box->setObjectName(QStringLiteral("mcconfHallTab7Box"));
        mcconfHallTab7Box->setMinimum(-1);
        mcconfHallTab7Box->setMaximum(6);

        horizontalLayout_22->addWidget(mcconfHallTab7Box);

        label_32 = new QLabel(groupBox_12);
        label_32->setObjectName(QStringLiteral("label_32"));

        horizontalLayout_22->addWidget(label_32);

        mcconfHallSlErpmBox = new QDoubleSpinBox(groupBox_12);
        mcconfHallSlErpmBox->setObjectName(QStringLiteral("mcconfHallSlErpmBox"));
        mcconfHallSlErpmBox->setMaximum(200000);
        mcconfHallSlErpmBox->setSingleStep(10);
        mcconfHallSlErpmBox->setValue(0);

        horizontalLayout_22->addWidget(mcconfHallSlErpmBox);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_22->addItem(horizontalSpacer_8);


        verticalLayout_20->addLayout(horizontalLayout_22);


        verticalLayout_23->addWidget(groupBox_12);

        verticalSpacer_7 = new QSpacerItem(20, 209, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_23->addItem(verticalSpacer_7);

        groupBox_11 = new QGroupBox(tab_13);
        groupBox_11->setObjectName(QStringLiteral("groupBox_11"));
        sizePolicy.setHeightForWidth(groupBox_11->sizePolicy().hasHeightForWidth());
        groupBox_11->setSizePolicy(sizePolicy);
        horizontalLayout_24 = new QHBoxLayout(groupBox_11);
        horizontalLayout_24->setSpacing(6);
        horizontalLayout_24->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_24->setObjectName(QStringLiteral("horizontalLayout_24"));
        gridLayout_47 = new QGridLayout();
        gridLayout_47->setSpacing(6);
        gridLayout_47->setObjectName(QStringLiteral("gridLayout_47"));
        mcconfDetectMotorParamButton = new QPushButton(groupBox_11);
        mcconfDetectMotorParamButton->setObjectName(QStringLiteral("mcconfDetectMotorParamButton"));

        gridLayout_47->addWidget(mcconfDetectMotorParamButton, 0, 0, 1, 1);

        verticalSpacer_5 = new QSpacerItem(20, 13, QSizePolicy::Minimum, QSizePolicy::Preferred);

        gridLayout_47->addItem(verticalSpacer_5, 1, 0, 1, 1);

        mcconfDetectApplyButton = new QPushButton(groupBox_11);
        mcconfDetectApplyButton->setObjectName(QStringLiteral("mcconfDetectApplyButton"));

        gridLayout_47->addWidget(mcconfDetectApplyButton, 2, 0, 1, 1);


        horizontalLayout_24->addLayout(gridLayout_47);

        gridLayout_7 = new QGridLayout();
        gridLayout_7->setSpacing(6);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        mcconfDetectCurrentBox = new QDoubleSpinBox(groupBox_11);
        mcconfDetectCurrentBox->setObjectName(QStringLiteral("mcconfDetectCurrentBox"));
        mcconfDetectCurrentBox->setValue(6);

        gridLayout_7->addWidget(mcconfDetectCurrentBox, 0, 1, 1, 1);

        label_44 = new QLabel(groupBox_11);
        label_44->setObjectName(QStringLiteral("label_44"));

        gridLayout_7->addWidget(label_44, 1, 0, 1, 1);

        mcconfDetectErpmBox = new QDoubleSpinBox(groupBox_11);
        mcconfDetectErpmBox->setObjectName(QStringLiteral("mcconfDetectErpmBox"));
        mcconfDetectErpmBox->setDecimals(1);
        mcconfDetectErpmBox->setMinimum(10);
        mcconfDetectErpmBox->setMaximum(10000);
        mcconfDetectErpmBox->setSingleStep(10);
        mcconfDetectErpmBox->setValue(600);

        gridLayout_7->addWidget(mcconfDetectErpmBox, 1, 1, 1, 1);

        label_42 = new QLabel(groupBox_11);
        label_42->setObjectName(QStringLiteral("label_42"));

        gridLayout_7->addWidget(label_42, 2, 0, 1, 1);

        mcconfDetectLowDutyBox = new QDoubleSpinBox(groupBox_11);
        mcconfDetectLowDutyBox->setObjectName(QStringLiteral("mcconfDetectLowDutyBox"));
        mcconfDetectLowDutyBox->setMaximum(0.4);
        mcconfDetectLowDutyBox->setSingleStep(0.01);
        mcconfDetectLowDutyBox->setValue(0.05);

        gridLayout_7->addWidget(mcconfDetectLowDutyBox, 2, 1, 1, 1);

        label_43 = new QLabel(groupBox_11);
        label_43->setObjectName(QStringLiteral("label_43"));

        gridLayout_7->addWidget(label_43, 0, 0, 1, 1);


        horizontalLayout_24->addLayout(gridLayout_7);

        mcconfDetectResultBrowser = new QTextBrowser(groupBox_11);
        mcconfDetectResultBrowser->setObjectName(QStringLiteral("mcconfDetectResultBrowser"));
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Ignored);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(mcconfDetectResultBrowser->sizePolicy().hasHeightForWidth());
        mcconfDetectResultBrowser->setSizePolicy(sizePolicy4);

        horizontalLayout_24->addWidget(mcconfDetectResultBrowser);


        verticalLayout_23->addWidget(groupBox_11);

        tabWidget_4->addTab(tab_13, QString());
        tab_24 = new QWidget();
        tab_24->setObjectName(QStringLiteral("tab_24"));
        verticalLayout_29 = new QVBoxLayout(tab_24);
        verticalLayout_29->setSpacing(6);
        verticalLayout_29->setContentsMargins(11, 11, 11, 11);
        verticalLayout_29->setObjectName(QStringLiteral("verticalLayout_29"));
        gridLayout_42 = new QGridLayout();
        gridLayout_42->setSpacing(6);
        gridLayout_42->setObjectName(QStringLiteral("gridLayout_42"));
        groupBox_39 = new QGroupBox(tab_24);
        groupBox_39->setObjectName(QStringLiteral("groupBox_39"));
        gridLayout_39 = new QGridLayout(groupBox_39);
        gridLayout_39->setSpacing(6);
        gridLayout_39->setContentsMargins(11, 11, 11, 11);
        gridLayout_39->setObjectName(QStringLiteral("gridLayout_39"));
        mcconfFocEncoderRatioBox = new QDoubleSpinBox(groupBox_39);
        mcconfFocEncoderRatioBox->setObjectName(QStringLiteral("mcconfFocEncoderRatioBox"));
        mcconfFocEncoderRatioBox->setMaximum(500);

        gridLayout_39->addWidget(mcconfFocEncoderRatioBox, 4, 3, 1, 1);

        label_89 = new QLabel(groupBox_39);
        label_89->setObjectName(QStringLiteral("label_89"));

        gridLayout_39->addWidget(label_89, 2, 0, 1, 1);

        mcconfFocCurrKpBox = new QDoubleSpinBox(groupBox_39);
        mcconfFocCurrKpBox->setObjectName(QStringLiteral("mcconfFocCurrKpBox"));
        mcconfFocCurrKpBox->setDecimals(4);
        mcconfFocCurrKpBox->setMaximum(1000);
        mcconfFocCurrKpBox->setSingleStep(0.01);

        gridLayout_39->addWidget(mcconfFocCurrKpBox, 2, 2, 1, 1);

        mcconfFocCurrKiBox = new QDoubleSpinBox(groupBox_39);
        mcconfFocCurrKiBox->setObjectName(QStringLiteral("mcconfFocCurrKiBox"));
        mcconfFocCurrKiBox->setMaximum(100000);

        gridLayout_39->addWidget(mcconfFocCurrKiBox, 2, 3, 1, 1);

        label_92 = new QLabel(groupBox_39);
        label_92->setObjectName(QStringLiteral("label_92"));

        gridLayout_39->addWidget(label_92, 4, 0, 1, 1);

        mcconfFocEncoderOffsetBox = new QDoubleSpinBox(groupBox_39);
        mcconfFocEncoderOffsetBox->setObjectName(QStringLiteral("mcconfFocEncoderOffsetBox"));
        mcconfFocEncoderOffsetBox->setMaximum(360);

        gridLayout_39->addWidget(mcconfFocEncoderOffsetBox, 4, 2, 1, 1);

        label_101 = new QLabel(groupBox_39);
        label_101->setObjectName(QStringLiteral("label_101"));

        gridLayout_39->addWidget(label_101, 0, 0, 1, 1);

        mcconfFocEncoderInvertedBox = new QCheckBox(groupBox_39);
        mcconfFocEncoderInvertedBox->setObjectName(QStringLiteral("mcconfFocEncoderInvertedBox"));

        gridLayout_39->addWidget(mcconfFocEncoderInvertedBox, 5, 3, 1, 1);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setSpacing(6);
        horizontalLayout_26->setObjectName(QStringLiteral("horizontalLayout_26"));
        mcconfFocModeEncoderButton = new QRadioButton(groupBox_39);
        mcconfFocModeEncoderButton->setObjectName(QStringLiteral("mcconfFocModeEncoderButton"));
        mcconfFocModeEncoderButton->setChecked(true);

        horizontalLayout_26->addWidget(mcconfFocModeEncoderButton);

        mcconfFocModeHallButton = new QRadioButton(groupBox_39);
        mcconfFocModeHallButton->setObjectName(QStringLiteral("mcconfFocModeHallButton"));

        horizontalLayout_26->addWidget(mcconfFocModeHallButton);

        mcconfFocModeSensorlessButton = new QRadioButton(groupBox_39);
        mcconfFocModeSensorlessButton->setObjectName(QStringLiteral("mcconfFocModeSensorlessButton"));

        horizontalLayout_26->addWidget(mcconfFocModeSensorlessButton);


        gridLayout_39->addLayout(horizontalLayout_26, 0, 2, 1, 2);

        mcconfFocSlErpmBox = new QDoubleSpinBox(groupBox_39);
        mcconfFocSlErpmBox->setObjectName(QStringLiteral("mcconfFocSlErpmBox"));
        mcconfFocSlErpmBox->setMaximum(200000);
        mcconfFocSlErpmBox->setSingleStep(10);

        gridLayout_39->addWidget(mcconfFocSlErpmBox, 5, 2, 1, 1);

        label_96 = new QLabel(groupBox_39);
        label_96->setObjectName(QStringLiteral("label_96"));

        gridLayout_39->addWidget(label_96, 5, 0, 1, 1);


        gridLayout_42->addWidget(groupBox_39, 0, 0, 1, 1);

        groupBox_41 = new QGroupBox(tab_24);
        groupBox_41->setObjectName(QStringLiteral("groupBox_41"));
        gridLayout_40 = new QGridLayout(groupBox_41);
        gridLayout_40->setSpacing(6);
        gridLayout_40->setContentsMargins(11, 11, 11, 11);
        gridLayout_40->setObjectName(QStringLiteral("gridLayout_40"));
        label_104 = new QLabel(groupBox_41);
        label_104->setObjectName(QStringLiteral("label_104"));

        gridLayout_40->addWidget(label_104, 7, 0, 1, 1);

        mcconfFocPllKpBox = new QDoubleSpinBox(groupBox_41);
        mcconfFocPllKpBox->setObjectName(QStringLiteral("mcconfFocPllKpBox"));
        mcconfFocPllKpBox->setMaximum(100000);

        gridLayout_40->addWidget(mcconfFocPllKpBox, 5, 1, 1, 1);

        mcconfFocDutyDownrampKiBox = new QDoubleSpinBox(groupBox_41);
        mcconfFocDutyDownrampKiBox->setObjectName(QStringLiteral("mcconfFocDutyDownrampKiBox"));
        mcconfFocDutyDownrampKiBox->setMaximum(100000);

        gridLayout_40->addWidget(mcconfFocDutyDownrampKiBox, 6, 2, 1, 1);

        label_103 = new QLabel(groupBox_41);
        label_103->setObjectName(QStringLiteral("label_103"));

        gridLayout_40->addWidget(label_103, 6, 0, 1, 1);

        mcconfFocPllKiBox = new QDoubleSpinBox(groupBox_41);
        mcconfFocPllKiBox->setObjectName(QStringLiteral("mcconfFocPllKiBox"));
        mcconfFocPllKiBox->setDecimals(2);
        mcconfFocPllKiBox->setMaximum(1e+06);
        mcconfFocPllKiBox->setSingleStep(1000);

        gridLayout_40->addWidget(mcconfFocPllKiBox, 5, 2, 1, 1);

        label_90 = new QLabel(groupBox_41);
        label_90->setObjectName(QStringLiteral("label_90"));

        gridLayout_40->addWidget(label_90, 5, 0, 1, 1);

        mcconfFocOpenloopRpmBox = new QDoubleSpinBox(groupBox_41);
        mcconfFocOpenloopRpmBox->setObjectName(QStringLiteral("mcconfFocOpenloopRpmBox"));
        mcconfFocOpenloopRpmBox->setKeyboardTracking(false);
        mcconfFocOpenloopRpmBox->setMaximum(100000);
        mcconfFocOpenloopRpmBox->setSingleStep(10);

        gridLayout_40->addWidget(mcconfFocOpenloopRpmBox, 7, 1, 1, 2);

        mcconfFocDutyDownrampKpBox = new QDoubleSpinBox(groupBox_41);
        mcconfFocDutyDownrampKpBox->setObjectName(QStringLiteral("mcconfFocDutyDownrampKpBox"));
        mcconfFocDutyDownrampKpBox->setMaximum(10000);

        gridLayout_40->addWidget(mcconfFocDutyDownrampKpBox, 6, 1, 1, 1);

        mcconfFocFSwBox = new QSpinBox(groupBox_41);
        mcconfFocFSwBox->setObjectName(QStringLiteral("mcconfFocFSwBox"));
        mcconfFocFSwBox->setMaximum(100000);
        mcconfFocFSwBox->setSingleStep(100);

        gridLayout_40->addWidget(mcconfFocFSwBox, 4, 1, 1, 1);

        label_94 = new QLabel(groupBox_41);
        label_94->setObjectName(QStringLiteral("label_94"));

        gridLayout_40->addWidget(label_94, 4, 0, 1, 1);

        mcconfFocDtCompBox = new QDoubleSpinBox(groupBox_41);
        mcconfFocDtCompBox->setObjectName(QStringLiteral("mcconfFocDtCompBox"));
        mcconfFocDtCompBox->setDecimals(3);
        mcconfFocDtCompBox->setMaximum(10000);
        mcconfFocDtCompBox->setSingleStep(0.01);

        gridLayout_40->addWidget(mcconfFocDtCompBox, 4, 2, 1, 1);


        gridLayout_42->addWidget(groupBox_41, 0, 1, 1, 1);

        groupBox_40 = new QGroupBox(tab_24);
        groupBox_40->setObjectName(QStringLiteral("groupBox_40"));
        gridLayout_41 = new QGridLayout(groupBox_40);
        gridLayout_41->setSpacing(6);
        gridLayout_41->setContentsMargins(11, 11, 11, 11);
        gridLayout_41->setObjectName(QStringLiteral("gridLayout_41"));
        mcconfFocObserverGainBox = new QDoubleSpinBox(groupBox_40);
        mcconfFocObserverGainBox->setObjectName(QStringLiteral("mcconfFocObserverGainBox"));
        mcconfFocObserverGainBox->setMaximum(100000);
        mcconfFocObserverGainBox->setSingleStep(1);

        gridLayout_41->addWidget(mcconfFocObserverGainBox, 4, 1, 1, 1);

        label_98 = new QLabel(groupBox_40);
        label_98->setObjectName(QStringLiteral("label_98"));

        gridLayout_41->addWidget(label_98, 4, 0, 1, 1);

        mcconfFocObserverGainCalcButton = new QPushButton(groupBox_40);
        mcconfFocObserverGainCalcButton->setObjectName(QStringLiteral("mcconfFocObserverGainCalcButton"));

        gridLayout_41->addWidget(mcconfFocObserverGainCalcButton, 4, 2, 1, 1);

        mcconfFocMotorRBox = new QDoubleSpinBox(groupBox_40);
        mcconfFocMotorRBox->setObjectName(QStringLiteral("mcconfFocMotorRBox"));
        mcconfFocMotorRBox->setDecimals(5);
        mcconfFocMotorRBox->setMaximum(1000);
        mcconfFocMotorRBox->setSingleStep(0.001);

        gridLayout_41->addWidget(mcconfFocMotorRBox, 1, 0, 1, 1);

        mcconfFocMotorLBox = new QDoubleSpinBox(groupBox_40);
        mcconfFocMotorLBox->setObjectName(QStringLiteral("mcconfFocMotorLBox"));
        mcconfFocMotorLBox->setDecimals(2);
        mcconfFocMotorLBox->setMaximum(1e+06);

        gridLayout_41->addWidget(mcconfFocMotorLBox, 1, 1, 1, 1);

        mcconfFocMotorLinkageBox = new QDoubleSpinBox(groupBox_40);
        mcconfFocMotorLinkageBox->setObjectName(QStringLiteral("mcconfFocMotorLinkageBox"));
        mcconfFocMotorLinkageBox->setDecimals(6);
        mcconfFocMotorLinkageBox->setMaximum(1000);
        mcconfFocMotorLinkageBox->setSingleStep(0.0001);

        gridLayout_41->addWidget(mcconfFocMotorLinkageBox, 1, 2, 1, 1);


        gridLayout_42->addWidget(groupBox_40, 1, 0, 1, 1);

        groupBox_43 = new QGroupBox(tab_24);
        groupBox_43->setObjectName(QStringLiteral("groupBox_43"));
        gridLayout_44 = new QGridLayout(groupBox_43);
        gridLayout_44->setSpacing(6);
        gridLayout_44->setContentsMargins(11, 11, 11, 11);
        gridLayout_44->setObjectName(QStringLiteral("gridLayout_44"));
        mcconfFocDCurrentFactorBox = new QDoubleSpinBox(groupBox_43);
        mcconfFocDCurrentFactorBox->setObjectName(QStringLiteral("mcconfFocDCurrentFactorBox"));
        mcconfFocDCurrentFactorBox->setSingleStep(0.1);

        gridLayout_44->addWidget(mcconfFocDCurrentFactorBox, 1, 2, 1, 1);

        mcconfFocSlOpenloopHystBox = new QDoubleSpinBox(groupBox_43);
        mcconfFocSlOpenloopHystBox->setObjectName(QStringLiteral("mcconfFocSlOpenloopHystBox"));
        mcconfFocSlOpenloopHystBox->setDecimals(3);
        mcconfFocSlOpenloopHystBox->setMaximum(200);
        mcconfFocSlOpenloopHystBox->setSingleStep(0.1);

        gridLayout_44->addWidget(mcconfFocSlOpenloopHystBox, 0, 1, 1, 1);

        label_105 = new QLabel(groupBox_43);
        label_105->setObjectName(QStringLiteral("label_105"));

        gridLayout_44->addWidget(label_105, 0, 0, 1, 1);

        label_107 = new QLabel(groupBox_43);
        label_107->setObjectName(QStringLiteral("label_107"));

        gridLayout_44->addWidget(label_107, 1, 0, 1, 1);

        mcconfFocDCurrentDutyBox = new QDoubleSpinBox(groupBox_43);
        mcconfFocDCurrentDutyBox->setObjectName(QStringLiteral("mcconfFocDCurrentDutyBox"));
        mcconfFocDCurrentDutyBox->setDecimals(3);
        mcconfFocDCurrentDutyBox->setMaximum(1);
        mcconfFocDCurrentDutyBox->setSingleStep(0.01);

        gridLayout_44->addWidget(mcconfFocDCurrentDutyBox, 1, 1, 1, 1);

        mcconfFocSlOpenloopTimeBox = new QDoubleSpinBox(groupBox_43);
        mcconfFocSlOpenloopTimeBox->setObjectName(QStringLiteral("mcconfFocSlOpenloopTimeBox"));
        mcconfFocSlOpenloopTimeBox->setDecimals(3);
        mcconfFocSlOpenloopTimeBox->setMaximum(200);
        mcconfFocSlOpenloopTimeBox->setSingleStep(0.1);

        gridLayout_44->addWidget(mcconfFocSlOpenloopTimeBox, 0, 2, 1, 1);


        gridLayout_42->addWidget(groupBox_43, 1, 1, 1, 1);


        verticalLayout_29->addLayout(gridLayout_42);

        groupBox_46 = new QGroupBox(tab_24);
        groupBox_46->setObjectName(QStringLiteral("groupBox_46"));
        horizontalLayout_45 = new QHBoxLayout(groupBox_46);
        horizontalLayout_45->setSpacing(6);
        horizontalLayout_45->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_45->setObjectName(QStringLiteral("horizontalLayout_45"));
        label_95 = new QLabel(groupBox_46);
        label_95->setObjectName(QStringLiteral("label_95"));

        horizontalLayout_45->addWidget(label_95);

        mcconfFocHallTab0Box = new QSpinBox(groupBox_46);
        mcconfFocHallTab0Box->setObjectName(QStringLiteral("mcconfFocHallTab0Box"));
        mcconfFocHallTab0Box->setMaximum(255);

        horizontalLayout_45->addWidget(mcconfFocHallTab0Box);

        mcconfFocHallTab1Box = new QSpinBox(groupBox_46);
        mcconfFocHallTab1Box->setObjectName(QStringLiteral("mcconfFocHallTab1Box"));
        mcconfFocHallTab1Box->setMaximum(255);

        horizontalLayout_45->addWidget(mcconfFocHallTab1Box);

        mcconfFocHallTab2Box = new QSpinBox(groupBox_46);
        mcconfFocHallTab2Box->setObjectName(QStringLiteral("mcconfFocHallTab2Box"));
        mcconfFocHallTab2Box->setMaximum(255);

        horizontalLayout_45->addWidget(mcconfFocHallTab2Box);

        mcconfFocHallTab3Box = new QSpinBox(groupBox_46);
        mcconfFocHallTab3Box->setObjectName(QStringLiteral("mcconfFocHallTab3Box"));
        mcconfFocHallTab3Box->setMaximum(255);

        horizontalLayout_45->addWidget(mcconfFocHallTab3Box);

        mcconfFocHallTab4Box = new QSpinBox(groupBox_46);
        mcconfFocHallTab4Box->setObjectName(QStringLiteral("mcconfFocHallTab4Box"));
        mcconfFocHallTab4Box->setMaximum(255);

        horizontalLayout_45->addWidget(mcconfFocHallTab4Box);

        mcconfFocHallTab5Box = new QSpinBox(groupBox_46);
        mcconfFocHallTab5Box->setObjectName(QStringLiteral("mcconfFocHallTab5Box"));
        mcconfFocHallTab5Box->setMaximum(255);

        horizontalLayout_45->addWidget(mcconfFocHallTab5Box);

        mcconfFocHallTab6Box = new QSpinBox(groupBox_46);
        mcconfFocHallTab6Box->setObjectName(QStringLiteral("mcconfFocHallTab6Box"));
        mcconfFocHallTab6Box->setMaximum(255);

        horizontalLayout_45->addWidget(mcconfFocHallTab6Box);

        mcconfFocHallTab7Box = new QSpinBox(groupBox_46);
        mcconfFocHallTab7Box->setObjectName(QStringLiteral("mcconfFocHallTab7Box"));
        mcconfFocHallTab7Box->setMaximum(255);

        horizontalLayout_45->addWidget(mcconfFocHallTab7Box);

        horizontalSpacer_23 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_45->addItem(horizontalSpacer_23);


        verticalLayout_29->addWidget(groupBox_46);

        verticalSpacer_17 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_29->addItem(verticalSpacer_17);

        groupBox_44 = new QGroupBox(tab_24);
        groupBox_44->setObjectName(QStringLiteral("groupBox_44"));
        gridLayout_45 = new QGridLayout(groupBox_44);
        gridLayout_45->setSpacing(6);
        gridLayout_45->setContentsMargins(11, 11, 11, 11);
        gridLayout_45->setObjectName(QStringLiteral("gridLayout_45"));
        horizontalSpacer_29 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_45->addItem(horizontalSpacer_29, 0, 4, 1, 1);

        mcconfFocCalcCCTcBox = new QDoubleSpinBox(groupBox_44);
        mcconfFocCalcCCTcBox->setObjectName(QStringLiteral("mcconfFocCalcCCTcBox"));
        mcconfFocCalcCCTcBox->setDecimals(1);
        mcconfFocCalcCCTcBox->setMaximum(100000);
        mcconfFocCalcCCTcBox->setSingleStep(10);
        mcconfFocCalcCCTcBox->setValue(1000);

        gridLayout_45->addWidget(mcconfFocCalcCCTcBox, 3, 1, 1, 1);

        mcconfFocMeasureLinkageButton = new QPushButton(groupBox_44);
        mcconfFocMeasureLinkageButton->setObjectName(QStringLiteral("mcconfFocMeasureLinkageButton"));

        gridLayout_45->addWidget(mcconfFocMeasureLinkageButton, 2, 0, 1, 1);

        mcconfFocMeasureRLButton = new QPushButton(groupBox_44);
        mcconfFocMeasureRLButton->setObjectName(QStringLiteral("mcconfFocMeasureRLButton"));

        gridLayout_45->addWidget(mcconfFocMeasureRLButton, 0, 0, 1, 1);

        mcconfFocDetectRBox = new QDoubleSpinBox(groupBox_44);
        mcconfFocDetectRBox->setObjectName(QStringLiteral("mcconfFocDetectRBox"));
        mcconfFocDetectRBox->setDecimals(5);
        mcconfFocDetectRBox->setMaximum(1000);
        mcconfFocDetectRBox->setSingleStep(0.001);

        gridLayout_45->addWidget(mcconfFocDetectRBox, 0, 1, 1, 1);

        mcconfFocDetectLBox = new QDoubleSpinBox(groupBox_44);
        mcconfFocDetectLBox->setObjectName(QStringLiteral("mcconfFocDetectLBox"));
        mcconfFocDetectLBox->setMaximum(100000);

        gridLayout_45->addWidget(mcconfFocDetectLBox, 0, 2, 1, 1);

        mcconfFocApplyRLLambdaButton = new QPushButton(groupBox_44);
        mcconfFocApplyRLLambdaButton->setObjectName(QStringLiteral("mcconfFocApplyRLLambdaButton"));

        gridLayout_45->addWidget(mcconfFocApplyRLLambdaButton, 0, 5, 1, 1);

        mcconfFocCalcCCButton = new QPushButton(groupBox_44);
        mcconfFocCalcCCButton->setObjectName(QStringLiteral("mcconfFocCalcCCButton"));

        gridLayout_45->addWidget(mcconfFocCalcCCButton, 3, 0, 1, 1);

        mcconfFocCalcCCApplyButton = new QPushButton(groupBox_44);
        mcconfFocCalcCCApplyButton->setObjectName(QStringLiteral("mcconfFocCalcCCApplyButton"));

        gridLayout_45->addWidget(mcconfFocCalcCCApplyButton, 3, 5, 1, 1);

        mcconfFocDetectLinkageBox = new QDoubleSpinBox(groupBox_44);
        mcconfFocDetectLinkageBox->setObjectName(QStringLiteral("mcconfFocDetectLinkageBox"));
        mcconfFocDetectLinkageBox->setReadOnly(true);
        mcconfFocDetectLinkageBox->setDecimals(8);
        mcconfFocDetectLinkageBox->setMaximum(100);
        mcconfFocDetectLinkageBox->setSingleStep(0.0001);
        mcconfFocDetectLinkageBox->setValue(0);

        gridLayout_45->addWidget(mcconfFocDetectLinkageBox, 0, 3, 1, 1);

        mcconfFocCalcKiBox = new QDoubleSpinBox(groupBox_44);
        mcconfFocCalcKiBox->setObjectName(QStringLiteral("mcconfFocCalcKiBox"));
        mcconfFocCalcKiBox->setReadOnly(true);
        mcconfFocCalcKiBox->setMaximum(100000);

        gridLayout_45->addWidget(mcconfFocCalcKiBox, 3, 3, 1, 1);

        mcconfFocCalcKpBox = new QDoubleSpinBox(groupBox_44);
        mcconfFocCalcKpBox->setObjectName(QStringLiteral("mcconfFocCalcKpBox"));
        mcconfFocCalcKpBox->setReadOnly(true);
        mcconfFocCalcKpBox->setDecimals(4);
        mcconfFocCalcKpBox->setMaximum(1000);
        mcconfFocCalcKpBox->setSingleStep(0.01);

        gridLayout_45->addWidget(mcconfFocCalcKpBox, 3, 2, 1, 1);

        mcconfFocDetectCurrentBox = new QDoubleSpinBox(groupBox_44);
        mcconfFocDetectCurrentBox->setObjectName(QStringLiteral("mcconfFocDetectCurrentBox"));
        mcconfFocDetectCurrentBox->setMaximum(150);
        mcconfFocDetectCurrentBox->setValue(6);

        gridLayout_45->addWidget(mcconfFocDetectCurrentBox, 2, 1, 1, 1);

        mcconfFocDetectDutyBox = new QDoubleSpinBox(groupBox_44);
        mcconfFocDetectDutyBox->setObjectName(QStringLiteral("mcconfFocDetectDutyBox"));
        mcconfFocDetectDutyBox->setMaximum(1);
        mcconfFocDetectDutyBox->setSingleStep(0.01);
        mcconfFocDetectDutyBox->setValue(0.5);

        gridLayout_45->addWidget(mcconfFocDetectDutyBox, 2, 2, 1, 1);

        mcconfFocDetectMinRpmBox = new QDoubleSpinBox(groupBox_44);
        mcconfFocDetectMinRpmBox->setObjectName(QStringLiteral("mcconfFocDetectMinRpmBox"));
        mcconfFocDetectMinRpmBox->setDecimals(1);
        mcconfFocDetectMinRpmBox->setMaximum(10000);
        mcconfFocDetectMinRpmBox->setSingleStep(10);
        mcconfFocDetectMinRpmBox->setValue(700);

        gridLayout_45->addWidget(mcconfFocDetectMinRpmBox, 2, 3, 1, 1);

        label_93 = new QLabel(groupBox_44);
        label_93->setObjectName(QStringLiteral("label_93"));

        gridLayout_45->addWidget(label_93, 2, 4, 1, 2);


        verticalLayout_29->addWidget(groupBox_44);

        groupBox_42 = new QGroupBox(tab_24);
        groupBox_42->setObjectName(QStringLiteral("groupBox_42"));
        horizontalLayout_25 = new QHBoxLayout(groupBox_42);
        horizontalLayout_25->setSpacing(6);
        horizontalLayout_25->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_25->setObjectName(QStringLiteral("horizontalLayout_25"));
        mcconfFocMeasureEncoderButton = new QPushButton(groupBox_42);
        mcconfFocMeasureEncoderButton->setObjectName(QStringLiteral("mcconfFocMeasureEncoderButton"));

        horizontalLayout_25->addWidget(mcconfFocMeasureEncoderButton);

        mcconfFocMeasureEncoderCurrentBox = new QDoubleSpinBox(groupBox_42);
        mcconfFocMeasureEncoderCurrentBox->setObjectName(QStringLiteral("mcconfFocMeasureEncoderCurrentBox"));
        mcconfFocMeasureEncoderCurrentBox->setValue(15);

        horizontalLayout_25->addWidget(mcconfFocMeasureEncoderCurrentBox);

        horizontalSpacer_26 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_25->addItem(horizontalSpacer_26);

        mcconfFocMeasureEncoderOffsetBox = new QDoubleSpinBox(groupBox_42);
        mcconfFocMeasureEncoderOffsetBox->setObjectName(QStringLiteral("mcconfFocMeasureEncoderOffsetBox"));
        mcconfFocMeasureEncoderOffsetBox->setReadOnly(true);
        mcconfFocMeasureEncoderOffsetBox->setMaximum(360);

        horizontalLayout_25->addWidget(mcconfFocMeasureEncoderOffsetBox);

        mcconfFocMeasureEncoderRatioBox = new QDoubleSpinBox(groupBox_42);
        mcconfFocMeasureEncoderRatioBox->setObjectName(QStringLiteral("mcconfFocMeasureEncoderRatioBox"));
        mcconfFocMeasureEncoderRatioBox->setReadOnly(true);
        mcconfFocMeasureEncoderRatioBox->setMaximum(500);

        horizontalLayout_25->addWidget(mcconfFocMeasureEncoderRatioBox);

        mcconfFocMeasureEncoderInvertedBox = new QCheckBox(groupBox_42);
        mcconfFocMeasureEncoderInvertedBox->setObjectName(QStringLiteral("mcconfFocMeasureEncoderInvertedBox"));

        horizontalLayout_25->addWidget(mcconfFocMeasureEncoderInvertedBox);

        horizontalSpacer_27 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_25->addItem(horizontalSpacer_27);

        mcconfFocMeasureEncoderApplyButton = new QPushButton(groupBox_42);
        mcconfFocMeasureEncoderApplyButton->setObjectName(QStringLiteral("mcconfFocMeasureEncoderApplyButton"));

        horizontalLayout_25->addWidget(mcconfFocMeasureEncoderApplyButton);


        verticalLayout_29->addWidget(groupBox_42);

        groupBox_45 = new QGroupBox(tab_24);
        groupBox_45->setObjectName(QStringLiteral("groupBox_45"));
        horizontalLayout_38 = new QHBoxLayout(groupBox_45);
        horizontalLayout_38->setSpacing(6);
        horizontalLayout_38->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_38->setObjectName(QStringLiteral("horizontalLayout_38"));
        mcconfFocMeasureHallButton = new QPushButton(groupBox_45);
        mcconfFocMeasureHallButton->setObjectName(QStringLiteral("mcconfFocMeasureHallButton"));

        horizontalLayout_38->addWidget(mcconfFocMeasureHallButton);

        mcconfFocMeasureHallCurrentBox = new QDoubleSpinBox(groupBox_45);
        mcconfFocMeasureHallCurrentBox->setObjectName(QStringLiteral("mcconfFocMeasureHallCurrentBox"));
        mcconfFocMeasureHallCurrentBox->setValue(15);

        horizontalLayout_38->addWidget(mcconfFocMeasureHallCurrentBox);

        horizontalSpacer_25 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_38->addItem(horizontalSpacer_25);

        mcconfFocMeasureHallTab0Box = new QSpinBox(groupBox_45);
        mcconfFocMeasureHallTab0Box->setObjectName(QStringLiteral("mcconfFocMeasureHallTab0Box"));
        mcconfFocMeasureHallTab0Box->setMaximum(255);

        horizontalLayout_38->addWidget(mcconfFocMeasureHallTab0Box);

        mcconfFocMeasureHallTab1Box = new QSpinBox(groupBox_45);
        mcconfFocMeasureHallTab1Box->setObjectName(QStringLiteral("mcconfFocMeasureHallTab1Box"));
        mcconfFocMeasureHallTab1Box->setMaximum(255);

        horizontalLayout_38->addWidget(mcconfFocMeasureHallTab1Box);

        mcconfFocMeasureHallTab2Box = new QSpinBox(groupBox_45);
        mcconfFocMeasureHallTab2Box->setObjectName(QStringLiteral("mcconfFocMeasureHallTab2Box"));
        mcconfFocMeasureHallTab2Box->setMaximum(255);

        horizontalLayout_38->addWidget(mcconfFocMeasureHallTab2Box);

        mcconfFocMeasureHallTab3Box = new QSpinBox(groupBox_45);
        mcconfFocMeasureHallTab3Box->setObjectName(QStringLiteral("mcconfFocMeasureHallTab3Box"));
        mcconfFocMeasureHallTab3Box->setMaximum(255);

        horizontalLayout_38->addWidget(mcconfFocMeasureHallTab3Box);

        mcconfFocMeasureHallTab4Box = new QSpinBox(groupBox_45);
        mcconfFocMeasureHallTab4Box->setObjectName(QStringLiteral("mcconfFocMeasureHallTab4Box"));
        mcconfFocMeasureHallTab4Box->setMaximum(255);

        horizontalLayout_38->addWidget(mcconfFocMeasureHallTab4Box);

        mcconfFocMeasureHallTab5Box = new QSpinBox(groupBox_45);
        mcconfFocMeasureHallTab5Box->setObjectName(QStringLiteral("mcconfFocMeasureHallTab5Box"));
        mcconfFocMeasureHallTab5Box->setMaximum(255);

        horizontalLayout_38->addWidget(mcconfFocMeasureHallTab5Box);

        mcconfFocMeasureHallTab6Box = new QSpinBox(groupBox_45);
        mcconfFocMeasureHallTab6Box->setObjectName(QStringLiteral("mcconfFocMeasureHallTab6Box"));
        mcconfFocMeasureHallTab6Box->setMaximum(255);

        horizontalLayout_38->addWidget(mcconfFocMeasureHallTab6Box);

        mcconfFocMeasureHallTab7Box = new QSpinBox(groupBox_45);
        mcconfFocMeasureHallTab7Box->setObjectName(QStringLiteral("mcconfFocMeasureHallTab7Box"));
        mcconfFocMeasureHallTab7Box->setMaximum(255);

        horizontalLayout_38->addWidget(mcconfFocMeasureHallTab7Box);

        horizontalSpacer_24 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_38->addItem(horizontalSpacer_24);

        mcconfFocMeasureHallApplyButton = new QPushButton(groupBox_45);
        mcconfFocMeasureHallApplyButton->setObjectName(QStringLiteral("mcconfFocMeasureHallApplyButton"));

        horizontalLayout_38->addWidget(mcconfFocMeasureHallApplyButton);


        verticalLayout_29->addWidget(groupBox_45);

        tabWidget_4->addTab(tab_24, QString());
        tab_14 = new QWidget();
        tab_14->setObjectName(QStringLiteral("tab_14"));
        verticalLayout_27 = new QVBoxLayout(tab_14);
        verticalLayout_27->setSpacing(6);
        verticalLayout_27->setContentsMargins(11, 11, 11, 11);
        verticalLayout_27->setObjectName(QStringLiteral("verticalLayout_27"));
        groupBox_13 = new QGroupBox(tab_14);
        groupBox_13->setObjectName(QStringLiteral("groupBox_13"));
        horizontalLayout_44 = new QHBoxLayout(groupBox_13);
        horizontalLayout_44->setSpacing(6);
        horizontalLayout_44->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_44->setObjectName(QStringLiteral("horizontalLayout_44"));
        mcconfPwmModeSyncButton = new QRadioButton(groupBox_13);
        mcconfPwmModeSyncButton->setObjectName(QStringLiteral("mcconfPwmModeSyncButton"));
        mcconfPwmModeSyncButton->setChecked(true);

        horizontalLayout_44->addWidget(mcconfPwmModeSyncButton);

        mcconfPwmModeBipolarButton = new QRadioButton(groupBox_13);
        mcconfPwmModeBipolarButton->setObjectName(QStringLiteral("mcconfPwmModeBipolarButton"));

        horizontalLayout_44->addWidget(mcconfPwmModeBipolarButton);

        mcconfPwmModeNonsyncHiswButton = new QRadioButton(groupBox_13);
        mcconfPwmModeNonsyncHiswButton->setObjectName(QStringLiteral("mcconfPwmModeNonsyncHiswButton"));

        horizontalLayout_44->addWidget(mcconfPwmModeNonsyncHiswButton);

        horizontalSpacer_21 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_44->addItem(horizontalSpacer_21);


        verticalLayout_27->addWidget(groupBox_13);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setSpacing(6);
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        groupBox_14 = new QGroupBox(tab_14);
        groupBox_14->setObjectName(QStringLiteral("groupBox_14"));
        sizePolicy3.setHeightForWidth(groupBox_14->sizePolicy().hasHeightForWidth());
        groupBox_14->setSizePolicy(sizePolicy3);
        gridLayout_14 = new QGridLayout(groupBox_14);
        gridLayout_14->setSpacing(6);
        gridLayout_14->setContentsMargins(11, 11, 11, 11);
        gridLayout_14->setObjectName(QStringLiteral("gridLayout_14"));
        label_34 = new QLabel(groupBox_14);
        label_34->setObjectName(QStringLiteral("label_34"));

        gridLayout_14->addWidget(label_34, 0, 0, 1, 1);

        mcconfCcBoostBox = new QDoubleSpinBox(groupBox_14);
        mcconfCcBoostBox->setObjectName(QStringLiteral("mcconfCcBoostBox"));
        mcconfCcBoostBox->setDecimals(3);
        mcconfCcBoostBox->setMaximum(1);
        mcconfCcBoostBox->setSingleStep(0.01);

        gridLayout_14->addWidget(mcconfCcBoostBox, 0, 1, 1, 1);

        label_35 = new QLabel(groupBox_14);
        label_35->setObjectName(QStringLiteral("label_35"));

        gridLayout_14->addWidget(label_35, 1, 0, 1, 1);

        mcconfCcMinBox = new QDoubleSpinBox(groupBox_14);
        mcconfCcMinBox->setObjectName(QStringLiteral("mcconfCcMinBox"));

        gridLayout_14->addWidget(mcconfCcMinBox, 1, 1, 1, 1);

        label_36 = new QLabel(groupBox_14);
        label_36->setObjectName(QStringLiteral("label_36"));

        gridLayout_14->addWidget(label_36, 2, 0, 1, 1);

        mcconfCcGainBox = new QDoubleSpinBox(groupBox_14);
        mcconfCcGainBox->setObjectName(QStringLiteral("mcconfCcGainBox"));
        mcconfCcGainBox->setDecimals(5);
        mcconfCcGainBox->setMaximum(50);
        mcconfCcGainBox->setSingleStep(0.0001);

        gridLayout_14->addWidget(mcconfCcGainBox, 2, 1, 1, 1);

        verticalSpacer_16 = new QSpacerItem(20, 25, QSizePolicy::Minimum, QSizePolicy::Preferred);

        gridLayout_14->addItem(verticalSpacer_16, 3, 1, 1, 1);


        horizontalLayout_23->addWidget(groupBox_14);

        groupBox_37 = new QGroupBox(tab_14);
        groupBox_37->setObjectName(QStringLiteral("groupBox_37"));
        groupBox_37->setFlat(false);
        groupBox_37->setCheckable(false);
        gridLayout_37 = new QGridLayout(groupBox_37);
        gridLayout_37->setSpacing(6);
        gridLayout_37->setContentsMargins(11, 11, 11, 11);
        gridLayout_37->setObjectName(QStringLiteral("gridLayout_37"));
        label_3 = new QLabel(groupBox_37);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout_37->addWidget(label_3, 0, 0, 1, 1);

        mcconfMDutyRampStepBox = new QDoubleSpinBox(groupBox_37);
        mcconfMDutyRampStepBox->setObjectName(QStringLiteral("mcconfMDutyRampStepBox"));
        mcconfMDutyRampStepBox->setDecimals(4);
        mcconfMDutyRampStepBox->setSingleStep(0.01);

        gridLayout_37->addWidget(mcconfMDutyRampStepBox, 0, 1, 1, 1);

        label_69 = new QLabel(groupBox_37);
        label_69->setObjectName(QStringLiteral("label_69"));

        gridLayout_37->addWidget(label_69, 1, 0, 1, 1);

        mcconfCcMaxRampStepBox = new QDoubleSpinBox(groupBox_37);
        mcconfCcMaxRampStepBox->setObjectName(QStringLiteral("mcconfCcMaxRampStepBox"));
        mcconfCcMaxRampStepBox->setDecimals(4);
        mcconfCcMaxRampStepBox->setMaximum(50);
        mcconfCcMaxRampStepBox->setSingleStep(0.01);

        gridLayout_37->addWidget(mcconfCcMaxRampStepBox, 1, 1, 1, 1);

        label_85 = new QLabel(groupBox_37);
        label_85->setObjectName(QStringLiteral("label_85"));

        gridLayout_37->addWidget(label_85, 2, 0, 1, 1);

        mcconfMCurrentBackoffGainBox = new QDoubleSpinBox(groupBox_37);
        mcconfMCurrentBackoffGainBox->setObjectName(QStringLiteral("mcconfMCurrentBackoffGainBox"));
        mcconfMCurrentBackoffGainBox->setDecimals(4);
        mcconfMCurrentBackoffGainBox->setSingleStep(0.01);

        gridLayout_37->addWidget(mcconfMCurrentBackoffGainBox, 2, 1, 1, 1);

        label_33 = new QLabel(groupBox_37);
        label_33->setObjectName(QStringLiteral("label_33"));

        gridLayout_37->addWidget(label_33, 3, 0, 1, 1);

        mcconfMDutyRampStepSpeedLimBox = new QDoubleSpinBox(groupBox_37);
        mcconfMDutyRampStepSpeedLimBox->setObjectName(QStringLiteral("mcconfMDutyRampStepSpeedLimBox"));
        mcconfMDutyRampStepSpeedLimBox->setDecimals(5);
        mcconfMDutyRampStepSpeedLimBox->setSingleStep(0.0001);

        gridLayout_37->addWidget(mcconfMDutyRampStepSpeedLimBox, 3, 1, 1, 1);


        horizontalLayout_23->addWidget(groupBox_37);


        verticalLayout_27->addLayout(horizontalLayout_23);

        horizontalLayout_39 = new QHBoxLayout();
        horizontalLayout_39->setSpacing(6);
        horizontalLayout_39->setObjectName(QStringLiteral("horizontalLayout_39"));
        groupBox_15 = new QGroupBox(tab_14);
        groupBox_15->setObjectName(QStringLiteral("groupBox_15"));
        sizePolicy3.setHeightForWidth(groupBox_15->sizePolicy().hasHeightForWidth());
        groupBox_15->setSizePolicy(sizePolicy3);
        gridLayout_15 = new QGridLayout(groupBox_15);
        gridLayout_15->setSpacing(6);
        gridLayout_15->setContentsMargins(11, 11, 11, 11);
        gridLayout_15->setObjectName(QStringLiteral("gridLayout_15"));
        label_37 = new QLabel(groupBox_15);
        label_37->setObjectName(QStringLiteral("label_37"));

        gridLayout_15->addWidget(label_37, 0, 0, 1, 1);

        mcconfSpidKpBox = new QDoubleSpinBox(groupBox_15);
        mcconfSpidKpBox->setObjectName(QStringLiteral("mcconfSpidKpBox"));
        mcconfSpidKpBox->setDecimals(5);
        mcconfSpidKpBox->setSingleStep(0.0001);

        gridLayout_15->addWidget(mcconfSpidKpBox, 0, 1, 1, 1);

        label_38 = new QLabel(groupBox_15);
        label_38->setObjectName(QStringLiteral("label_38"));

        gridLayout_15->addWidget(label_38, 1, 0, 1, 1);

        mcconfSpidKiBox = new QDoubleSpinBox(groupBox_15);
        mcconfSpidKiBox->setObjectName(QStringLiteral("mcconfSpidKiBox"));
        mcconfSpidKiBox->setDecimals(5);
        mcconfSpidKiBox->setSingleStep(0.0001);

        gridLayout_15->addWidget(mcconfSpidKiBox, 1, 1, 1, 1);

        label_39 = new QLabel(groupBox_15);
        label_39->setObjectName(QStringLiteral("label_39"));

        gridLayout_15->addWidget(label_39, 2, 0, 1, 1);

        mcconfSpidKdBox = new QDoubleSpinBox(groupBox_15);
        mcconfSpidKdBox->setObjectName(QStringLiteral("mcconfSpidKdBox"));
        mcconfSpidKdBox->setDecimals(5);
        mcconfSpidKdBox->setSingleStep(0.0001);

        gridLayout_15->addWidget(mcconfSpidKdBox, 2, 1, 1, 1);

        label_40 = new QLabel(groupBox_15);
        label_40->setObjectName(QStringLiteral("label_40"));

        gridLayout_15->addWidget(label_40, 3, 0, 1, 1);

        mcconfSpidMinRpmBox = new QDoubleSpinBox(groupBox_15);
        mcconfSpidMinRpmBox->setObjectName(QStringLiteral("mcconfSpidMinRpmBox"));
        mcconfSpidMinRpmBox->setMaximum(200000);
        mcconfSpidMinRpmBox->setSingleStep(100);

        gridLayout_15->addWidget(mcconfSpidMinRpmBox, 3, 1, 1, 1);


        horizontalLayout_39->addWidget(groupBox_15);

        groupBox_30 = new QGroupBox(tab_14);
        groupBox_30->setObjectName(QStringLiteral("groupBox_30"));
        sizePolicy.setHeightForWidth(groupBox_30->sizePolicy().hasHeightForWidth());
        groupBox_30->setSizePolicy(sizePolicy);
        gridLayout_26 = new QGridLayout(groupBox_30);
        gridLayout_26->setSpacing(6);
        gridLayout_26->setContentsMargins(11, 11, 11, 11);
        gridLayout_26->setObjectName(QStringLiteral("gridLayout_26"));
        label_68 = new QLabel(groupBox_30);
        label_68->setObjectName(QStringLiteral("label_68"));

        gridLayout_26->addWidget(label_68, 0, 0, 1, 1);

        mcconfPpidKiBox = new QDoubleSpinBox(groupBox_30);
        mcconfPpidKiBox->setObjectName(QStringLiteral("mcconfPpidKiBox"));
        mcconfPpidKiBox->setDecimals(5);
        mcconfPpidKiBox->setSingleStep(0.0001);

        gridLayout_26->addWidget(mcconfPpidKiBox, 1, 1, 1, 1);

        label_70 = new QLabel(groupBox_30);
        label_70->setObjectName(QStringLiteral("label_70"));

        gridLayout_26->addWidget(label_70, 1, 0, 1, 1);

        mcconfPpidKdBox = new QDoubleSpinBox(groupBox_30);
        mcconfPpidKdBox->setObjectName(QStringLiteral("mcconfPpidKdBox"));
        mcconfPpidKdBox->setDecimals(5);
        mcconfPpidKdBox->setSingleStep(0.0001);

        gridLayout_26->addWidget(mcconfPpidKdBox, 2, 1, 1, 1);

        label_71 = new QLabel(groupBox_30);
        label_71->setObjectName(QStringLiteral("label_71"));

        gridLayout_26->addWidget(label_71, 2, 0, 1, 1);

        mcconfPpidKpBox = new QDoubleSpinBox(groupBox_30);
        mcconfPpidKpBox->setObjectName(QStringLiteral("mcconfPpidKpBox"));
        mcconfPpidKpBox->setDecimals(5);
        mcconfPpidKpBox->setSingleStep(0.0001);

        gridLayout_26->addWidget(mcconfPpidKpBox, 0, 1, 1, 1);

        label_11 = new QLabel(groupBox_30);
        label_11->setObjectName(QStringLiteral("label_11"));

        gridLayout_26->addWidget(label_11, 3, 0, 1, 1);

        mcconfPpidAngDivBox = new QDoubleSpinBox(groupBox_30);
        mcconfPpidAngDivBox->setObjectName(QStringLiteral("mcconfPpidAngDivBox"));
        mcconfPpidAngDivBox->setMinimum(0.01);
        mcconfPpidAngDivBox->setMaximum(10000);

        gridLayout_26->addWidget(mcconfPpidAngDivBox, 3, 1, 1, 1);


        horizontalLayout_39->addWidget(groupBox_30);


        verticalLayout_27->addLayout(horizontalLayout_39);

        horizontalLayout_53 = new QHBoxLayout();
        horizontalLayout_53->setSpacing(6);
        horizontalLayout_53->setObjectName(QStringLiteral("horizontalLayout_53"));
        groupBox_17 = new QGroupBox(tab_14);
        groupBox_17->setObjectName(QStringLiteral("groupBox_17"));
        gridLayout_38 = new QGridLayout(groupBox_17);
        gridLayout_38->setSpacing(6);
        gridLayout_38->setContentsMargins(11, 11, 11, 11);
        gridLayout_38->setObjectName(QStringLiteral("gridLayout_38"));
        label_4 = new QLabel(groupBox_17);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout_38->addWidget(label_4, 0, 1, 1, 1);

        mcconfMEncoderCountBox = new QSpinBox(groupBox_17);
        mcconfMEncoderCountBox->setObjectName(QStringLiteral("mcconfMEncoderCountBox"));
        mcconfMEncoderCountBox->setMaximum(1000000);
        mcconfMEncoderCountBox->setSingleStep(100);

        gridLayout_38->addWidget(mcconfMEncoderCountBox, 1, 2, 1, 1);

        mcconfMFaultStopTimeBox = new QSpinBox(groupBox_17);
        mcconfMFaultStopTimeBox->setObjectName(QStringLiteral("mcconfMFaultStopTimeBox"));
        mcconfMFaultStopTimeBox->setMinimum(-1);
        mcconfMFaultStopTimeBox->setMaximum(40000000);
        mcconfMFaultStopTimeBox->setSingleStep(500);

        gridLayout_38->addWidget(mcconfMFaultStopTimeBox, 0, 2, 1, 1);

        label_91 = new QLabel(groupBox_17);
        label_91->setObjectName(QStringLiteral("label_91"));

        gridLayout_38->addWidget(label_91, 1, 1, 1, 1);


        horizontalLayout_53->addWidget(groupBox_17);

        groupBox_3 = new QGroupBox(tab_14);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        gridLayout_43 = new QGridLayout(groupBox_3);
        gridLayout_43->setSpacing(6);
        gridLayout_43->setContentsMargins(11, 11, 11, 11);
        gridLayout_43->setObjectName(QStringLiteral("gridLayout_43"));
        mcconfMSensorHallButton = new QRadioButton(groupBox_3);
        mcconfMSensorHallButton->setObjectName(QStringLiteral("mcconfMSensorHallButton"));
        mcconfMSensorHallButton->setChecked(true);

        gridLayout_43->addWidget(mcconfMSensorHallButton, 0, 0, 1, 1);

        mcconfMSensorAsSpiButton = new QRadioButton(groupBox_3);
        mcconfMSensorAsSpiButton->setObjectName(QStringLiteral("mcconfMSensorAsSpiButton"));

        gridLayout_43->addWidget(mcconfMSensorAsSpiButton, 0, 1, 1, 1);

        mcconfMSensorAbiButton = new QRadioButton(groupBox_3);
        mcconfMSensorAbiButton->setObjectName(QStringLiteral("mcconfMSensorAbiButton"));

        gridLayout_43->addWidget(mcconfMSensorAbiButton, 1, 0, 1, 1);


        horizontalLayout_53->addWidget(groupBox_3);

        horizontalSpacer_22 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_53->addItem(horizontalSpacer_22);


        verticalLayout_27->addLayout(horizontalLayout_53);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_27->addItem(verticalSpacer_8);

        tabWidget_4->addTab(tab_14, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        verticalLayout_25 = new QVBoxLayout(tab_4);
        verticalLayout_25->setSpacing(6);
        verticalLayout_25->setContentsMargins(11, 11, 11, 11);
        verticalLayout_25->setObjectName(QStringLiteral("verticalLayout_25"));
        mcconfDescEdit = new MRichTextEdit(tab_4);
        mcconfDescEdit->setObjectName(QStringLiteral("mcconfDescEdit"));

        verticalLayout_25->addWidget(mcconfDescEdit);

        tabWidget_4->addTab(tab_4, QString());

        verticalLayout_31->addWidget(tabWidget_4);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        mcconfReadButton = new QPushButton(tab_11);
        mcconfReadButton->setObjectName(QStringLiteral("mcconfReadButton"));

        horizontalLayout_17->addWidget(mcconfReadButton);

        mcconfReadDefaultButton = new QPushButton(tab_11);
        mcconfReadDefaultButton->setObjectName(QStringLiteral("mcconfReadDefaultButton"));

        horizontalLayout_17->addWidget(mcconfReadDefaultButton);

        mcconfWriteButton = new QPushButton(tab_11);
        mcconfWriteButton->setObjectName(QStringLiteral("mcconfWriteButton"));

        horizontalLayout_17->addWidget(mcconfWriteButton);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_17->addItem(horizontalSpacer_6);

        mcconfLoadXmlButton = new QPushButton(tab_11);
        mcconfLoadXmlButton->setObjectName(QStringLiteral("mcconfLoadXmlButton"));

        horizontalLayout_17->addWidget(mcconfLoadXmlButton);

        mcconfSaveXmlButton = new QPushButton(tab_11);
        mcconfSaveXmlButton->setObjectName(QStringLiteral("mcconfSaveXmlButton"));

        horizontalLayout_17->addWidget(mcconfSaveXmlButton);


        verticalLayout_31->addLayout(horizontalLayout_17);

        tabWidget->addTab(tab_11, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        verticalLayout_33 = new QVBoxLayout(tab_5);
        verticalLayout_33->setSpacing(6);
        verticalLayout_33->setContentsMargins(11, 11, 11, 11);
        verticalLayout_33->setObjectName(QStringLiteral("verticalLayout_33"));
        tabWidget_3 = new QTabWidget(tab_5);
        tabWidget_3->setObjectName(QStringLiteral("tabWidget_3"));
        tabWidget_3->setTabPosition(QTabWidget::West);
        tab_16 = new QWidget();
        tab_16->setObjectName(QStringLiteral("tab_16"));
        verticalLayout_3 = new QVBoxLayout(tab_16);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        groupBox_28 = new QGroupBox(tab_16);
        groupBox_28->setObjectName(QStringLiteral("groupBox_28"));
        gridLayout_29 = new QGridLayout(groupBox_28);
        gridLayout_29->setSpacing(6);
        gridLayout_29->setContentsMargins(11, 11, 11, 11);
        gridLayout_29->setObjectName(QStringLiteral("gridLayout_29"));
        label_65 = new QLabel(groupBox_28);
        label_65->setObjectName(QStringLiteral("label_65"));

        gridLayout_29->addWidget(label_65, 0, 0, 1, 1);

        appconfControllerIdBox = new QSpinBox(groupBox_28);
        appconfControllerIdBox->setObjectName(QStringLiteral("appconfControllerIdBox"));
        appconfControllerIdBox->setMaximum(255);

        gridLayout_29->addWidget(appconfControllerIdBox, 0, 1, 1, 1);


        horizontalLayout_5->addWidget(groupBox_28);

        appconfSendCanStatusBox = new QGroupBox(tab_16);
        appconfSendCanStatusBox->setObjectName(QStringLiteral("appconfSendCanStatusBox"));
        appconfSendCanStatusBox->setCheckable(true);
        appconfSendCanStatusBox->setChecked(false);
        gridLayout_25 = new QGridLayout(appconfSendCanStatusBox);
        gridLayout_25->setSpacing(6);
        gridLayout_25->setContentsMargins(11, 11, 11, 11);
        gridLayout_25->setObjectName(QStringLiteral("gridLayout_25"));
        label_12 = new QLabel(appconfSendCanStatusBox);
        label_12->setObjectName(QStringLiteral("label_12"));

        gridLayout_25->addWidget(label_12, 0, 0, 1, 1);

        appconfSendCanStatusRateBox = new QSpinBox(appconfSendCanStatusBox);
        appconfSendCanStatusRateBox->setObjectName(QStringLiteral("appconfSendCanStatusRateBox"));
        appconfSendCanStatusRateBox->setMaximum(1000);

        gridLayout_25->addWidget(appconfSendCanStatusRateBox, 0, 1, 1, 1);


        horizontalLayout_5->addWidget(appconfSendCanStatusBox);


        verticalLayout_3->addLayout(horizontalLayout_5);

        groupBox_18 = new QGroupBox(tab_16);
        groupBox_18->setObjectName(QStringLiteral("groupBox_18"));
        horizontalLayout_33 = new QHBoxLayout(groupBox_18);
        horizontalLayout_33->setSpacing(6);
        horizontalLayout_33->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_33->setObjectName(QStringLiteral("horizontalLayout_33"));
        gridLayout_22 = new QGridLayout();
        gridLayout_22->setSpacing(6);
        gridLayout_22->setObjectName(QStringLiteral("gridLayout_22"));
        appconfUseUartButton = new QRadioButton(groupBox_18);
        appconfUseUartButton->setObjectName(QStringLiteral("appconfUseUartButton"));

        gridLayout_22->addWidget(appconfUseUartButton, 1, 0, 1, 1);

        appconfUsePpmUartButton = new QRadioButton(groupBox_18);
        appconfUsePpmUartButton->setObjectName(QStringLiteral("appconfUsePpmUartButton"));

        gridLayout_22->addWidget(appconfUsePpmUartButton, 1, 1, 1, 1);

        appconfUseCustomButton = new QRadioButton(groupBox_18);
        appconfUseCustomButton->setObjectName(QStringLiteral("appconfUseCustomButton"));

        gridLayout_22->addWidget(appconfUseCustomButton, 2, 2, 1, 1);

        appconfUseNoAppButton = new QRadioButton(groupBox_18);
        appconfUseNoAppButton->setObjectName(QStringLiteral("appconfUseNoAppButton"));
        appconfUseNoAppButton->setChecked(true);

        gridLayout_22->addWidget(appconfUseNoAppButton, 0, 0, 1, 1);

        appconfUseNrfButton = new QRadioButton(groupBox_18);
        appconfUseNrfButton->setObjectName(QStringLiteral("appconfUseNrfButton"));

        gridLayout_22->addWidget(appconfUseNrfButton, 2, 1, 1, 1);

        appconfUseNunchukButton = new QRadioButton(groupBox_18);
        appconfUseNunchukButton->setObjectName(QStringLiteral("appconfUseNunchukButton"));

        gridLayout_22->addWidget(appconfUseNunchukButton, 2, 0, 1, 1);

        appconfUsePpmButton = new QRadioButton(groupBox_18);
        appconfUsePpmButton->setObjectName(QStringLiteral("appconfUsePpmButton"));

        gridLayout_22->addWidget(appconfUsePpmButton, 0, 1, 1, 1);

        appconfUseAdcButton = new QRadioButton(groupBox_18);
        appconfUseAdcButton->setObjectName(QStringLiteral("appconfUseAdcButton"));

        gridLayout_22->addWidget(appconfUseAdcButton, 0, 2, 1, 1);

        appconfUseAdcUartButton = new QRadioButton(groupBox_18);
        appconfUseAdcUartButton->setObjectName(QStringLiteral("appconfUseAdcUartButton"));

        gridLayout_22->addWidget(appconfUseAdcUartButton, 1, 2, 1, 1);


        horizontalLayout_33->addLayout(gridLayout_22);

        horizontalSpacer_12 = new QSpacerItem(561, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_33->addItem(horizontalSpacer_12);


        verticalLayout_3->addWidget(groupBox_18);

        groupBox_22 = new QGroupBox(tab_16);
        groupBox_22->setObjectName(QStringLiteral("groupBox_22"));
        gridLayout_18 = new QGridLayout(groupBox_22);
        gridLayout_18->setSpacing(6);
        gridLayout_18->setContentsMargins(11, 11, 11, 11);
        gridLayout_18->setObjectName(QStringLiteral("gridLayout_18"));
        label_52 = new QLabel(groupBox_22);
        label_52->setObjectName(QStringLiteral("label_52"));

        gridLayout_18->addWidget(label_52, 0, 0, 1, 1);

        appconfTimeoutBox = new QSpinBox(groupBox_22);
        appconfTimeoutBox->setObjectName(QStringLiteral("appconfTimeoutBox"));
        appconfTimeoutBox->setMaximum(30000);
        appconfTimeoutBox->setSingleStep(500);

        gridLayout_18->addWidget(appconfTimeoutBox, 0, 1, 1, 1);

        label_53 = new QLabel(groupBox_22);
        label_53->setObjectName(QStringLiteral("label_53"));

        gridLayout_18->addWidget(label_53, 1, 0, 1, 1);

        appconfTimeoutBrakeCurrentBox = new QDoubleSpinBox(groupBox_22);
        appconfTimeoutBrakeCurrentBox->setObjectName(QStringLiteral("appconfTimeoutBrakeCurrentBox"));
        appconfTimeoutBrakeCurrentBox->setMaximum(200);

        gridLayout_18->addWidget(appconfTimeoutBrakeCurrentBox, 1, 1, 1, 1);


        verticalLayout_3->addWidget(groupBox_22);

        verticalSpacer_3 = new QSpacerItem(20, 396, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer_3);

        tabWidget_3->addTab(tab_16, QString());
        tab_17 = new QWidget();
        tab_17->setObjectName(QStringLiteral("tab_17"));
        verticalLayout_35 = new QVBoxLayout(tab_17);
        verticalLayout_35->setSpacing(6);
        verticalLayout_35->setContentsMargins(11, 11, 11, 11);
        verticalLayout_35->setObjectName(QStringLiteral("verticalLayout_35"));
        groupBox_19 = new QGroupBox(tab_17);
        groupBox_19->setObjectName(QStringLiteral("groupBox_19"));
        horizontalLayout_28 = new QHBoxLayout(groupBox_19);
        horizontalLayout_28->setSpacing(6);
        horizontalLayout_28->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_28->setObjectName(QStringLiteral("horizontalLayout_28"));
        gridLayout_13 = new QGridLayout();
        gridLayout_13->setSpacing(6);
        gridLayout_13->setObjectName(QStringLiteral("gridLayout_13"));
        appconfPpmDutyNorevButton = new QRadioButton(groupBox_19);
        appconfPpmDutyNorevButton->setObjectName(QStringLiteral("appconfPpmDutyNorevButton"));

        gridLayout_13->addWidget(appconfPpmDutyNorevButton, 0, 2, 1, 1);

        appconfPpmDutyButton = new QRadioButton(groupBox_19);
        appconfPpmDutyButton->setObjectName(QStringLiteral("appconfPpmDutyButton"));

        gridLayout_13->addWidget(appconfPpmDutyButton, 0, 1, 1, 1);

        appconfPpmDisabledButton = new QRadioButton(groupBox_19);
        appconfPpmDisabledButton->setObjectName(QStringLiteral("appconfPpmDisabledButton"));
        appconfPpmDisabledButton->setChecked(true);

        gridLayout_13->addWidget(appconfPpmDisabledButton, 0, 0, 1, 1);

        appconfPpmPidNorevButton = new QRadioButton(groupBox_19);
        appconfPpmPidNorevButton->setObjectName(QStringLiteral("appconfPpmPidNorevButton"));

        gridLayout_13->addWidget(appconfPpmPidNorevButton, 1, 3, 1, 1);

        appconfPpmCurrentNorevBrakeButton = new QRadioButton(groupBox_19);
        appconfPpmCurrentNorevBrakeButton->setObjectName(QStringLiteral("appconfPpmCurrentNorevBrakeButton"));

        gridLayout_13->addWidget(appconfPpmCurrentNorevBrakeButton, 1, 1, 1, 1);

        appconfPpmCurrentButton = new QRadioButton(groupBox_19);
        appconfPpmCurrentButton->setObjectName(QStringLiteral("appconfPpmCurrentButton"));
        appconfPpmCurrentButton->setChecked(false);

        gridLayout_13->addWidget(appconfPpmCurrentButton, 0, 3, 1, 1);

        appconfPpmCurrentNorevButton = new QRadioButton(groupBox_19);
        appconfPpmCurrentNorevButton->setObjectName(QStringLiteral("appconfPpmCurrentNorevButton"));

        gridLayout_13->addWidget(appconfPpmCurrentNorevButton, 1, 0, 1, 1);

        appconfPpmPidButton = new QRadioButton(groupBox_19);
        appconfPpmPidButton->setObjectName(QStringLiteral("appconfPpmPidButton"));

        gridLayout_13->addWidget(appconfPpmPidButton, 1, 2, 1, 1);


        horizontalLayout_28->addLayout(gridLayout_13);

        horizontalSpacer_10 = new QSpacerItem(411, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_28->addItem(horizontalSpacer_10);


        verticalLayout_35->addWidget(groupBox_19);

        groupBox_20 = new QGroupBox(tab_17);
        groupBox_20->setObjectName(QStringLiteral("groupBox_20"));
        gridLayout_17 = new QGridLayout(groupBox_20);
        gridLayout_17->setSpacing(6);
        gridLayout_17->setContentsMargins(11, 11, 11, 11);
        gridLayout_17->setObjectName(QStringLiteral("gridLayout_17"));
        appconfPpmMedianFilterBox = new QCheckBox(groupBox_20);
        appconfPpmMedianFilterBox->setObjectName(QStringLiteral("appconfPpmMedianFilterBox"));

        gridLayout_17->addWidget(appconfPpmMedianFilterBox, 4, 0, 1, 1);

        label_51 = new QLabel(groupBox_20);
        label_51->setObjectName(QStringLiteral("label_51"));

        gridLayout_17->addWidget(label_51, 3, 0, 1, 1);

        appconfPpmPidMaxErpmBox = new QDoubleSpinBox(groupBox_20);
        appconfPpmPidMaxErpmBox->setObjectName(QStringLiteral("appconfPpmPidMaxErpmBox"));
        appconfPpmPidMaxErpmBox->setMaximum(200000);
        appconfPpmPidMaxErpmBox->setSingleStep(100);

        gridLayout_17->addWidget(appconfPpmPidMaxErpmBox, 0, 1, 1, 1);

        label_49 = new QLabel(groupBox_20);
        label_49->setObjectName(QStringLiteral("label_49"));

        gridLayout_17->addWidget(label_49, 1, 0, 1, 1);

        appconfPpmPulseStartBox = new QDoubleSpinBox(groupBox_20);
        appconfPpmPulseStartBox->setObjectName(QStringLiteral("appconfPpmPulseStartBox"));
        appconfPpmPulseStartBox->setMaximum(10);
        appconfPpmPulseStartBox->setSingleStep(0.1);

        gridLayout_17->addWidget(appconfPpmPulseStartBox, 2, 1, 1, 1);

        label_50 = new QLabel(groupBox_20);
        label_50->setObjectName(QStringLiteral("label_50"));

        gridLayout_17->addWidget(label_50, 2, 0, 1, 1);

        appconfPpmPulseWidthBox = new QDoubleSpinBox(groupBox_20);
        appconfPpmPulseWidthBox->setObjectName(QStringLiteral("appconfPpmPulseWidthBox"));
        appconfPpmPulseWidthBox->setMaximum(20);
        appconfPpmPulseWidthBox->setSingleStep(0.1);

        gridLayout_17->addWidget(appconfPpmPulseWidthBox, 3, 1, 1, 1);

        label_45 = new QLabel(groupBox_20);
        label_45->setObjectName(QStringLiteral("label_45"));

        gridLayout_17->addWidget(label_45, 0, 0, 1, 1);

        appconfPpmHystBox = new QDoubleSpinBox(groupBox_20);
        appconfPpmHystBox->setObjectName(QStringLiteral("appconfPpmHystBox"));
        appconfPpmHystBox->setMaximum(1);
        appconfPpmHystBox->setSingleStep(0.05);

        gridLayout_17->addWidget(appconfPpmHystBox, 1, 1, 1, 1);

        appconfPpmSafeStartBox = new QCheckBox(groupBox_20);
        appconfPpmSafeStartBox->setObjectName(QStringLiteral("appconfPpmSafeStartBox"));

        gridLayout_17->addWidget(appconfPpmSafeStartBox, 5, 0, 1, 1);


        verticalLayout_35->addWidget(groupBox_20);

        appconfPpmRpmLimBox = new QGroupBox(tab_17);
        appconfPpmRpmLimBox->setObjectName(QStringLiteral("appconfPpmRpmLimBox"));
        appconfPpmRpmLimBox->setCheckable(true);
        appconfPpmRpmLimBox->setChecked(false);
        gridLayout_20 = new QGridLayout(appconfPpmRpmLimBox);
        gridLayout_20->setSpacing(6);
        gridLayout_20->setContentsMargins(11, 11, 11, 11);
        gridLayout_20->setObjectName(QStringLiteral("gridLayout_20"));
        appconfPpmRpmLimStartBox = new QDoubleSpinBox(appconfPpmRpmLimBox);
        appconfPpmRpmLimStartBox->setObjectName(QStringLiteral("appconfPpmRpmLimStartBox"));
        appconfPpmRpmLimStartBox->setMaximum(200000);
        appconfPpmRpmLimStartBox->setSingleStep(100);

        gridLayout_20->addWidget(appconfPpmRpmLimStartBox, 0, 1, 1, 1);

        label_47 = new QLabel(appconfPpmRpmLimBox);
        label_47->setObjectName(QStringLiteral("label_47"));

        gridLayout_20->addWidget(label_47, 0, 0, 1, 1);

        label_48 = new QLabel(appconfPpmRpmLimBox);
        label_48->setObjectName(QStringLiteral("label_48"));

        gridLayout_20->addWidget(label_48, 1, 0, 1, 1);

        appconfPpmRpmLimEndBox = new QDoubleSpinBox(appconfPpmRpmLimBox);
        appconfPpmRpmLimEndBox->setObjectName(QStringLiteral("appconfPpmRpmLimEndBox"));
        appconfPpmRpmLimEndBox->setMaximum(200000);
        appconfPpmRpmLimEndBox->setSingleStep(100);

        gridLayout_20->addWidget(appconfPpmRpmLimEndBox, 1, 1, 1, 1);


        verticalLayout_35->addWidget(appconfPpmRpmLimBox);

        appconfPpmMultiGroup = new QGroupBox(tab_17);
        appconfPpmMultiGroup->setObjectName(QStringLiteral("appconfPpmMultiGroup"));
        appconfPpmMultiGroup->setCheckable(true);
        appconfPpmMultiGroup->setChecked(false);
        horizontalLayout_37 = new QHBoxLayout(appconfPpmMultiGroup);
        horizontalLayout_37->setSpacing(6);
        horizontalLayout_37->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_37->setObjectName(QStringLiteral("horizontalLayout_37"));
        appconfPpmTcBox = new QCheckBox(appconfPpmMultiGroup);
        appconfPpmTcBox->setObjectName(QStringLiteral("appconfPpmTcBox"));
        appconfPpmTcBox->setChecked(false);

        horizontalLayout_37->addWidget(appconfPpmTcBox);

        horizontalSpacer_14 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_37->addItem(horizontalSpacer_14);

        label_67 = new QLabel(appconfPpmMultiGroup);
        label_67->setObjectName(QStringLiteral("label_67"));

        horizontalLayout_37->addWidget(label_67);

        appconfPpmTcErpmBox = new QDoubleSpinBox(appconfPpmMultiGroup);
        appconfPpmTcErpmBox->setObjectName(QStringLiteral("appconfPpmTcErpmBox"));
        appconfPpmTcErpmBox->setMaximum(100000);
        appconfPpmTcErpmBox->setValue(3000);

        horizontalLayout_37->addWidget(appconfPpmTcErpmBox);


        verticalLayout_35->addWidget(appconfPpmMultiGroup);

        appconfUpdatePpmBox = new QGroupBox(tab_17);
        appconfUpdatePpmBox->setObjectName(QStringLiteral("appconfUpdatePpmBox"));
        appconfUpdatePpmBox->setCheckable(true);
        appconfUpdatePpmBox->setChecked(false);
        gridLayout_19 = new QGridLayout(appconfUpdatePpmBox);
        gridLayout_19->setSpacing(6);
        gridLayout_19->setContentsMargins(11, 11, 11, 11);
        gridLayout_19->setObjectName(QStringLiteral("gridLayout_19"));
        appconfDecodedPpmBar = new QProgressBar(appconfUpdatePpmBox);
        appconfDecodedPpmBar->setObjectName(QStringLiteral("appconfDecodedPpmBar"));
        appconfDecodedPpmBar->setMinimum(0);
        appconfDecodedPpmBar->setMaximum(1000);
        appconfDecodedPpmBar->setValue(0);

        gridLayout_19->addWidget(appconfDecodedPpmBar, 0, 0, 1, 1);

        appconfPpmPulsewidthNumber = new QLCDNumber(appconfUpdatePpmBox);
        appconfPpmPulsewidthNumber->setObjectName(QStringLiteral("appconfPpmPulsewidthNumber"));

        gridLayout_19->addWidget(appconfPpmPulsewidthNumber, 0, 2, 1, 1);

        label_80 = new QLabel(appconfUpdatePpmBox);
        label_80->setObjectName(QStringLiteral("label_80"));

        gridLayout_19->addWidget(label_80, 0, 1, 1, 1);


        verticalLayout_35->addWidget(appconfUpdatePpmBox);

        verticalSpacer_6 = new QSpacerItem(20, 221, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_35->addItem(verticalSpacer_6);

        tabWidget_3->addTab(tab_17, QString());
        tab_22 = new QWidget();
        tab_22->setObjectName(QStringLiteral("tab_22"));
        verticalLayout_16 = new QVBoxLayout(tab_22);
        verticalLayout_16->setSpacing(6);
        verticalLayout_16->setContentsMargins(11, 11, 11, 11);
        verticalLayout_16->setObjectName(QStringLiteral("verticalLayout_16"));
        groupBox_31 = new QGroupBox(tab_22);
        groupBox_31->setObjectName(QStringLiteral("groupBox_31"));
        horizontalLayout_40 = new QHBoxLayout(groupBox_31);
        horizontalLayout_40->setSpacing(6);
        horizontalLayout_40->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_40->setObjectName(QStringLiteral("horizontalLayout_40"));
        gridLayout_30 = new QGridLayout();
        gridLayout_30->setSpacing(6);
        gridLayout_30->setObjectName(QStringLiteral("gridLayout_30"));
        appconfAdcCurrentButtonButton = new QRadioButton(groupBox_31);
        appconfAdcCurrentButtonButton->setObjectName(QStringLiteral("appconfAdcCurrentButtonButton"));

        gridLayout_30->addWidget(appconfAdcCurrentButtonButton, 0, 3, 1, 1);

        appconfAdcDisabledButton = new QRadioButton(groupBox_31);
        appconfAdcDisabledButton->setObjectName(QStringLiteral("appconfAdcDisabledButton"));
        appconfAdcDisabledButton->setChecked(true);

        gridLayout_30->addWidget(appconfAdcDisabledButton, 0, 0, 1, 1);

        appconfAdcCurrentNorevCenterButton = new QRadioButton(groupBox_31);
        appconfAdcCurrentNorevCenterButton->setObjectName(QStringLiteral("appconfAdcCurrentNorevCenterButton"));

        gridLayout_30->addWidget(appconfAdcCurrentNorevCenterButton, 0, 4, 1, 1);

        appconfAdcCurrentNorevButtonButton = new QRadioButton(groupBox_31);
        appconfAdcCurrentNorevButtonButton->setObjectName(QStringLiteral("appconfAdcCurrentNorevButtonButton"));

        gridLayout_30->addWidget(appconfAdcCurrentNorevButtonButton, 1, 0, 1, 1);

        appconfAdcCurrentButton = new QRadioButton(groupBox_31);
        appconfAdcCurrentButton->setObjectName(QStringLiteral("appconfAdcCurrentButton"));
        appconfAdcCurrentButton->setChecked(false);

        gridLayout_30->addWidget(appconfAdcCurrentButton, 0, 1, 1, 1);

        appconfAdcCurrentCenterButton = new QRadioButton(groupBox_31);
        appconfAdcCurrentCenterButton->setObjectName(QStringLiteral("appconfAdcCurrentCenterButton"));

        gridLayout_30->addWidget(appconfAdcCurrentCenterButton, 0, 2, 1, 1);

        appconfAdcDutyCycleButtonButton = new QRadioButton(groupBox_31);
        appconfAdcDutyCycleButtonButton->setObjectName(QStringLiteral("appconfAdcDutyCycleButtonButton"));

        gridLayout_30->addWidget(appconfAdcDutyCycleButtonButton, 1, 4, 1, 1);

        appconfAdcDutyCycleCenterButton = new QRadioButton(groupBox_31);
        appconfAdcDutyCycleCenterButton->setObjectName(QStringLiteral("appconfAdcDutyCycleCenterButton"));

        gridLayout_30->addWidget(appconfAdcDutyCycleCenterButton, 1, 3, 1, 1);

        appconfAdcDutyCycleButton = new QRadioButton(groupBox_31);
        appconfAdcDutyCycleButton->setObjectName(QStringLiteral("appconfAdcDutyCycleButton"));

        gridLayout_30->addWidget(appconfAdcDutyCycleButton, 1, 2, 1, 1);

        appconfAdcCurrentNorevAdcButton = new QRadioButton(groupBox_31);
        appconfAdcCurrentNorevAdcButton->setObjectName(QStringLiteral("appconfAdcCurrentNorevAdcButton"));

        gridLayout_30->addWidget(appconfAdcCurrentNorevAdcButton, 1, 1, 1, 1);


        horizontalLayout_40->addLayout(gridLayout_30);

        horizontalSpacer_16 = new QSpacerItem(411, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_40->addItem(horizontalSpacer_16);


        verticalLayout_16->addWidget(groupBox_31);

        groupBox_33 = new QGroupBox(tab_22);
        groupBox_33->setObjectName(QStringLiteral("groupBox_33"));
        gridLayout_33 = new QGridLayout(groupBox_33);
        gridLayout_33->setSpacing(6);
        gridLayout_33->setContentsMargins(11, 11, 11, 11);
        gridLayout_33->setObjectName(QStringLiteral("gridLayout_33"));
        appconfAdcUpdateRateBox = new QSpinBox(groupBox_33);
        appconfAdcUpdateRateBox->setObjectName(QStringLiteral("appconfAdcUpdateRateBox"));
        appconfAdcUpdateRateBox->setMaximum(10000);
        appconfAdcUpdateRateBox->setSingleStep(10);

        gridLayout_33->addWidget(appconfAdcUpdateRateBox, 0, 1, 1, 1);

        appconfAdcHystBox = new QDoubleSpinBox(groupBox_33);
        appconfAdcHystBox->setObjectName(QStringLiteral("appconfAdcHystBox"));
        appconfAdcHystBox->setMaximum(1);
        appconfAdcHystBox->setSingleStep(0.05);

        gridLayout_33->addWidget(appconfAdcHystBox, 1, 1, 1, 1);

        label_78 = new QLabel(groupBox_33);
        label_78->setObjectName(QStringLiteral("label_78"));

        gridLayout_33->addWidget(label_78, 0, 0, 1, 1);

        appconfAdcFilterBox = new QCheckBox(groupBox_33);
        appconfAdcFilterBox->setObjectName(QStringLiteral("appconfAdcFilterBox"));

        gridLayout_33->addWidget(appconfAdcFilterBox, 0, 5, 1, 1);

        label_76 = new QLabel(groupBox_33);
        label_76->setObjectName(QStringLiteral("label_76"));

        gridLayout_33->addWidget(label_76, 1, 0, 1, 1);

        appconfAdcSafeStartBox = new QCheckBox(groupBox_33);
        appconfAdcSafeStartBox->setObjectName(QStringLiteral("appconfAdcSafeStartBox"));

        gridLayout_33->addWidget(appconfAdcSafeStartBox, 1, 5, 1, 1);

        widget = new QWidget(groupBox_33);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setMinimumSize(QSize(50, 0));

        gridLayout_33->addWidget(widget, 0, 2, 1, 1);

        horizontalSpacer_18 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_33->addItem(horizontalSpacer_18, 0, 7, 1, 1);

        appconfAdcVoltageStartBox = new QDoubleSpinBox(groupBox_33);
        appconfAdcVoltageStartBox->setObjectName(QStringLiteral("appconfAdcVoltageStartBox"));
        appconfAdcVoltageStartBox->setMaximum(10);
        appconfAdcVoltageStartBox->setSingleStep(0.01);

        gridLayout_33->addWidget(appconfAdcVoltageStartBox, 0, 4, 1, 1);

        label_77 = new QLabel(groupBox_33);
        label_77->setObjectName(QStringLiteral("label_77"));

        gridLayout_33->addWidget(label_77, 0, 3, 1, 1);

        label_75 = new QLabel(groupBox_33);
        label_75->setObjectName(QStringLiteral("label_75"));

        gridLayout_33->addWidget(label_75, 1, 3, 1, 1);

        appconfAdcVoltageEndBox = new QDoubleSpinBox(groupBox_33);
        appconfAdcVoltageEndBox->setObjectName(QStringLiteral("appconfAdcVoltageEndBox"));
        appconfAdcVoltageEndBox->setMaximum(20);
        appconfAdcVoltageEndBox->setSingleStep(0.01);

        gridLayout_33->addWidget(appconfAdcVoltageEndBox, 1, 4, 1, 1);

        appconfAdcInvertVoltageBox = new QCheckBox(groupBox_33);
        appconfAdcInvertVoltageBox->setObjectName(QStringLiteral("appconfAdcInvertVoltageBox"));

        gridLayout_33->addWidget(appconfAdcInvertVoltageBox, 0, 6, 1, 1);


        verticalLayout_16->addWidget(groupBox_33);

        groupBox_36 = new QGroupBox(tab_22);
        groupBox_36->setObjectName(QStringLiteral("groupBox_36"));
        gridLayout_35 = new QGridLayout(groupBox_36);
        gridLayout_35->setSpacing(6);
        gridLayout_35->setContentsMargins(11, 11, 11, 11);
        gridLayout_35->setObjectName(QStringLiteral("gridLayout_35"));
        appconfAdcInvertRevButtonBox = new QCheckBox(groupBox_36);
        appconfAdcInvertRevButtonBox->setObjectName(QStringLiteral("appconfAdcInvertRevButtonBox"));

        gridLayout_35->addWidget(appconfAdcInvertRevButtonBox, 2, 0, 1, 1);

        appconfAdcInvertCcButtonBox = new QCheckBox(groupBox_36);
        appconfAdcInvertCcButtonBox->setObjectName(QStringLiteral("appconfAdcInvertCcButtonBox"));

        gridLayout_35->addWidget(appconfAdcInvertCcButtonBox, 3, 0, 1, 1);

        verticalSpacer_12 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_35->addItem(verticalSpacer_12, 4, 0, 1, 1);

        textBrowser_2 = new QTextBrowser(groupBox_36);
        textBrowser_2->setObjectName(QStringLiteral("textBrowser_2"));

        gridLayout_35->addWidget(textBrowser_2, 2, 1, 3, 1);


        verticalLayout_16->addWidget(groupBox_36);

        appconfAdcRpmLimBox = new QGroupBox(tab_22);
        appconfAdcRpmLimBox->setObjectName(QStringLiteral("appconfAdcRpmLimBox"));
        appconfAdcRpmLimBox->setCheckable(true);
        appconfAdcRpmLimBox->setChecked(false);
        gridLayout_32 = new QGridLayout(appconfAdcRpmLimBox);
        gridLayout_32->setSpacing(6);
        gridLayout_32->setContentsMargins(11, 11, 11, 11);
        gridLayout_32->setObjectName(QStringLiteral("gridLayout_32"));
        appconfAdcRpmLimStartBox = new QDoubleSpinBox(appconfAdcRpmLimBox);
        appconfAdcRpmLimStartBox->setObjectName(QStringLiteral("appconfAdcRpmLimStartBox"));
        appconfAdcRpmLimStartBox->setMaximum(200000);
        appconfAdcRpmLimStartBox->setSingleStep(100);

        gridLayout_32->addWidget(appconfAdcRpmLimStartBox, 0, 1, 1, 1);

        label_73 = new QLabel(appconfAdcRpmLimBox);
        label_73->setObjectName(QStringLiteral("label_73"));

        gridLayout_32->addWidget(label_73, 0, 0, 1, 1);

        appconfAdcRpmLimEndBox = new QDoubleSpinBox(appconfAdcRpmLimBox);
        appconfAdcRpmLimEndBox->setObjectName(QStringLiteral("appconfAdcRpmLimEndBox"));
        appconfAdcRpmLimEndBox->setMaximum(200000);
        appconfAdcRpmLimEndBox->setSingleStep(100);

        gridLayout_32->addWidget(appconfAdcRpmLimEndBox, 0, 4, 1, 1);

        label_74 = new QLabel(appconfAdcRpmLimBox);
        label_74->setObjectName(QStringLiteral("label_74"));

        gridLayout_32->addWidget(label_74, 0, 3, 1, 1);

        horizontalSpacer_28 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_32->addItem(horizontalSpacer_28, 0, 2, 1, 1);


        verticalLayout_16->addWidget(appconfAdcRpmLimBox);

        appconfAdcMultiGroup = new QGroupBox(tab_22);
        appconfAdcMultiGroup->setObjectName(QStringLiteral("appconfAdcMultiGroup"));
        appconfAdcMultiGroup->setCheckable(true);
        appconfAdcMultiGroup->setChecked(false);
        horizontalLayout_41 = new QHBoxLayout(appconfAdcMultiGroup);
        horizontalLayout_41->setSpacing(6);
        horizontalLayout_41->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_41->setObjectName(QStringLiteral("horizontalLayout_41"));
        appconfAdcTcBox = new QCheckBox(appconfAdcMultiGroup);
        appconfAdcTcBox->setObjectName(QStringLiteral("appconfAdcTcBox"));
        appconfAdcTcBox->setChecked(false);

        horizontalLayout_41->addWidget(appconfAdcTcBox);

        horizontalSpacer_17 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_41->addItem(horizontalSpacer_17);

        label_72 = new QLabel(appconfAdcMultiGroup);
        label_72->setObjectName(QStringLiteral("label_72"));

        horizontalLayout_41->addWidget(label_72);

        appconfAdcTcErpmBox = new QDoubleSpinBox(appconfAdcMultiGroup);
        appconfAdcTcErpmBox->setObjectName(QStringLiteral("appconfAdcTcErpmBox"));
        appconfAdcTcErpmBox->setMaximum(100000);
        appconfAdcTcErpmBox->setValue(3000);

        horizontalLayout_41->addWidget(appconfAdcTcErpmBox);


        verticalLayout_16->addWidget(appconfAdcMultiGroup);

        appconfAdcUpdateBox = new QGroupBox(tab_22);
        appconfAdcUpdateBox->setObjectName(QStringLiteral("appconfAdcUpdateBox"));
        appconfAdcUpdateBox->setCheckable(true);
        appconfAdcUpdateBox->setChecked(false);
        gridLayout_31 = new QGridLayout(appconfAdcUpdateBox);
        gridLayout_31->setSpacing(6);
        gridLayout_31->setContentsMargins(11, 11, 11, 11);
        gridLayout_31->setObjectName(QStringLiteral("gridLayout_31"));
        appconfAdcDecodedBar = new QProgressBar(appconfAdcUpdateBox);
        appconfAdcDecodedBar->setObjectName(QStringLiteral("appconfAdcDecodedBar"));
        appconfAdcDecodedBar->setMinimum(0);
        appconfAdcDecodedBar->setMaximum(1000);
        appconfAdcDecodedBar->setValue(0);

        gridLayout_31->addWidget(appconfAdcDecodedBar, 0, 0, 1, 1);

        appconfAdcVoltageNumber = new QLCDNumber(appconfAdcUpdateBox);
        appconfAdcVoltageNumber->setObjectName(QStringLiteral("appconfAdcVoltageNumber"));
        appconfAdcVoltageNumber->setProperty("value", QVariant(0));

        gridLayout_31->addWidget(appconfAdcVoltageNumber, 0, 2, 1, 1);

        label_79 = new QLabel(appconfAdcUpdateBox);
        label_79->setObjectName(QStringLiteral("label_79"));

        gridLayout_31->addWidget(label_79, 0, 1, 1, 1);

        appconfAdcDecodedBar2 = new QProgressBar(appconfAdcUpdateBox);
        appconfAdcDecodedBar2->setObjectName(QStringLiteral("appconfAdcDecodedBar2"));
        appconfAdcDecodedBar2->setMaximum(1000);
        appconfAdcDecodedBar2->setValue(0);

        gridLayout_31->addWidget(appconfAdcDecodedBar2, 1, 0, 1, 1);

        lblVoltage2 = new QLabel(appconfAdcUpdateBox);
        lblVoltage2->setObjectName(QStringLiteral("lblVoltage2"));

        gridLayout_31->addWidget(lblVoltage2, 1, 1, 1, 1);

        appconfAdcVoltageNumber2 = new QLCDNumber(appconfAdcUpdateBox);
        appconfAdcVoltageNumber2->setObjectName(QStringLiteral("appconfAdcVoltageNumber2"));

        gridLayout_31->addWidget(appconfAdcVoltageNumber2, 1, 2, 1, 1);


        verticalLayout_16->addWidget(appconfAdcUpdateBox);

        verticalSpacer_14 = new QSpacerItem(20, 76, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_16->addItem(verticalSpacer_14);

        tabWidget_3->addTab(tab_22, QString());
        tab_18 = new QWidget();
        tab_18->setObjectName(QStringLiteral("tab_18"));
        verticalLayout_36 = new QVBoxLayout(tab_18);
        verticalLayout_36->setSpacing(6);
        verticalLayout_36->setContentsMargins(11, 11, 11, 11);
        verticalLayout_36->setObjectName(QStringLiteral("verticalLayout_36"));
        groupBox_21 = new QGroupBox(tab_18);
        groupBox_21->setObjectName(QStringLiteral("groupBox_21"));
        gridLayout_16 = new QGridLayout(groupBox_21);
        gridLayout_16->setSpacing(6);
        gridLayout_16->setContentsMargins(11, 11, 11, 11);
        gridLayout_16->setObjectName(QStringLiteral("gridLayout_16"));
        label_46 = new QLabel(groupBox_21);
        label_46->setObjectName(QStringLiteral("label_46"));

        gridLayout_16->addWidget(label_46, 0, 0, 1, 1);

        appconfUartBaudBox = new QSpinBox(groupBox_21);
        appconfUartBaudBox->setObjectName(QStringLiteral("appconfUartBaudBox"));
        appconfUartBaudBox->setMaximum(20000000);
        appconfUartBaudBox->setSingleStep(2400);

        gridLayout_16->addWidget(appconfUartBaudBox, 0, 1, 1, 1);


        verticalLayout_36->addWidget(groupBox_21);

        verticalSpacer_10 = new QSpacerItem(20, 470, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_36->addItem(verticalSpacer_10);

        tabWidget_3->addTab(tab_18, QString());
        tab_21 = new QWidget();
        tab_21->setObjectName(QStringLiteral("tab_21"));
        verticalLayout_32 = new QVBoxLayout(tab_21);
        verticalLayout_32->setSpacing(6);
        verticalLayout_32->setContentsMargins(11, 11, 11, 11);
        verticalLayout_32->setObjectName(QStringLiteral("verticalLayout_32"));
        groupBox_24 = new QGroupBox(tab_21);
        groupBox_24->setObjectName(QStringLiteral("groupBox_24"));
        horizontalLayout_31 = new QHBoxLayout(groupBox_24);
        horizontalLayout_31->setSpacing(6);
        horizontalLayout_31->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_31->setObjectName(QStringLiteral("horizontalLayout_31"));
        horizontalLayout_35 = new QHBoxLayout();
        horizontalLayout_35->setSpacing(6);
        horizontalLayout_35->setObjectName(QStringLiteral("horizontalLayout_35"));
        appconfChukDisabledButton = new QRadioButton(groupBox_24);
        appconfChukDisabledButton->setObjectName(QStringLiteral("appconfChukDisabledButton"));
        appconfChukDisabledButton->setChecked(true);

        horizontalLayout_35->addWidget(appconfChukDisabledButton);

        appconfChukCurrentNorevButton = new QRadioButton(groupBox_24);
        appconfChukCurrentNorevButton->setObjectName(QStringLiteral("appconfChukCurrentNorevButton"));

        horizontalLayout_35->addWidget(appconfChukCurrentNorevButton);

        appconfChukCurrentButton = new QRadioButton(groupBox_24);
        appconfChukCurrentButton->setObjectName(QStringLiteral("appconfChukCurrentButton"));

        horizontalLayout_35->addWidget(appconfChukCurrentButton);


        horizontalLayout_31->addLayout(horizontalLayout_35);

        horizontalSpacer_11 = new QSpacerItem(720, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_31->addItem(horizontalSpacer_11);


        verticalLayout_32->addWidget(groupBox_24);

        groupBox_25 = new QGroupBox(tab_21);
        groupBox_25->setObjectName(QStringLiteral("groupBox_25"));
        sizePolicy3.setHeightForWidth(groupBox_25->sizePolicy().hasHeightForWidth());
        groupBox_25->setSizePolicy(sizePolicy3);
        gridLayout_21 = new QGridLayout(groupBox_25);
        gridLayout_21->setSpacing(6);
        gridLayout_21->setContentsMargins(11, 11, 11, 11);
        gridLayout_21->setObjectName(QStringLiteral("gridLayout_21"));
        label_54 = new QLabel(groupBox_25);
        label_54->setObjectName(QStringLiteral("label_54"));

        gridLayout_21->addWidget(label_54, 0, 0, 1, 1);

        appconfChukHystBox = new QDoubleSpinBox(groupBox_25);
        appconfChukHystBox->setObjectName(QStringLiteral("appconfChukHystBox"));
        appconfChukHystBox->setMaximum(1);
        appconfChukHystBox->setSingleStep(0.05);

        gridLayout_21->addWidget(appconfChukHystBox, 0, 1, 1, 1);

        label_63 = new QLabel(groupBox_25);
        label_63->setObjectName(QStringLiteral("label_63"));

        gridLayout_21->addWidget(label_63, 0, 2, 1, 1);

        appconfChukRampTimePosBox = new QDoubleSpinBox(groupBox_25);
        appconfChukRampTimePosBox->setObjectName(QStringLiteral("appconfChukRampTimePosBox"));
        appconfChukRampTimePosBox->setSingleStep(0.1);
        appconfChukRampTimePosBox->setValue(1);

        gridLayout_21->addWidget(appconfChukRampTimePosBox, 0, 3, 1, 1);

        label_56 = new QLabel(groupBox_25);
        label_56->setObjectName(QStringLiteral("label_56"));

        gridLayout_21->addWidget(label_56, 1, 0, 1, 1);

        appconfChukRpmLimStartBox = new QDoubleSpinBox(groupBox_25);
        appconfChukRpmLimStartBox->setObjectName(QStringLiteral("appconfChukRpmLimStartBox"));
        appconfChukRpmLimStartBox->setMaximum(200000);
        appconfChukRpmLimStartBox->setSingleStep(100);

        gridLayout_21->addWidget(appconfChukRpmLimStartBox, 1, 1, 1, 1);

        label_64 = new QLabel(groupBox_25);
        label_64->setObjectName(QStringLiteral("label_64"));

        gridLayout_21->addWidget(label_64, 1, 2, 1, 1);

        appconfChukRampTimeNegBox = new QDoubleSpinBox(groupBox_25);
        appconfChukRampTimeNegBox->setObjectName(QStringLiteral("appconfChukRampTimeNegBox"));
        appconfChukRampTimeNegBox->setSingleStep(0.1);
        appconfChukRampTimeNegBox->setValue(0.5);

        gridLayout_21->addWidget(appconfChukRampTimeNegBox, 1, 3, 1, 1);

        label_55 = new QLabel(groupBox_25);
        label_55->setObjectName(QStringLiteral("label_55"));

        gridLayout_21->addWidget(label_55, 2, 0, 1, 1);

        appconfChukRpmLimEndBox = new QDoubleSpinBox(groupBox_25);
        appconfChukRpmLimEndBox->setObjectName(QStringLiteral("appconfChukRpmLimEndBox"));
        appconfChukRpmLimEndBox->setMaximum(200000);
        appconfChukRpmLimEndBox->setSingleStep(100);

        gridLayout_21->addWidget(appconfChukRpmLimEndBox, 2, 1, 1, 1);

        label_88 = new QLabel(groupBox_25);
        label_88->setObjectName(QStringLiteral("label_88"));

        gridLayout_21->addWidget(label_88, 2, 2, 1, 1);

        appconfChukErpmPerSBox = new QDoubleSpinBox(groupBox_25);
        appconfChukErpmPerSBox->setObjectName(QStringLiteral("appconfChukErpmPerSBox"));
        appconfChukErpmPerSBox->setDecimals(1);
        appconfChukErpmPerSBox->setMaximum(100000);
        appconfChukErpmPerSBox->setSingleStep(100);
        appconfChukErpmPerSBox->setValue(3000);

        gridLayout_21->addWidget(appconfChukErpmPerSBox, 2, 3, 1, 1);

        label_56->raise();
        appconfChukRpmLimStartBox->raise();
        label_54->raise();
        appconfChukHystBox->raise();
        label_55->raise();
        appconfChukRpmLimEndBox->raise();
        label_63->raise();
        appconfChukRampTimePosBox->raise();
        label_64->raise();
        appconfChukRampTimeNegBox->raise();
        label_88->raise();
        appconfChukErpmPerSBox->raise();

        verticalLayout_32->addWidget(groupBox_25);

        appconfChukMultiGroup = new QGroupBox(tab_21);
        appconfChukMultiGroup->setObjectName(QStringLiteral("appconfChukMultiGroup"));
        appconfChukMultiGroup->setCheckable(true);
        horizontalLayout_36 = new QHBoxLayout(appconfChukMultiGroup);
        horizontalLayout_36->setSpacing(6);
        horizontalLayout_36->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_36->setObjectName(QStringLiteral("horizontalLayout_36"));
        appconfChukTcBox = new QCheckBox(appconfChukMultiGroup);
        appconfChukTcBox->setObjectName(QStringLiteral("appconfChukTcBox"));
        appconfChukTcBox->setChecked(false);

        horizontalLayout_36->addWidget(appconfChukTcBox);

        horizontalSpacer_13 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_36->addItem(horizontalSpacer_13);

        label_66 = new QLabel(appconfChukMultiGroup);
        label_66->setObjectName(QStringLiteral("label_66"));

        horizontalLayout_36->addWidget(label_66);

        appconfChukTcErpmBox = new QDoubleSpinBox(appconfChukMultiGroup);
        appconfChukTcErpmBox->setObjectName(QStringLiteral("appconfChukTcErpmBox"));
        appconfChukTcErpmBox->setMaximum(100000);
        appconfChukTcErpmBox->setValue(3000);

        horizontalLayout_36->addWidget(appconfChukTcErpmBox);


        verticalLayout_32->addWidget(appconfChukMultiGroup);

        appconfUpdateChukBox = new QGroupBox(tab_21);
        appconfUpdateChukBox->setObjectName(QStringLiteral("appconfUpdateChukBox"));
        appconfUpdateChukBox->setCheckable(true);
        appconfUpdateChukBox->setChecked(false);
        horizontalLayout_32 = new QHBoxLayout(appconfUpdateChukBox);
        horizontalLayout_32->setSpacing(6);
        horizontalLayout_32->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_32->setObjectName(QStringLiteral("horizontalLayout_32"));
        appconfDecodedChukBar = new QProgressBar(appconfUpdateChukBox);
        appconfDecodedChukBar->setObjectName(QStringLiteral("appconfDecodedChukBar"));
        appconfDecodedChukBar->setMinimum(0);
        appconfDecodedChukBar->setMaximum(1000);
        appconfDecodedChukBar->setValue(0);

        horizontalLayout_32->addWidget(appconfDecodedChukBar);


        verticalLayout_32->addWidget(appconfUpdateChukBox);

        textBrowser = new QTextBrowser(tab_21);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));

        verticalLayout_32->addWidget(textBrowser);

        tabWidget_3->addTab(tab_21, QString());
        tab_25 = new QWidget();
        tab_25->setObjectName(QStringLiteral("tab_25"));
        verticalLayout_37 = new QVBoxLayout(tab_25);
        verticalLayout_37->setSpacing(6);
        verticalLayout_37->setContentsMargins(11, 11, 11, 11);
        verticalLayout_37->setObjectName(QStringLiteral("verticalLayout_37"));
        groupBox_47 = new QGroupBox(tab_25);
        groupBox_47->setObjectName(QStringLiteral("groupBox_47"));
        horizontalLayout_46 = new QHBoxLayout(groupBox_47);
        horizontalLayout_46->setSpacing(6);
        horizontalLayout_46->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_46->setObjectName(QStringLiteral("horizontalLayout_46"));
        appconfNrfSpeed250kButton = new QRadioButton(groupBox_47);
        appconfNrfSpeed250kButton->setObjectName(QStringLiteral("appconfNrfSpeed250kButton"));
        appconfNrfSpeed250kButton->setChecked(true);

        horizontalLayout_46->addWidget(appconfNrfSpeed250kButton);

        appconfNrfSpeed1mButton = new QRadioButton(groupBox_47);
        appconfNrfSpeed1mButton->setObjectName(QStringLiteral("appconfNrfSpeed1mButton"));

        horizontalLayout_46->addWidget(appconfNrfSpeed1mButton);

        appconfNrfSpeed2mButton = new QRadioButton(groupBox_47);
        appconfNrfSpeed2mButton->setObjectName(QStringLiteral("appconfNrfSpeed2mButton"));

        horizontalLayout_46->addWidget(appconfNrfSpeed2mButton);

        horizontalSpacer_33 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_46->addItem(horizontalSpacer_33);


        verticalLayout_37->addWidget(groupBox_47);

        groupBox_48 = new QGroupBox(tab_25);
        groupBox_48->setObjectName(QStringLiteral("groupBox_48"));
        horizontalLayout_47 = new QHBoxLayout(groupBox_48);
        horizontalLayout_47->setSpacing(6);
        horizontalLayout_47->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_47->setObjectName(QStringLiteral("horizontalLayout_47"));
        appconfNrfPowerM18Button = new QRadioButton(groupBox_48);
        appconfNrfPowerM18Button->setObjectName(QStringLiteral("appconfNrfPowerM18Button"));
        appconfNrfPowerM18Button->setChecked(true);

        horizontalLayout_47->addWidget(appconfNrfPowerM18Button);

        appconfNrfPowerM12Button = new QRadioButton(groupBox_48);
        appconfNrfPowerM12Button->setObjectName(QStringLiteral("appconfNrfPowerM12Button"));

        horizontalLayout_47->addWidget(appconfNrfPowerM12Button);

        appconfNrfPowerM6Button = new QRadioButton(groupBox_48);
        appconfNrfPowerM6Button->setObjectName(QStringLiteral("appconfNrfPowerM6Button"));

        horizontalLayout_47->addWidget(appconfNrfPowerM6Button);

        appconfNrfPower0Button = new QRadioButton(groupBox_48);
        appconfNrfPower0Button->setObjectName(QStringLiteral("appconfNrfPower0Button"));

        horizontalLayout_47->addWidget(appconfNrfPower0Button);

        horizontalSpacer_31 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_47->addItem(horizontalSpacer_31);


        verticalLayout_37->addWidget(groupBox_48);

        groupBox_50 = new QGroupBox(tab_25);
        groupBox_50->setObjectName(QStringLiteral("groupBox_50"));
        horizontalLayout_49 = new QHBoxLayout(groupBox_50);
        horizontalLayout_49->setSpacing(6);
        horizontalLayout_49->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_49->setObjectName(QStringLiteral("horizontalLayout_49"));
        appconfNrfCrc1BButton = new QRadioButton(groupBox_50);
        appconfNrfCrc1BButton->setObjectName(QStringLiteral("appconfNrfCrc1BButton"));
        appconfNrfCrc1BButton->setChecked(true);

        horizontalLayout_49->addWidget(appconfNrfCrc1BButton);

        appconfNrfCrc2BButton = new QRadioButton(groupBox_50);
        appconfNrfCrc2BButton->setObjectName(QStringLiteral("appconfNrfCrc2BButton"));

        horizontalLayout_49->addWidget(appconfNrfCrc2BButton);

        horizontalSpacer_32 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_49->addItem(horizontalSpacer_32);


        verticalLayout_37->addWidget(groupBox_50);

        groupBox_49 = new QGroupBox(tab_25);
        groupBox_49->setObjectName(QStringLiteral("groupBox_49"));
        horizontalLayout_48 = new QHBoxLayout(groupBox_49);
        horizontalLayout_48->setSpacing(6);
        horizontalLayout_48->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_48->setObjectName(QStringLiteral("horizontalLayout_48"));
        appconfNrfUseAckBox = new QCheckBox(groupBox_49);
        appconfNrfUseAckBox->setObjectName(QStringLiteral("appconfNrfUseAckBox"));

        horizontalLayout_48->addWidget(appconfNrfUseAckBox);

        label_97 = new QLabel(groupBox_49);
        label_97->setObjectName(QStringLiteral("label_97"));

        horizontalLayout_48->addWidget(label_97);

        appconfNrfRetrBox = new QSpinBox(groupBox_49);
        appconfNrfRetrBox->setObjectName(QStringLiteral("appconfNrfRetrBox"));
        appconfNrfRetrBox->setMaximum(15);

        horizontalLayout_48->addWidget(appconfNrfRetrBox);

        label_99 = new QLabel(groupBox_49);
        label_99->setObjectName(QStringLiteral("label_99"));

        horizontalLayout_48->addWidget(label_99);

        appconfNrfRetrDelayBox = new QComboBox(groupBox_49);
        appconfNrfRetrDelayBox->setObjectName(QStringLiteral("appconfNrfRetrDelayBox"));

        horizontalLayout_48->addWidget(appconfNrfRetrDelayBox);

        horizontalSpacer_30 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_48->addItem(horizontalSpacer_30);


        verticalLayout_37->addWidget(groupBox_49);

        groupBox_51 = new QGroupBox(tab_25);
        groupBox_51->setObjectName(QStringLiteral("groupBox_51"));
        horizontalLayout_50 = new QHBoxLayout(groupBox_51);
        horizontalLayout_50->setSpacing(6);
        horizontalLayout_50->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_50->setObjectName(QStringLiteral("horizontalLayout_50"));
        appconfNrfChannelBox = new QSpinBox(groupBox_51);
        appconfNrfChannelBox->setObjectName(QStringLiteral("appconfNrfChannelBox"));
        appconfNrfChannelBox->setMaximum(125);

        horizontalLayout_50->addWidget(appconfNrfChannelBox);

        horizontalSpacer_34 = new QSpacerItem(836, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_50->addItem(horizontalSpacer_34);


        verticalLayout_37->addWidget(groupBox_51);

        groupBox_52 = new QGroupBox(tab_25);
        groupBox_52->setObjectName(QStringLiteral("groupBox_52"));
        horizontalLayout_51 = new QHBoxLayout(groupBox_52);
        horizontalLayout_51->setSpacing(6);
        horizontalLayout_51->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_51->setObjectName(QStringLiteral("horizontalLayout_51"));
        appconfNrfAddrB0Box = new QSpinBox(groupBox_52);
        appconfNrfAddrB0Box->setObjectName(QStringLiteral("appconfNrfAddrB0Box"));
        appconfNrfAddrB0Box->setMaximum(255);

        horizontalLayout_51->addWidget(appconfNrfAddrB0Box);

        appconfNrfAddrB1Box = new QSpinBox(groupBox_52);
        appconfNrfAddrB1Box->setObjectName(QStringLiteral("appconfNrfAddrB1Box"));
        appconfNrfAddrB1Box->setMaximum(255);

        horizontalLayout_51->addWidget(appconfNrfAddrB1Box);

        appconfNrfAddrB2Box = new QSpinBox(groupBox_52);
        appconfNrfAddrB2Box->setObjectName(QStringLiteral("appconfNrfAddrB2Box"));
        appconfNrfAddrB2Box->setMaximum(255);

        horizontalLayout_51->addWidget(appconfNrfAddrB2Box);

        horizontalSpacer_35 = new QSpacerItem(710, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_51->addItem(horizontalSpacer_35);


        verticalLayout_37->addWidget(groupBox_52);

        verticalSpacer_18 = new QSpacerItem(20, 213, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_37->addItem(verticalSpacer_18);

        tabWidget_3->addTab(tab_25, QString());

        verticalLayout_33->addWidget(tabWidget_3);

        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setSpacing(6);
        horizontalLayout_27->setObjectName(QStringLiteral("horizontalLayout_27"));
        appconfReadButton = new QPushButton(tab_5);
        appconfReadButton->setObjectName(QStringLiteral("appconfReadButton"));

        horizontalLayout_27->addWidget(appconfReadButton);

        appconfReadDefaultButton = new QPushButton(tab_5);
        appconfReadDefaultButton->setObjectName(QStringLiteral("appconfReadDefaultButton"));

        horizontalLayout_27->addWidget(appconfReadDefaultButton);

        appconfWriteButton = new QPushButton(tab_5);
        appconfWriteButton->setObjectName(QStringLiteral("appconfWriteButton"));

        horizontalLayout_27->addWidget(appconfWriteButton);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_27->addItem(horizontalSpacer_9);


        verticalLayout_33->addLayout(horizontalLayout_27);

        tabWidget->addTab(tab_5, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        verticalLayout_17 = new QVBoxLayout(tab_6);
        verticalLayout_17->setSpacing(6);
        verticalLayout_17->setContentsMargins(11, 11, 11, 11);
        verticalLayout_17->setObjectName(QStringLiteral("verticalLayout_17"));
        tabWidget_5 = new QTabWidget(tab_6);
        tabWidget_5->setObjectName(QStringLiteral("tabWidget_5"));
        tab_19 = new QWidget();
        tab_19->setObjectName(QStringLiteral("tab_19"));
        horizontalLayout_29 = new QHBoxLayout(tab_19);
        horizontalLayout_29->setSpacing(6);
        horizontalLayout_29->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_29->setObjectName(QStringLiteral("horizontalLayout_29"));
        realtimePlotRest = new QCustomPlot(tab_19);
        realtimePlotRest->setObjectName(QStringLiteral("realtimePlotRest"));

        horizontalLayout_29->addWidget(realtimePlotRest);

        tabWidget_5->addTab(tab_19, QString());
        tab_20 = new QWidget();
        tab_20->setObjectName(QStringLiteral("tab_20"));
        horizontalLayout_30 = new QHBoxLayout(tab_20);
        horizontalLayout_30->setSpacing(6);
        horizontalLayout_30->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_30->setObjectName(QStringLiteral("horizontalLayout_30"));
        realtimePlotTemperature = new QCustomPlot(tab_20);
        realtimePlotTemperature->setObjectName(QStringLiteral("realtimePlotTemperature"));
        sizePolicy.setHeightForWidth(realtimePlotTemperature->sizePolicy().hasHeightForWidth());
        realtimePlotTemperature->setSizePolicy(sizePolicy);

        horizontalLayout_30->addWidget(realtimePlotTemperature);

        tabWidget_5->addTab(tab_20, QString());
        tab_28 = new QWidget();
        tab_28->setObjectName(QStringLiteral("tab_28"));
        horizontalLayout_52 = new QHBoxLayout(tab_28);
        horizontalLayout_52->setSpacing(6);
        horizontalLayout_52->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_52->setObjectName(QStringLiteral("horizontalLayout_52"));
        realtimePlotRpm = new QCustomPlot(tab_28);
        realtimePlotRpm->setObjectName(QStringLiteral("realtimePlotRpm"));

        horizontalLayout_52->addWidget(realtimePlotRpm);

        tabWidget_5->addTab(tab_28, QString());

        verticalLayout_17->addWidget(tabWidget_5);

        rtDataWidget = new RtDataWidget(tab_6);
        rtDataWidget->setObjectName(QStringLiteral("rtDataWidget"));
        sizePolicy3.setHeightForWidth(rtDataWidget->sizePolicy().hasHeightForWidth());
        rtDataWidget->setSizePolicy(sizePolicy3);
        rtDataWidget->setMinimumSize(QSize(0, 140));

        verticalLayout_17->addWidget(rtDataWidget);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        realtimeAutoScaleBox = new QCheckBox(tab_6);
        realtimeAutoScaleBox->setObjectName(QStringLiteral("realtimeAutoScaleBox"));
        realtimeAutoScaleBox->setChecked(true);

        horizontalLayout_16->addWidget(realtimeAutoScaleBox);

        realtimeActivateBox = new QCheckBox(tab_6);
        realtimeActivateBox->setObjectName(QStringLiteral("realtimeActivateBox"));
        realtimeActivateBox->setTristate(false);

        horizontalLayout_16->addWidget(realtimeActivateBox);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_16->addItem(horizontalSpacer_7);


        verticalLayout_17->addLayout(horizontalLayout_16);

        tabWidget->addTab(tab_6, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        verticalLayout_10 = new QVBoxLayout(tab_2);
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setContentsMargins(11, 11, 11, 11);
        verticalLayout_10->setObjectName(QStringLiteral("verticalLayout_10"));
        voltagePlot = new QCustomPlot(tab_2);
        voltagePlot->setObjectName(QStringLiteral("voltagePlot"));
        sizePolicy2.setHeightForWidth(voltagePlot->sizePolicy().hasHeightForWidth());
        voltagePlot->setSizePolicy(sizePolicy2);

        verticalLayout_10->addWidget(voltagePlot);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        showPh1Box = new QCheckBox(tab_2);
        showPh1Box->setObjectName(QStringLiteral("showPh1Box"));
        showPh1Box->setChecked(true);

        horizontalLayout_4->addWidget(showPh1Box);

        showPh2Box = new QCheckBox(tab_2);
        showPh2Box->setObjectName(QStringLiteral("showPh2Box"));
        showPh2Box->setChecked(true);

        horizontalLayout_4->addWidget(showPh2Box);

        showPh3Box = new QCheckBox(tab_2);
        showPh3Box->setObjectName(QStringLiteral("showPh3Box"));
        showPh3Box->setChecked(true);

        horizontalLayout_4->addWidget(showPh3Box);

        showVirtualGndBox = new QCheckBox(tab_2);
        showVirtualGndBox->setObjectName(QStringLiteral("showVirtualGndBox"));
        showVirtualGndBox->setChecked(true);

        horizontalLayout_4->addWidget(showVirtualGndBox);

        showPosVoltageBox = new QCheckBox(tab_2);
        showPosVoltageBox->setObjectName(QStringLiteral("showPosVoltageBox"));
        showPosVoltageBox->setChecked(true);

        horizontalLayout_4->addWidget(showPosVoltageBox);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);

        truncateBox = new QCheckBox(tab_2);
        truncateBox->setObjectName(QStringLiteral("truncateBox"));

        horizontalLayout_4->addWidget(truncateBox);


        verticalLayout_10->addLayout(horizontalLayout_4);

        tabWidget->addTab(tab_2, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        verticalLayout_19 = new QVBoxLayout(tab);
        verticalLayout_19->setSpacing(6);
        verticalLayout_19->setContentsMargins(11, 11, 11, 11);
        verticalLayout_19->setObjectName(QStringLiteral("verticalLayout_19"));
        tabWidget_2 = new QTabWidget(tab);
        tabWidget_2->setObjectName(QStringLiteral("tabWidget_2"));
        tabWidget_2->setTabPosition(QTabWidget::West);
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        verticalLayout_8 = new QVBoxLayout(tab_7);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        currentPlot = new QCustomPlot(tab_7);
        currentPlot->setObjectName(QStringLiteral("currentPlot"));
        QSizePolicy sizePolicy5(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(currentPlot->sizePolicy().hasHeightForWidth());
        currentPlot->setSizePolicy(sizePolicy5);

        verticalLayout_8->addWidget(currentPlot);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        showCurrent1Box = new QCheckBox(tab_7);
        showCurrent1Box->setObjectName(QStringLiteral("showCurrent1Box"));
        showCurrent1Box->setChecked(true);

        horizontalLayout_14->addWidget(showCurrent1Box);

        showCurrent2Box = new QCheckBox(tab_7);
        showCurrent2Box->setObjectName(QStringLiteral("showCurrent2Box"));
        showCurrent2Box->setChecked(true);

        horizontalLayout_14->addWidget(showCurrent2Box);

        showCurrent3Box = new QCheckBox(tab_7);
        showCurrent3Box->setObjectName(QStringLiteral("showCurrent3Box"));
        showCurrent3Box->setChecked(true);

        horizontalLayout_14->addWidget(showCurrent3Box);

        showTotalCurrentBox = new QCheckBox(tab_7);
        showTotalCurrentBox->setObjectName(QStringLiteral("showTotalCurrentBox"));
        showTotalCurrentBox->setChecked(true);

        horizontalLayout_14->addWidget(showTotalCurrentBox);

        showMcTotalCurrentBox = new QCheckBox(tab_7);
        showMcTotalCurrentBox->setObjectName(QStringLiteral("showMcTotalCurrentBox"));
        showMcTotalCurrentBox->setChecked(true);

        horizontalLayout_14->addWidget(showMcTotalCurrentBox);

        showPosCurrentBox = new QCheckBox(tab_7);
        showPosCurrentBox->setObjectName(QStringLiteral("showPosCurrentBox"));
        showPosCurrentBox->setChecked(true);

        horizontalLayout_14->addWidget(showPosCurrentBox);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer_3);

        currentTimeButton = new QRadioButton(tab_7);
        currentTimeButton->setObjectName(QStringLiteral("currentTimeButton"));
        currentTimeButton->setChecked(true);

        horizontalLayout_14->addWidget(currentTimeButton);

        currentSpectrumButton = new QRadioButton(tab_7);
        currentSpectrumButton->setObjectName(QStringLiteral("currentSpectrumButton"));

        horizontalLayout_14->addWidget(currentSpectrumButton);


        verticalLayout_8->addLayout(horizontalLayout_14);

        tabWidget_2->addTab(tab_7, QString());
        tab_8 = new QWidget();
        tab_8->setObjectName(QStringLiteral("tab_8"));
        verticalLayout_12 = new QVBoxLayout(tab_8);
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setContentsMargins(11, 11, 11, 11);
        verticalLayout_12->setObjectName(QStringLiteral("verticalLayout_12"));
        splitter = new QSplitter(tab_8);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        verticalLayout_7 = new QVBoxLayout(layoutWidget);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        filterResponsePlot = new QCustomPlot(layoutWidget);
        filterResponsePlot->setObjectName(QStringLiteral("filterResponsePlot"));

        verticalLayout_7->addWidget(filterResponsePlot);

        filterLogScaleBox = new QCheckBox(layoutWidget);
        filterLogScaleBox->setObjectName(QStringLiteral("filterLogScaleBox"));

        verticalLayout_7->addWidget(filterLogScaleBox);

        splitter->addWidget(layoutWidget);
        layoutWidget_12 = new QWidget(splitter);
        layoutWidget_12->setObjectName(QStringLiteral("layoutWidget_12"));
        verticalLayout_9 = new QVBoxLayout(layoutWidget_12);
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setContentsMargins(11, 11, 11, 11);
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        filterPlot = new QCustomPlot(layoutWidget_12);
        filterPlot->setObjectName(QStringLiteral("filterPlot"));

        verticalLayout_9->addWidget(filterPlot);

        filterScatterBox = new QCheckBox(layoutWidget_12);
        filterScatterBox->setObjectName(QStringLiteral("filterScatterBox"));

        verticalLayout_9->addWidget(filterScatterBox);

        splitter->addWidget(layoutWidget_12);

        verticalLayout_12->addWidget(splitter);

        tabWidget_2->addTab(tab_8, QString());
        tab_9 = new QWidget();
        tab_9->setObjectName(QStringLiteral("tab_9"));
        verticalLayout_15 = new QVBoxLayout(tab_9);
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setContentsMargins(11, 11, 11, 11);
        verticalLayout_15->setObjectName(QStringLiteral("verticalLayout_15"));
        splitter_2 = new QSplitter(tab_9);
        splitter_2->setObjectName(QStringLiteral("splitter_2"));
        splitter_2->setOrientation(Qt::Horizontal);
        layoutWidget_10 = new QWidget(splitter_2);
        layoutWidget_10->setObjectName(QStringLiteral("layoutWidget_10"));
        verticalLayout_13 = new QVBoxLayout(layoutWidget_10);
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setContentsMargins(11, 11, 11, 11);
        verticalLayout_13->setObjectName(QStringLiteral("verticalLayout_13"));
        verticalLayout_13->setContentsMargins(0, 0, 0, 0);
        filterResponsePlot2 = new QCustomPlot(layoutWidget_10);
        filterResponsePlot2->setObjectName(QStringLiteral("filterResponsePlot2"));

        verticalLayout_13->addWidget(filterResponsePlot2);

        filterLogScaleBox2 = new QCheckBox(layoutWidget_10);
        filterLogScaleBox2->setObjectName(QStringLiteral("filterLogScaleBox2"));

        verticalLayout_13->addWidget(filterLogScaleBox2);

        splitter_2->addWidget(layoutWidget_10);
        layoutWidget2_2 = new QWidget(splitter_2);
        layoutWidget2_2->setObjectName(QStringLiteral("layoutWidget2_2"));
        verticalLayout_14 = new QVBoxLayout(layoutWidget2_2);
        verticalLayout_14->setSpacing(6);
        verticalLayout_14->setContentsMargins(11, 11, 11, 11);
        verticalLayout_14->setObjectName(QStringLiteral("verticalLayout_14"));
        verticalLayout_14->setContentsMargins(0, 0, 0, 0);
        filterPlot2 = new QCustomPlot(layoutWidget2_2);
        filterPlot2->setObjectName(QStringLiteral("filterPlot2"));

        verticalLayout_14->addWidget(filterPlot2);

        filterScatterBox2 = new QCheckBox(layoutWidget2_2);
        filterScatterBox2->setObjectName(QStringLiteral("filterScatterBox2"));

        verticalLayout_14->addWidget(filterScatterBox2);

        splitter_2->addWidget(layoutWidget2_2);

        verticalLayout_15->addWidget(splitter_2);

        tabWidget_2->addTab(tab_9, QString());

        verticalLayout_19->addWidget(tabWidget_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        groupBox_4 = new QGroupBox(tab);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        gridLayout_4 = new QGridLayout(groupBox_4);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        currentFilterActiveBox = new QCheckBox(groupBox_4);
        currentFilterActiveBox->setObjectName(QStringLiteral("currentFilterActiveBox"));

        gridLayout_4->addWidget(currentFilterActiveBox, 0, 0, 1, 1);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        firRadioButton = new QRadioButton(groupBox_4);
        firRadioButton->setObjectName(QStringLiteral("firRadioButton"));
        firRadioButton->setChecked(true);

        horizontalLayout_6->addWidget(firRadioButton);

        meanRadioButton = new QRadioButton(groupBox_4);
        meanRadioButton->setObjectName(QStringLiteral("meanRadioButton"));

        horizontalLayout_6->addWidget(meanRadioButton);


        gridLayout_4->addLayout(horizontalLayout_6, 0, 1, 1, 1);

        compDelayBox = new QCheckBox(groupBox_4);
        compDelayBox->setObjectName(QStringLiteral("compDelayBox"));

        gridLayout_4->addWidget(compDelayBox, 1, 0, 1, 1);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setSpacing(6);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        label_6 = new QLabel(groupBox_4);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayout_3->addWidget(label_6, 0, 0, 1, 1);

        currentFilterFreqBox = new QDoubleSpinBox(groupBox_4);
        currentFilterFreqBox->setObjectName(QStringLiteral("currentFilterFreqBox"));
        currentFilterFreqBox->setDecimals(3);
        currentFilterFreqBox->setMaximum(0.5);
        currentFilterFreqBox->setSingleStep(0.005);
        currentFilterFreqBox->setValue(0.05);

        gridLayout_3->addWidget(currentFilterFreqBox, 0, 1, 1, 1);

        label_7 = new QLabel(groupBox_4);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayout_3->addWidget(label_7, 1, 0, 1, 1);

        currentFilterTapBox = new QSpinBox(groupBox_4);
        currentFilterTapBox->setObjectName(QStringLiteral("currentFilterTapBox"));
        currentFilterTapBox->setMinimum(1);
        currentFilterTapBox->setMaximum(10);
        currentFilterTapBox->setValue(6);

        gridLayout_3->addWidget(currentFilterTapBox, 1, 1, 1, 1);


        gridLayout_4->addLayout(gridLayout_3, 1, 1, 2, 1);

        hammingBox = new QCheckBox(groupBox_4);
        hammingBox->setObjectName(QStringLiteral("hammingBox"));

        gridLayout_4->addWidget(hammingBox, 2, 0, 1, 1);


        horizontalLayout_3->addWidget(groupBox_4);

        groupBox_7 = new QGroupBox(tab);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        gridLayout_5 = new QGridLayout(groupBox_7);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        currentFilterActiveBox2 = new QCheckBox(groupBox_7);
        currentFilterActiveBox2->setObjectName(QStringLiteral("currentFilterActiveBox2"));

        gridLayout_5->addWidget(currentFilterActiveBox2, 0, 0, 1, 1);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        firRadioButton2 = new QRadioButton(groupBox_7);
        firRadioButton2->setObjectName(QStringLiteral("firRadioButton2"));
        firRadioButton2->setChecked(true);

        horizontalLayout_11->addWidget(firRadioButton2);

        meanRadioButton2 = new QRadioButton(groupBox_7);
        meanRadioButton2->setObjectName(QStringLiteral("meanRadioButton2"));

        horizontalLayout_11->addWidget(meanRadioButton2);


        gridLayout_5->addLayout(horizontalLayout_11, 0, 1, 1, 1);

        gridLayout_6 = new QGridLayout();
        gridLayout_6->setSpacing(6);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        label_8 = new QLabel(groupBox_7);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayout_6->addWidget(label_8, 0, 0, 1, 1);

        currentFilterFreqBox2 = new QDoubleSpinBox(groupBox_7);
        currentFilterFreqBox2->setObjectName(QStringLiteral("currentFilterFreqBox2"));
        currentFilterFreqBox2->setDecimals(3);
        currentFilterFreqBox2->setMaximum(0.5);
        currentFilterFreqBox2->setSingleStep(0.005);
        currentFilterFreqBox2->setValue(0.05);

        gridLayout_6->addWidget(currentFilterFreqBox2, 0, 1, 1, 1);

        label_9 = new QLabel(groupBox_7);
        label_9->setObjectName(QStringLiteral("label_9"));

        gridLayout_6->addWidget(label_9, 1, 0, 1, 1);

        currentFilterTapBox2 = new QSpinBox(groupBox_7);
        currentFilterTapBox2->setObjectName(QStringLiteral("currentFilterTapBox2"));
        currentFilterTapBox2->setMinimum(1);
        currentFilterTapBox2->setMaximum(10);
        currentFilterTapBox2->setValue(6);

        gridLayout_6->addWidget(currentFilterTapBox2, 1, 1, 1, 1);


        gridLayout_5->addLayout(gridLayout_6, 1, 1, 2, 1);

        hammingBox2 = new QCheckBox(groupBox_7);
        hammingBox2->setObjectName(QStringLiteral("hammingBox2"));

        gridLayout_5->addWidget(hammingBox2, 2, 0, 1, 1);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        label_10 = new QLabel(groupBox_7);
        label_10->setObjectName(QStringLiteral("label_10"));

        horizontalLayout_12->addWidget(label_10);

        decimationSpinBox = new QSpinBox(groupBox_7);
        decimationSpinBox->setObjectName(QStringLiteral("decimationSpinBox"));
        decimationSpinBox->setMinimum(1);
        decimationSpinBox->setMaximum(20);
        decimationSpinBox->setValue(8);

        horizontalLayout_12->addWidget(decimationSpinBox);


        gridLayout_5->addLayout(horizontalLayout_12, 1, 0, 1, 1);


        horizontalLayout_3->addWidget(groupBox_7);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer);


        horizontalLayout_3->addLayout(horizontalLayout_10);


        verticalLayout_19->addLayout(horizontalLayout_3);

        tabWidget->addTab(tab, QString());
        tab_15 = new QWidget();
        tab_15->setObjectName(QStringLiteral("tab_15"));
        verticalLayout_21 = new QVBoxLayout(tab_15);
        verticalLayout_21->setSpacing(6);
        verticalLayout_21->setContentsMargins(11, 11, 11, 11);
        verticalLayout_21->setObjectName(QStringLiteral("verticalLayout_21"));
        widget_2 = new QWidget(tab_15);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        QSizePolicy sizePolicy6(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy6.setHorizontalStretch(1);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(widget_2->sizePolicy().hasHeightForWidth());
        widget_2->setSizePolicy(sizePolicy6);
        verticalLayout_4 = new QVBoxLayout(widget_2);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        terminalBrowser = new QTextBrowser(widget_2);
        terminalBrowser->setObjectName(QStringLiteral("terminalBrowser"));
        QSizePolicy sizePolicy7(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy7.setHorizontalStretch(0);
        sizePolicy7.setVerticalStretch(0);
        sizePolicy7.setHeightForWidth(terminalBrowser->sizePolicy().hasHeightForWidth());
        terminalBrowser->setSizePolicy(sizePolicy7);
        QFont font;
        font.setFamily(QStringLiteral("Monospace"));
        terminalBrowser->setFont(font);

        verticalLayout_4->addWidget(terminalBrowser);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        terminalEdit = new QLineEdit(widget_2);
        terminalEdit->setObjectName(QStringLiteral("terminalEdit"));

        horizontalLayout_15->addWidget(terminalEdit);

        sendTerminalButton = new QPushButton(widget_2);
        sendTerminalButton->setObjectName(QStringLiteral("sendTerminalButton"));

        horizontalLayout_15->addWidget(sendTerminalButton);

        clearTerminalButton = new QPushButton(widget_2);
        clearTerminalButton->setObjectName(QStringLiteral("clearTerminalButton"));

        horizontalLayout_15->addWidget(clearTerminalButton);


        verticalLayout_4->addLayout(horizontalLayout_15);


        verticalLayout_21->addWidget(widget_2);

        tabWidget->addTab(tab_15, QString());
        tab_23 = new QWidget();
        tab_23->setObjectName(QStringLiteral("tab_23"));
        verticalLayout_18 = new QVBoxLayout(tab_23);
        verticalLayout_18->setSpacing(6);
        verticalLayout_18->setContentsMargins(11, 11, 11, 11);
        verticalLayout_18->setObjectName(QStringLiteral("verticalLayout_18"));
        groupBox_23 = new QGroupBox(tab_23);
        groupBox_23->setObjectName(QStringLiteral("groupBox_23"));
        gridLayout_34 = new QGridLayout(groupBox_23);
        gridLayout_34->setSpacing(6);
        gridLayout_34->setContentsMargins(11, 11, 11, 11);
        gridLayout_34->setObjectName(QStringLiteral("gridLayout_34"));
        label_81 = new QLabel(groupBox_23);
        label_81->setObjectName(QStringLiteral("label_81"));

        gridLayout_34->addWidget(label_81, 0, 0, 1, 1);

        firmwareUploadButton = new QPushButton(groupBox_23);
        firmwareUploadButton->setObjectName(QStringLiteral("firmwareUploadButton"));

        gridLayout_34->addWidget(firmwareUploadButton, 1, 3, 1, 1);

        firmwareUploadStatusLabel = new QLabel(groupBox_23);
        firmwareUploadStatusLabel->setObjectName(QStringLiteral("firmwareUploadStatusLabel"));

        gridLayout_34->addWidget(firmwareUploadStatusLabel, 2, 0, 1, 2);

        firmwareBar = new QProgressBar(groupBox_23);
        firmwareBar->setObjectName(QStringLiteral("firmwareBar"));
        firmwareBar->setMaximum(1000);
        firmwareBar->setValue(0);

        gridLayout_34->addWidget(firmwareBar, 1, 0, 1, 2);

        firmwareEdit = new QLineEdit(groupBox_23);
        firmwareEdit->setObjectName(QStringLiteral("firmwareEdit"));

        gridLayout_34->addWidget(firmwareEdit, 0, 1, 1, 1);

        firmwareCancelButton = new QPushButton(groupBox_23);
        firmwareCancelButton->setObjectName(QStringLiteral("firmwareCancelButton"));

        gridLayout_34->addWidget(firmwareCancelButton, 1, 2, 1, 1);

        firmwareChooseButton = new QPushButton(groupBox_23);
        firmwareChooseButton->setObjectName(QStringLiteral("firmwareChooseButton"));

        gridLayout_34->addWidget(firmwareChooseButton, 0, 2, 1, 2);


        verticalLayout_18->addWidget(groupBox_23);

        groupBox_26 = new QGroupBox(tab_23);
        groupBox_26->setObjectName(QStringLiteral("groupBox_26"));
        horizontalLayout_9 = new QHBoxLayout(groupBox_26);
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        label_82 = new QLabel(groupBox_26);
        label_82->setObjectName(QStringLiteral("label_82"));

        horizontalLayout_9->addWidget(label_82);

        firmwareVersionLabel = new QLabel(groupBox_26);
        firmwareVersionLabel->setObjectName(QStringLiteral("firmwareVersionLabel"));

        horizontalLayout_9->addWidget(firmwareVersionLabel);

        horizontalSpacer_19 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_9->addItem(horizontalSpacer_19);

        firmwareVersionReadButton = new QPushButton(groupBox_26);
        firmwareVersionReadButton->setObjectName(QStringLiteral("firmwareVersionReadButton"));

        horizontalLayout_9->addWidget(firmwareVersionReadButton);


        verticalLayout_18->addWidget(groupBox_26);

        groupBox_32 = new QGroupBox(tab_23);
        groupBox_32->setObjectName(QStringLiteral("groupBox_32"));
        horizontalLayout_42 = new QHBoxLayout(groupBox_32);
        horizontalLayout_42->setSpacing(6);
        horizontalLayout_42->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_42->setObjectName(QStringLiteral("horizontalLayout_42"));
        firmwareSupportedLabel = new QLabel(groupBox_32);
        firmwareSupportedLabel->setObjectName(QStringLiteral("firmwareSupportedLabel"));

        horizontalLayout_42->addWidget(firmwareSupportedLabel);


        verticalLayout_18->addWidget(groupBox_32);

        verticalSpacer_15 = new QSpacerItem(20, 508, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_18->addItem(verticalSpacer_15);

        tabWidget->addTab(tab_23, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        verticalLayout_5 = new QVBoxLayout(tab_3);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        gridLayout_8 = new QGridLayout();
        gridLayout_8->setSpacing(6);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        detectButton = new QPushButton(tab_3);
        detectButton->setObjectName(QStringLiteral("detectButton"));

        gridLayout_8->addWidget(detectButton, 0, 0, 1, 1);

        stopDetectButton = new QPushButton(tab_3);
        stopDetectButton->setObjectName(QStringLiteral("stopDetectButton"));

        gridLayout_8->addWidget(stopDetectButton, 0, 7, 1, 1);

        detectPidPosErrorButton = new QPushButton(tab_3);
        detectPidPosErrorButton->setObjectName(QStringLiteral("detectPidPosErrorButton"));

        gridLayout_8->addWidget(detectPidPosErrorButton, 0, 4, 1, 1);

        detectEncoderButton = new QPushButton(tab_3);
        detectEncoderButton->setObjectName(QStringLiteral("detectEncoderButton"));

        gridLayout_8->addWidget(detectEncoderButton, 0, 2, 1, 1);

        detectObserverButton = new QPushButton(tab_3);
        detectObserverButton->setObjectName(QStringLiteral("detectObserverButton"));

        gridLayout_8->addWidget(detectObserverButton, 0, 1, 1, 1);

        detectEncoderObserverErrorButton = new QPushButton(tab_3);
        detectEncoderObserverErrorButton->setObjectName(QStringLiteral("detectEncoderObserverErrorButton"));

        gridLayout_8->addWidget(detectEncoderObserverErrorButton, 0, 5, 1, 1);

        horizontalSpacer_36 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_8->addItem(horizontalSpacer_36, 0, 6, 1, 1);

        detectPidPosButton = new QPushButton(tab_3);
        detectPidPosButton->setObjectName(QStringLiteral("detectPidPosButton"));

        gridLayout_8->addWidget(detectPidPosButton, 0, 3, 1, 1);


        verticalLayout_5->addLayout(gridLayout_8);

        rotorPosBar = new QProgressBar(tab_3);
        rotorPosBar->setObjectName(QStringLiteral("rotorPosBar"));
        rotorPosBar->setMaximum(359);
        rotorPosBar->setValue(120);

        verticalLayout_5->addWidget(rotorPosBar);

        realtimePlotPosition = new QCustomPlot(tab_3);
        realtimePlotPosition->setObjectName(QStringLiteral("realtimePlotPosition"));
        sizePolicy2.setHeightForWidth(realtimePlotPosition->sizePolicy().hasHeightForWidth());
        realtimePlotPosition->setSizePolicy(sizePolicy2);

        verticalLayout_5->addWidget(realtimePlotPosition);

        tabWidget->addTab(tab_3, QString());
        tab_10 = new QWidget();
        tab_10->setObjectName(QStringLiteral("tab_10"));
        verticalLayout_22 = new QVBoxLayout(tab_10);
        verticalLayout_22->setSpacing(6);
        verticalLayout_22->setContentsMargins(11, 11, 11, 11);
        verticalLayout_22->setObjectName(QStringLiteral("verticalLayout_22"));
        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        experimentSampleLabel = new QLabel(tab_10);
        experimentSampleLabel->setObjectName(QStringLiteral("experimentSampleLabel"));

        horizontalLayout_7->addWidget(experimentSampleLabel);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_4);

        experimentClearSamplesButton = new QPushButton(tab_10);
        experimentClearSamplesButton->setObjectName(QStringLiteral("experimentClearSamplesButton"));

        horizontalLayout_7->addWidget(experimentClearSamplesButton);

        experimentSaveSamplesButton = new QPushButton(tab_10);
        experimentSaveSamplesButton->setObjectName(QStringLiteral("experimentSaveSamplesButton"));

        horizontalLayout_7->addWidget(experimentSaveSamplesButton);


        verticalLayout_22->addLayout(horizontalLayout_7);

        experimentBrowser = new QTextBrowser(tab_10);
        experimentBrowser->setObjectName(QStringLiteral("experimentBrowser"));

        verticalLayout_22->addWidget(experimentBrowser);

        groupBox_6 = new QGroupBox(tab_10);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        verticalLayout_11 = new QVBoxLayout(groupBox_6);
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setContentsMargins(11, 11, 11, 11);
        verticalLayout_11->setObjectName(QStringLiteral("verticalLayout_11"));
        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        label_14 = new QLabel(groupBox_6);
        label_14->setObjectName(QStringLiteral("label_14"));

        horizontalLayout_13->addWidget(label_14);

        experimentPathEdit = new QLineEdit(groupBox_6);
        experimentPathEdit->setObjectName(QStringLiteral("experimentPathEdit"));

        horizontalLayout_13->addWidget(experimentPathEdit);


        verticalLayout_11->addLayout(horizontalLayout_13);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        experimentAutosaveBox = new QCheckBox(groupBox_6);
        experimentAutosaveBox->setObjectName(QStringLiteral("experimentAutosaveBox"));

        horizontalLayout_8->addWidget(experimentAutosaveBox);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_5);

        label_13 = new QLabel(groupBox_6);
        label_13->setObjectName(QStringLiteral("label_13"));

        horizontalLayout_8->addWidget(label_13);

        experimentAutosaveIntervalBox = new QSpinBox(groupBox_6);
        experimentAutosaveIntervalBox->setObjectName(QStringLiteral("experimentAutosaveIntervalBox"));
        experimentAutosaveIntervalBox->setMaximum(1000000);
        experimentAutosaveIntervalBox->setValue(1000);

        horizontalLayout_8->addWidget(experimentAutosaveIntervalBox);

        label_15 = new QLabel(groupBox_6);
        label_15->setObjectName(QStringLiteral("label_15"));

        horizontalLayout_8->addWidget(label_15);


        verticalLayout_11->addLayout(horizontalLayout_8);


        verticalLayout_22->addWidget(groupBox_6);

        groupBox_35 = new QGroupBox(tab_10);
        groupBox_35->setObjectName(QStringLiteral("groupBox_35"));
        horizontalLayout_2 = new QHBoxLayout(groupBox_35);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        servoOutputSlider = new QSlider(groupBox_35);
        servoOutputSlider->setObjectName(QStringLiteral("servoOutputSlider"));
        servoOutputSlider->setMaximum(1000);
        servoOutputSlider->setValue(500);
        servoOutputSlider->setOrientation(Qt::Horizontal);
        servoOutputSlider->setInvertedAppearance(false);
        servoOutputSlider->setInvertedControls(false);
        servoOutputSlider->setTickPosition(QSlider::NoTicks);

        horizontalLayout_2->addWidget(servoOutputSlider);

        servoOutputNumber = new QLCDNumber(groupBox_35);
        servoOutputNumber->setObjectName(QStringLiteral("servoOutputNumber"));
        servoOutputNumber->setDigitCount(5);
        servoOutputNumber->setProperty("value", QVariant(0.5));

        horizontalLayout_2->addWidget(servoOutputNumber);


        verticalLayout_22->addWidget(groupBox_35);

        tabWidget->addTab(tab_10, QString());

        verticalLayout_6->addWidget(tabWidget);


        horizontalLayout->addLayout(verticalLayout_6);

        widget2 = new QWidget(centralWidget);
        widget2->setObjectName(QStringLiteral("widget2"));
        verticalLayout_26 = new QVBoxLayout(widget2);
        verticalLayout_26->setSpacing(6);
        verticalLayout_26->setContentsMargins(11, 11, 11, 11);
        verticalLayout_26->setObjectName(QStringLiteral("verticalLayout_26"));
        toolBox = new QToolBox(widget2);
        toolBox->setObjectName(QStringLiteral("toolBox"));
        sizePolicy3.setHeightForWidth(toolBox->sizePolicy().hasHeightForWidth());
        toolBox->setSizePolicy(sizePolicy3);
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        page->setGeometry(QRect(0, 0, 248, 82));
        gridLayout_49 = new QGridLayout(page);
        gridLayout_49->setSpacing(6);
        gridLayout_49->setContentsMargins(11, 11, 11, 11);
        gridLayout_49->setObjectName(QStringLiteral("gridLayout_49"));
        serialCombobox = new QComboBox(page);
        serialCombobox->setObjectName(QStringLiteral("serialCombobox"));
        QSizePolicy sizePolicy8(QSizePolicy::MinimumExpanding, QSizePolicy::Fixed);
        sizePolicy8.setHorizontalStretch(0);
        sizePolicy8.setVerticalStretch(0);
        sizePolicy8.setHeightForWidth(serialCombobox->sizePolicy().hasHeightForWidth());
        serialCombobox->setSizePolicy(sizePolicy8);

        gridLayout_49->addWidget(serialCombobox, 0, 0, 1, 2);

        refreshButton = new QPushButton(page);
        refreshButton->setObjectName(QStringLiteral("refreshButton"));
        QSizePolicy sizePolicy9(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy9.setHorizontalStretch(0);
        sizePolicy9.setVerticalStretch(0);
        sizePolicy9.setHeightForWidth(refreshButton->sizePolicy().hasHeightForWidth());
        refreshButton->setSizePolicy(sizePolicy9);
        QIcon icon;
        icon.addFile(QStringLiteral(":/res/refresh.png"), QSize(), QIcon::Normal, QIcon::Off);
        refreshButton->setIcon(icon);

        gridLayout_49->addWidget(refreshButton, 1, 0, 1, 1);

        serialConnectButton = new QPushButton(page);
        serialConnectButton->setObjectName(QStringLiteral("serialConnectButton"));

        gridLayout_49->addWidget(serialConnectButton, 1, 1, 1, 1);

        toolBox->addItem(page, QStringLiteral("Serial Connection"));
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        page_2->setGeometry(QRect(0, 0, 248, 82));
        gridLayout_50 = new QGridLayout(page_2);
        gridLayout_50->setSpacing(6);
        gridLayout_50->setContentsMargins(11, 11, 11, 11);
        gridLayout_50->setObjectName(QStringLiteral("gridLayout_50"));
        udpIpEdit = new QLineEdit(page_2);
        udpIpEdit->setObjectName(QStringLiteral("udpIpEdit"));

        gridLayout_50->addWidget(udpIpEdit, 0, 0, 1, 1);

        udpConnectButton = new QPushButton(page_2);
        udpConnectButton->setObjectName(QStringLiteral("udpConnectButton"));

        gridLayout_50->addWidget(udpConnectButton, 1, 0, 1, 1);

        toolBox->addItem(page_2, QStringLiteral("UDP Connection"));

        verticalLayout_26->addWidget(toolBox);

        gridLayout_28 = new QGridLayout();
        gridLayout_28->setSpacing(6);
        gridLayout_28->setObjectName(QStringLiteral("gridLayout_28"));
        disconnectButton = new QPushButton(widget2);
        disconnectButton->setObjectName(QStringLiteral("disconnectButton"));

        gridLayout_28->addWidget(disconnectButton, 0, 0, 1, 2);

        appconfRebootButton = new QPushButton(widget2);
        appconfRebootButton->setObjectName(QStringLiteral("appconfRebootButton"));

        gridLayout_28->addWidget(appconfRebootButton, 0, 2, 1, 1);

        canIdBox = new QSpinBox(widget2);
        canIdBox->setObjectName(QStringLiteral("canIdBox"));

        gridLayout_28->addWidget(canIdBox, 1, 0, 1, 1);

        canFwdBox = new QCheckBox(widget2);
        canFwdBox->setObjectName(QStringLiteral("canFwdBox"));

        gridLayout_28->addWidget(canFwdBox, 1, 1, 1, 2);


        verticalLayout_26->addLayout(gridLayout_28);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_26->addItem(verticalSpacer);

        tabWidget_6 = new QTabWidget(widget2);
        tabWidget_6->setObjectName(QStringLiteral("tabWidget_6"));
        tab_26 = new QWidget();
        tab_26->setObjectName(QStringLiteral("tab_26"));
        verticalLayout_2 = new QVBoxLayout(tab_26);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        groupBox_2 = new QGroupBox(tab_26);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        gridLayout_2 = new QGridLayout(groupBox_2);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        dutyBox = new QDoubleSpinBox(groupBox_2);
        dutyBox->setObjectName(QStringLiteral("dutyBox"));
        dutyBox->setMinimum(-1);
        dutyBox->setMaximum(1);
        dutyBox->setSingleStep(0.01);
        dutyBox->setValue(0.2);

        gridLayout_2->addWidget(dutyBox, 0, 0, 1, 1);

        dutyButton = new QPushButton(groupBox_2);
        dutyButton->setObjectName(QStringLiteral("dutyButton"));

        gridLayout_2->addWidget(dutyButton, 0, 1, 1, 1);

        rpmBox = new QSpinBox(groupBox_2);
        rpmBox->setObjectName(QStringLiteral("rpmBox"));
        rpmBox->setMinimum(-100000);
        rpmBox->setMaximum(100000);
        rpmBox->setSingleStep(1000);
        rpmBox->setValue(15000);

        gridLayout_2->addWidget(rpmBox, 1, 0, 1, 1);

        rpmButton = new QPushButton(groupBox_2);
        rpmButton->setObjectName(QStringLiteral("rpmButton"));

        gridLayout_2->addWidget(rpmButton, 1, 1, 1, 1);

        currentBox = new QDoubleSpinBox(groupBox_2);
        currentBox->setObjectName(QStringLiteral("currentBox"));
        currentBox->setDecimals(1);
        currentBox->setMinimum(-200);
        currentBox->setMaximum(200);
        currentBox->setSingleStep(0.5);
        currentBox->setValue(3);

        gridLayout_2->addWidget(currentBox, 2, 0, 1, 1);

        currentButton = new QPushButton(groupBox_2);
        currentButton->setObjectName(QStringLiteral("currentButton"));

        gridLayout_2->addWidget(currentButton, 2, 1, 1, 1);

        currentBrakeButton = new QPushButton(groupBox_2);
        currentBrakeButton->setObjectName(QStringLiteral("currentBrakeButton"));

        gridLayout_2->addWidget(currentBrakeButton, 3, 1, 1, 1);

        posCtrlButton = new QPushButton(groupBox_2);
        posCtrlButton->setObjectName(QStringLiteral("posCtrlButton"));

        gridLayout_2->addWidget(posCtrlButton, 4, 1, 1, 1);

        currentBrakeBox = new QDoubleSpinBox(groupBox_2);
        currentBrakeBox->setObjectName(QStringLiteral("currentBrakeBox"));
        currentBrakeBox->setDecimals(1);
        currentBrakeBox->setMinimum(0);
        currentBrakeBox->setMaximum(200);
        currentBrakeBox->setSingleStep(0.5);
        currentBrakeBox->setValue(3);

        gridLayout_2->addWidget(currentBrakeBox, 3, 0, 1, 1);

        posCtrlBox = new QDoubleSpinBox(groupBox_2);
        posCtrlBox->setObjectName(QStringLiteral("posCtrlBox"));
        posCtrlBox->setDecimals(3);
        posCtrlBox->setMaximum(360);

        gridLayout_2->addWidget(posCtrlBox, 4, 0, 1, 1);

        overrideKbBox = new QCheckBox(groupBox_2);
        overrideKbBox->setObjectName(QStringLiteral("overrideKbBox"));
        overrideKbBox->setChecked(true);

        gridLayout_2->addWidget(overrideKbBox, 5, 0, 1, 1);

        arrowCurrentBox = new QDoubleSpinBox(groupBox_2);
        arrowCurrentBox->setObjectName(QStringLiteral("arrowCurrentBox"));
        arrowCurrentBox->setDecimals(1);
        arrowCurrentBox->setMaximum(200);
        arrowCurrentBox->setSingleStep(0.5);
        arrowCurrentBox->setValue(3);

        gridLayout_2->addWidget(arrowCurrentBox, 5, 1, 1, 1);

        offBrakeButton = new QPushButton(groupBox_2);
        offBrakeButton->setObjectName(QStringLiteral("offBrakeButton"));

        gridLayout_2->addWidget(offBrakeButton, 6, 0, 1, 2);


        verticalLayout_2->addWidget(groupBox_2);

        tabWidget_6->addTab(tab_26, QString());
        tab_27 = new QWidget();
        tab_27->setObjectName(QStringLiteral("tab_27"));
        verticalLayout_38 = new QVBoxLayout(tab_27);
        verticalLayout_38->setSpacing(6);
        verticalLayout_38->setContentsMargins(11, 11, 11, 11);
        verticalLayout_38->setObjectName(QStringLiteral("verticalLayout_38"));
        groupBox = new QGroupBox(tab_27);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));

        gridLayout->addWidget(label, 1, 0, 1, 1);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayout->addWidget(label_2, 2, 0, 1, 1);

        sampleNumBox = new QSpinBox(groupBox);
        sampleNumBox->setObjectName(QStringLiteral("sampleNumBox"));
        sampleNumBox->setMinimum(10);
        sampleNumBox->setMaximum(2000);
        sampleNumBox->setSingleStep(100);
        sampleNumBox->setValue(1000);

        gridLayout->addWidget(sampleNumBox, 1, 1, 1, 1);

        sampleFreqBox = new QSpinBox(groupBox);
        sampleFreqBox->setObjectName(QStringLiteral("sampleFreqBox"));
        sampleFreqBox->setMinimum(1);
        sampleFreqBox->setMaximum(200000);
        sampleFreqBox->setSingleStep(1000);
        sampleFreqBox->setValue(40000);

        gridLayout->addWidget(sampleFreqBox, 3, 1, 1, 1);

        sampleIntBox = new QSpinBox(groupBox);
        sampleIntBox->setObjectName(QStringLiteral("sampleIntBox"));
        sampleIntBox->setMinimum(1);

        gridLayout->addWidget(sampleIntBox, 2, 1, 1, 1);

        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayout->addWidget(label_5, 3, 0, 1, 1);

        getDataButton = new QPushButton(groupBox);
        getDataButton->setObjectName(QStringLiteral("getDataButton"));

        gridLayout->addWidget(getDataButton, 0, 0, 1, 1);

        getDataStartButton = new QPushButton(groupBox);
        getDataStartButton->setObjectName(QStringLiteral("getDataStartButton"));

        gridLayout->addWidget(getDataStartButton, 0, 1, 1, 1);


        verticalLayout->addLayout(gridLayout);


        verticalLayout_38->addWidget(groupBox);

        groupBox_5 = new QGroupBox(tab_27);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        gridLayout_27 = new QGridLayout(groupBox_5);
        gridLayout_27->setSpacing(6);
        gridLayout_27->setContentsMargins(11, 11, 11, 11);
        gridLayout_27->setObjectName(QStringLiteral("gridLayout_27"));
        horizontalZoomBox = new QCheckBox(groupBox_5);
        horizontalZoomBox->setObjectName(QStringLiteral("horizontalZoomBox"));
        horizontalZoomBox->setCheckable(true);
        horizontalZoomBox->setChecked(true);

        gridLayout_27->addWidget(horizontalZoomBox, 0, 0, 1, 1);

        verticalZoomBox = new QCheckBox(groupBox_5);
        verticalZoomBox->setObjectName(QStringLiteral("verticalZoomBox"));
        verticalZoomBox->setChecked(true);

        gridLayout_27->addWidget(verticalZoomBox, 0, 1, 1, 1);

        rescaleButton = new QPushButton(groupBox_5);
        rescaleButton->setObjectName(QStringLiteral("rescaleButton"));

        gridLayout_27->addWidget(rescaleButton, 1, 0, 1, 1);

        replotButton = new QPushButton(groupBox_5);
        replotButton->setObjectName(QStringLiteral("replotButton"));

        gridLayout_27->addWidget(replotButton, 1, 1, 1, 1);

        verticalSpacer_19 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_27->addItem(verticalSpacer_19, 2, 1, 1, 1);


        verticalLayout_38->addWidget(groupBox_5);

        tabWidget_6->addTab(tab_27, QString());

        verticalLayout_26->addWidget(tabWidget_6);

        offButton = new QPushButton(widget2);
        offButton->setObjectName(QStringLiteral("offButton"));
        offButton->setMinimumSize(QSize(0, 50));
        QFont font1;
        font1.setPointSize(15);
        font1.setBold(true);
        font1.setWeight(75);
        offButton->setFont(font1);

        verticalLayout_26->addWidget(offButton);


        horizontalLayout->addWidget(widget2);

        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        QWidget::setTabOrder(mcconfLimCurrentMaxBox, mcconfLimCurrentMinBox);
        QWidget::setTabOrder(mcconfLimCurrentMinBox, mcconfLimCurrentInMaxBox);
        QWidget::setTabOrder(mcconfLimCurrentInMaxBox, mcconfLimCurrentInMinBox);
        QWidget::setTabOrder(mcconfLimCurrentInMinBox, mcconfLimCurrentAbsMaxBox);
        QWidget::setTabOrder(mcconfLimCurrentAbsMaxBox, mcconfLimMinErpmBox);
        QWidget::setTabOrder(mcconfLimMinErpmBox, mcconfLimMaxErpmBox);
        QWidget::setTabOrder(mcconfLimMaxErpmBox, mcconfLimMaxErpmFbrakeBox);
        QWidget::setTabOrder(mcconfLimMaxErpmFbrakeBox, mcconfLimMaxErpmFbrakeCcBox);
        QWidget::setTabOrder(mcconfLimMaxErpmFbrakeCcBox, mcconfLimTempFetStartBox);
        QWidget::setTabOrder(mcconfLimTempFetStartBox, mcconfLimTempFetEndBox);
        QWidget::setTabOrder(mcconfLimTempFetEndBox, mcconfLimTempMotorStartBox);
        QWidget::setTabOrder(mcconfLimTempMotorStartBox, mcconfLimTempMotorEndBox);
        QWidget::setTabOrder(mcconfLimTempMotorEndBox, mcconfLimMinVinBox);
        QWidget::setTabOrder(mcconfLimMinVinBox, mcconfLimMaxVinBox);
        QWidget::setTabOrder(mcconfLimMaxVinBox, mcconfSlMinErpmBox);
        QWidget::setTabOrder(mcconfSlMinErpmBox, mcconfSlMinErpmIlBox);
        QWidget::setTabOrder(mcconfSlMinErpmIlBox, mcconfSlMaxFbCurrBox);
        QWidget::setTabOrder(mcconfSlMaxFbCurrBox, mcconfSlIntLimBox);
        QWidget::setTabOrder(mcconfSlIntLimBox, mcconfSlIntLimScaleBrBox);
        QWidget::setTabOrder(mcconfSlIntLimScaleBrBox, mcconfSlBrErpmBox);
        QWidget::setTabOrder(mcconfSlBrErpmBox, mcconfSlBemfKBox);
        QWidget::setTabOrder(mcconfSlBemfKBox, mcconfHallTab0Box);
        QWidget::setTabOrder(mcconfHallTab0Box, mcconfHallTab1Box);
        QWidget::setTabOrder(mcconfHallTab1Box, mcconfHallTab2Box);
        QWidget::setTabOrder(mcconfHallTab2Box, mcconfHallTab3Box);
        QWidget::setTabOrder(mcconfHallTab3Box, mcconfHallTab4Box);
        QWidget::setTabOrder(mcconfHallTab4Box, mcconfHallTab5Box);
        QWidget::setTabOrder(mcconfHallTab5Box, mcconfHallTab6Box);
        QWidget::setTabOrder(mcconfHallTab6Box, mcconfHallTab7Box);
        QWidget::setTabOrder(mcconfHallTab7Box, mcconfHallSlErpmBox);
        QWidget::setTabOrder(mcconfHallSlErpmBox, sampleNumBox);
        QWidget::setTabOrder(sampleNumBox, sampleIntBox);
        QWidget::setTabOrder(sampleIntBox, horizontalZoomBox);
        QWidget::setTabOrder(horizontalZoomBox, verticalZoomBox);
        QWidget::setTabOrder(verticalZoomBox, rescaleButton);
        QWidget::setTabOrder(rescaleButton, replotButton);
        QWidget::setTabOrder(replotButton, filterLogScaleBox);
        QWidget::setTabOrder(filterLogScaleBox, mcconfSensorModeSensorlessButton);
        QWidget::setTabOrder(mcconfSensorModeSensorlessButton, mcconfSensorModeSensoredButton);
        QWidget::setTabOrder(mcconfSensorModeSensoredButton, mcconfSensorModeHybridButton);
        QWidget::setTabOrder(mcconfSensorModeHybridButton, mcconfCommIntButton);
        QWidget::setTabOrder(mcconfCommIntButton, mcconfCommDelayButton);
        QWidget::setTabOrder(mcconfCommDelayButton, sampleFreqBox);
        QWidget::setTabOrder(sampleFreqBox, mcconfTypeDcButton);
        QWidget::setTabOrder(mcconfTypeDcButton, tabWidget_4);
        QWidget::setTabOrder(tabWidget_4, currentFilterTapBox);
        QWidget::setTabOrder(currentFilterTapBox, mcconfTypeBldcButton);
        QWidget::setTabOrder(mcconfTypeBldcButton, dutyBox);
        QWidget::setTabOrder(dutyBox, currentFilterFreqBox);
        QWidget::setTabOrder(currentFilterFreqBox, mcconfLimCurrentSlowAbsMaxBox);
        QWidget::setTabOrder(mcconfLimCurrentSlowAbsMaxBox, dutyButton);
        QWidget::setTabOrder(dutyButton, mcconfLimErpmLimitNegTorqueBox);
        QWidget::setTabOrder(mcconfLimErpmLimitNegTorqueBox, rpmBox);
        QWidget::setTabOrder(rpmBox, rpmButton);
        QWidget::setTabOrder(rpmButton, mcconfDetectMotorParamButton);
        QWidget::setTabOrder(mcconfDetectMotorParamButton, mcconfDetectCurrentBox);
        QWidget::setTabOrder(mcconfDetectCurrentBox, mcconfDetectErpmBox);
        QWidget::setTabOrder(mcconfDetectErpmBox, mcconfDetectLowDutyBox);
        QWidget::setTabOrder(mcconfDetectLowDutyBox, mcconfPwmModeSyncButton);
        QWidget::setTabOrder(mcconfPwmModeSyncButton, mcconfPwmModeBipolarButton);
        QWidget::setTabOrder(mcconfPwmModeBipolarButton, mcconfPwmModeNonsyncHiswButton);
        QWidget::setTabOrder(mcconfPwmModeNonsyncHiswButton, mcconfCcBoostBox);
        QWidget::setTabOrder(mcconfCcBoostBox, mcconfCcMinBox);
        QWidget::setTabOrder(mcconfCcMinBox, mcconfCcGainBox);
        QWidget::setTabOrder(mcconfCcGainBox, mcconfSpidKiBox);
        QWidget::setTabOrder(mcconfSpidKiBox, mcconfSpidMinRpmBox);
        QWidget::setTabOrder(mcconfSpidMinRpmBox, mcconfSpidKdBox);
        QWidget::setTabOrder(mcconfSpidKdBox, mcconfSpidKpBox);
        QWidget::setTabOrder(mcconfSpidKpBox, mcconfPpidKiBox);
        QWidget::setTabOrder(mcconfPpidKiBox, mcconfPpidKpBox);
        QWidget::setTabOrder(mcconfPpidKpBox, mcconfPpidKdBox);
        QWidget::setTabOrder(mcconfPpidKdBox, mcconfMFaultStopTimeBox);
        QWidget::setTabOrder(mcconfMFaultStopTimeBox, mcconfReadButton);
        QWidget::setTabOrder(mcconfReadButton, mcconfWriteButton);
        QWidget::setTabOrder(mcconfWriteButton, mcconfLoadXmlButton);
        QWidget::setTabOrder(mcconfLoadXmlButton, mcconfSaveXmlButton);
        QWidget::setTabOrder(mcconfSaveXmlButton, tabWidget_3);
        QWidget::setTabOrder(tabWidget_3, appconfControllerIdBox);
        QWidget::setTabOrder(appconfControllerIdBox, appconfSendCanStatusBox);
        QWidget::setTabOrder(appconfSendCanStatusBox, appconfSendCanStatusRateBox);
        QWidget::setTabOrder(appconfSendCanStatusRateBox, appconfUseUartButton);
        QWidget::setTabOrder(appconfUseUartButton, appconfUsePpmUartButton);
        QWidget::setTabOrder(appconfUsePpmUartButton, appconfUseCustomButton);
        QWidget::setTabOrder(appconfUseCustomButton, appconfUseNoAppButton);
        QWidget::setTabOrder(appconfUseNoAppButton, appconfUseNrfButton);
        QWidget::setTabOrder(appconfUseNrfButton, appconfUseNunchukButton);
        QWidget::setTabOrder(appconfUseNunchukButton, appconfUsePpmButton);
        QWidget::setTabOrder(appconfUsePpmButton, appconfUseAdcButton);
        QWidget::setTabOrder(appconfUseAdcButton, appconfUseAdcUartButton);
        QWidget::setTabOrder(appconfUseAdcUartButton, appconfTimeoutBox);
        QWidget::setTabOrder(appconfTimeoutBox, appconfTimeoutBrakeCurrentBox);
        QWidget::setTabOrder(appconfTimeoutBrakeCurrentBox, appconfPpmDutyNorevButton);
        QWidget::setTabOrder(appconfPpmDutyNorevButton, appconfPpmDutyButton);
        QWidget::setTabOrder(appconfPpmDutyButton, appconfPpmDisabledButton);
        QWidget::setTabOrder(appconfPpmDisabledButton, appconfPpmPidNorevButton);
        QWidget::setTabOrder(appconfPpmPidNorevButton, appconfPpmCurrentNorevBrakeButton);
        QWidget::setTabOrder(appconfPpmCurrentNorevBrakeButton, appconfPpmCurrentButton);
        QWidget::setTabOrder(appconfPpmCurrentButton, appconfPpmCurrentNorevButton);
        QWidget::setTabOrder(appconfPpmCurrentNorevButton, appconfPpmPidButton);
        QWidget::setTabOrder(appconfPpmPidButton, appconfPpmMedianFilterBox);
        QWidget::setTabOrder(appconfPpmMedianFilterBox, appconfPpmPidMaxErpmBox);
        QWidget::setTabOrder(appconfPpmPidMaxErpmBox, appconfPpmPulseStartBox);
        QWidget::setTabOrder(appconfPpmPulseStartBox, appconfPpmPulseWidthBox);
        QWidget::setTabOrder(appconfPpmPulseWidthBox, appconfPpmHystBox);
        QWidget::setTabOrder(appconfPpmHystBox, appconfPpmSafeStartBox);
        QWidget::setTabOrder(appconfPpmSafeStartBox, appconfPpmRpmLimBox);
        QWidget::setTabOrder(appconfPpmRpmLimBox, appconfPpmRpmLimStartBox);
        QWidget::setTabOrder(appconfPpmRpmLimStartBox, appconfPpmRpmLimEndBox);
        QWidget::setTabOrder(appconfPpmRpmLimEndBox, appconfPpmMultiGroup);
        QWidget::setTabOrder(appconfPpmMultiGroup, appconfPpmTcBox);
        QWidget::setTabOrder(appconfPpmTcBox, appconfPpmTcErpmBox);
        QWidget::setTabOrder(appconfPpmTcErpmBox, appconfUpdatePpmBox);
        QWidget::setTabOrder(appconfUpdatePpmBox, appconfAdcCurrentButtonButton);
        QWidget::setTabOrder(appconfAdcCurrentButtonButton, appconfAdcDisabledButton);
        QWidget::setTabOrder(appconfAdcDisabledButton, appconfAdcCurrentNorevCenterButton);
        QWidget::setTabOrder(appconfAdcCurrentNorevCenterButton, appconfAdcCurrentNorevButtonButton);
        QWidget::setTabOrder(appconfAdcCurrentNorevButtonButton, appconfAdcCurrentButton);
        QWidget::setTabOrder(appconfAdcCurrentButton, appconfAdcCurrentCenterButton);
        QWidget::setTabOrder(appconfAdcCurrentCenterButton, appconfAdcUpdateRateBox);
        QWidget::setTabOrder(appconfAdcUpdateRateBox, appconfAdcHystBox);
        QWidget::setTabOrder(appconfAdcHystBox, appconfAdcInvertRevButtonBox);
        QWidget::setTabOrder(appconfAdcInvertRevButtonBox, appconfAdcSafeStartBox);
        QWidget::setTabOrder(appconfAdcSafeStartBox, appconfAdcFilterBox);
        QWidget::setTabOrder(appconfAdcFilterBox, appconfAdcRpmLimBox);
        QWidget::setTabOrder(appconfAdcRpmLimBox, appconfAdcRpmLimStartBox);
        QWidget::setTabOrder(appconfAdcRpmLimStartBox, appconfAdcMultiGroup);
        QWidget::setTabOrder(appconfAdcMultiGroup, appconfAdcTcBox);
        QWidget::setTabOrder(appconfAdcTcBox, appconfAdcTcErpmBox);
        QWidget::setTabOrder(appconfAdcTcErpmBox, appconfAdcUpdateBox);
        QWidget::setTabOrder(appconfAdcUpdateBox, appconfUartBaudBox);
        QWidget::setTabOrder(appconfUartBaudBox, appconfChukDisabledButton);
        QWidget::setTabOrder(appconfChukDisabledButton, appconfChukCurrentNorevButton);
        QWidget::setTabOrder(appconfChukCurrentNorevButton, appconfChukCurrentButton);
        QWidget::setTabOrder(appconfChukCurrentButton, appconfChukHystBox);
        QWidget::setTabOrder(appconfChukHystBox, appconfChukRampTimePosBox);
        QWidget::setTabOrder(appconfChukRampTimePosBox, appconfChukRpmLimStartBox);
        QWidget::setTabOrder(appconfChukRpmLimStartBox, appconfChukRampTimeNegBox);
        QWidget::setTabOrder(appconfChukRampTimeNegBox, appconfChukRpmLimEndBox);
        QWidget::setTabOrder(appconfChukRpmLimEndBox, appconfChukMultiGroup);
        QWidget::setTabOrder(appconfChukMultiGroup, appconfChukTcBox);
        QWidget::setTabOrder(appconfChukTcBox, appconfChukTcErpmBox);
        QWidget::setTabOrder(appconfChukTcErpmBox, appconfUpdateChukBox);
        QWidget::setTabOrder(appconfUpdateChukBox, textBrowser);
        QWidget::setTabOrder(textBrowser, appconfReadButton);
        QWidget::setTabOrder(appconfReadButton, appconfWriteButton);
        QWidget::setTabOrder(appconfWriteButton, tabWidget_5);
        QWidget::setTabOrder(tabWidget_5, realtimeAutoScaleBox);
        QWidget::setTabOrder(realtimeAutoScaleBox, realtimeActivateBox);
        QWidget::setTabOrder(realtimeActivateBox, showPh1Box);
        QWidget::setTabOrder(showPh1Box, showPh2Box);
        QWidget::setTabOrder(showPh2Box, showPh3Box);
        QWidget::setTabOrder(showPh3Box, showVirtualGndBox);
        QWidget::setTabOrder(showVirtualGndBox, showPosVoltageBox);
        QWidget::setTabOrder(showPosVoltageBox, truncateBox);
        QWidget::setTabOrder(truncateBox, tabWidget_2);
        QWidget::setTabOrder(tabWidget_2, showCurrent1Box);
        QWidget::setTabOrder(showCurrent1Box, showCurrent2Box);
        QWidget::setTabOrder(showCurrent2Box, showCurrent3Box);
        QWidget::setTabOrder(showCurrent3Box, showTotalCurrentBox);
        QWidget::setTabOrder(showTotalCurrentBox, showMcTotalCurrentBox);
        QWidget::setTabOrder(showMcTotalCurrentBox, showPosCurrentBox);
        QWidget::setTabOrder(showPosCurrentBox, currentTimeButton);
        QWidget::setTabOrder(currentTimeButton, currentSpectrumButton);
        QWidget::setTabOrder(currentSpectrumButton, filterScatterBox);
        QWidget::setTabOrder(filterScatterBox, filterLogScaleBox2);
        QWidget::setTabOrder(filterLogScaleBox2, filterScatterBox2);
        QWidget::setTabOrder(filterScatterBox2, currentFilterActiveBox);
        QWidget::setTabOrder(currentFilterActiveBox, firRadioButton);
        QWidget::setTabOrder(firRadioButton, meanRadioButton);
        QWidget::setTabOrder(meanRadioButton, compDelayBox);
        QWidget::setTabOrder(compDelayBox, hammingBox);
        QWidget::setTabOrder(hammingBox, currentFilterActiveBox2);
        QWidget::setTabOrder(currentFilterActiveBox2, firRadioButton2);
        QWidget::setTabOrder(firRadioButton2, meanRadioButton2);
        QWidget::setTabOrder(meanRadioButton2, currentFilterFreqBox2);
        QWidget::setTabOrder(currentFilterFreqBox2, currentFilterTapBox2);
        QWidget::setTabOrder(currentFilterTapBox2, hammingBox2);
        QWidget::setTabOrder(hammingBox2, decimationSpinBox);
        QWidget::setTabOrder(decimationSpinBox, terminalBrowser);
        QWidget::setTabOrder(terminalBrowser, terminalEdit);
        QWidget::setTabOrder(terminalEdit, sendTerminalButton);
        QWidget::setTabOrder(sendTerminalButton, clearTerminalButton);
        QWidget::setTabOrder(clearTerminalButton, firmwareChooseButton);
        QWidget::setTabOrder(firmwareChooseButton, firmwareUploadButton);
        QWidget::setTabOrder(firmwareUploadButton, firmwareEdit);
        QWidget::setTabOrder(firmwareEdit, firmwareVersionReadButton);
        QWidget::setTabOrder(firmwareVersionReadButton, detectButton);
        QWidget::setTabOrder(detectButton, stopDetectButton);
        QWidget::setTabOrder(stopDetectButton, experimentClearSamplesButton);
        QWidget::setTabOrder(experimentClearSamplesButton, experimentSaveSamplesButton);
        QWidget::setTabOrder(experimentSaveSamplesButton, experimentBrowser);
        QWidget::setTabOrder(experimentBrowser, experimentPathEdit);
        QWidget::setTabOrder(experimentPathEdit, experimentAutosaveBox);
        QWidget::setTabOrder(experimentAutosaveBox, experimentAutosaveIntervalBox);
        QWidget::setTabOrder(experimentAutosaveIntervalBox, servoOutputSlider);
        QWidget::setTabOrder(servoOutputSlider, currentBox);
        QWidget::setTabOrder(currentBox, currentButton);
        QWidget::setTabOrder(currentButton, currentBrakeBox);
        QWidget::setTabOrder(currentBrakeBox, currentBrakeButton);
        QWidget::setTabOrder(currentBrakeButton, posCtrlBox);
        QWidget::setTabOrder(posCtrlBox, posCtrlButton);
        QWidget::setTabOrder(posCtrlButton, overrideKbBox);
        QWidget::setTabOrder(overrideKbBox, arrowCurrentBox);
        QWidget::setTabOrder(arrowCurrentBox, offBrakeButton);
        QWidget::setTabOrder(offBrakeButton, getDataButton);
        QWidget::setTabOrder(getDataButton, getDataStartButton);
        QWidget::setTabOrder(getDataStartButton, appconfAdcInvertCcButtonBox);
        QWidget::setTabOrder(appconfAdcInvertCcButtonBox, textBrowser_2);
        QWidget::setTabOrder(textBrowser_2, mcconfMDutyRampStepSpeedLimBox);

        retranslateUi(MainWindow);
        QObject::connect(currentFilterActiveBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(truncateBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(currentFilterFreqBox, SIGNAL(valueChanged(double)), replotButton, SLOT(click()));
        QObject::connect(sampleFreqBox, SIGNAL(valueChanged(int)), replotButton, SLOT(click()));
        QObject::connect(hammingBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(compDelayBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(currentFilterTapBox, SIGNAL(valueChanged(int)), replotButton, SLOT(click()));
        QObject::connect(firRadioButton, SIGNAL(toggled(bool)), replotButton, SLOT(click()));
        QObject::connect(filterScatterBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(currentFilterActiveBox2, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(firRadioButton2, SIGNAL(toggled(bool)), replotButton, SLOT(click()));
        QObject::connect(decimationSpinBox, SIGNAL(valueChanged(int)), replotButton, SLOT(click()));
        QObject::connect(hammingBox2, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(currentFilterTapBox2, SIGNAL(valueChanged(int)), replotButton, SLOT(click()));
        QObject::connect(currentFilterFreqBox2, SIGNAL(valueChanged(double)), replotButton, SLOT(click()));
        QObject::connect(filterScatterBox2, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showCurrent1Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showCurrent2Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showCurrent3Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showTotalCurrentBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showMcTotalCurrentBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showPosCurrentBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showPh1Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showPh2Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showPh3Box, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showPosVoltageBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(showVirtualGndBox, SIGNAL(clicked()), replotButton, SLOT(click()));
        QObject::connect(currentTimeButton, SIGNAL(toggled(bool)), replotButton, SLOT(click()));
        QObject::connect(terminalEdit, SIGNAL(returnPressed()), sendTerminalButton, SLOT(click()));

        tabWidget->setCurrentIndex(0);
        tabWidget_4->setCurrentIndex(0);
        tabWidget_3->setCurrentIndex(0);
        appconfNrfRetrDelayBox->setCurrentIndex(0);
        tabWidget_5->setCurrentIndex(0);
        tabWidget_2->setCurrentIndex(0);
        toolBox->setCurrentIndex(0);
        tabWidget_6->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "BLDC Tool", 0));
        groupBox_29->setTitle(QApplication::translate("MainWindow", "Motor Type", 0));
        mcconfTypeBldcButton->setText(QApplication::translate("MainWindow", "BLDC", 0));
        mcconfTypeDcButton->setText(QApplication::translate("MainWindow", "DC", 0));
        mcconfTypeFocButton->setText(QApplication::translate("MainWindow", "FOC", 0));
        groupBox_8->setTitle(QApplication::translate("MainWindow", "Current Limits", 0));
        label_19->setText(QApplication::translate("MainWindow", "Batt min (regen)", 0));
        label_20->setText(QApplication::translate("MainWindow", "Absolute max", 0));
        mcconfLimCurrentInMinBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        label_18->setText(QApplication::translate("MainWindow", "Batt max", 0));
        label_17->setText(QApplication::translate("MainWindow", "Motor min (regen)", 0));
        mcconfLimCurrentAbsMaxBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        mcconfLimCurrentMinBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        mcconfLimCurrentInMaxBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        label_16->setText(QApplication::translate("MainWindow", "Motor max", 0));
        mcconfLimCurrentMaxBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        mcconfLimCurrentSlowAbsMaxBox->setText(QApplication::translate("MainWindow", "Slow absolute max", 0));
        groupBox_9->setTitle(QApplication::translate("MainWindow", "RPM Limits (BLDC Only)", 0));
        label_21->setText(QApplication::translate("MainWindow", "Min ERPM", 0));
        label_22->setText(QApplication::translate("MainWindow", "Max ERPM", 0));
        label_23->setText(QApplication::translate("MainWindow", "Max ERPM at full brake", 0));
        mcconfLimErpmLimitNegTorqueBox->setText(QApplication::translate("MainWindow", "Limit ERPM with negative torque", 0));
        label_62->setText(QApplication::translate("MainWindow", "Max ERPM at full brake in current control mode", 0));
        groupBox_27->setTitle(QApplication::translate("MainWindow", "Temperature Limits", 0));
        label_57->setText(QApplication::translate("MainWindow", "MOSFET Start", 0));
        mcconfLimTempFetStartBox->setSuffix(QApplication::translate("MainWindow", " \302\260C", 0));
        label_58->setText(QApplication::translate("MainWindow", "MOSFET End", 0));
        mcconfLimTempFetEndBox->setSuffix(QApplication::translate("MainWindow", " \302\260C", 0));
        label_59->setText(QApplication::translate("MainWindow", "Motor Start", 0));
        mcconfLimTempMotorStartBox->setSuffix(QApplication::translate("MainWindow", " \302\260C", 0));
        label_60->setText(QApplication::translate("MainWindow", "Motor End", 0));
        mcconfLimTempMotorEndBox->setSuffix(QApplication::translate("MainWindow", " \302\260C", 0));
        groupBox_10->setTitle(QApplication::translate("MainWindow", "Voltage Limits", 0));
        label_86->setText(QApplication::translate("MainWindow", "Battery cutoff start", 0));
        label_25->setText(QApplication::translate("MainWindow", "Maximum input voltage", 0));
        label_24->setText(QApplication::translate("MainWindow", "Minimum input voltage", 0));
        mcconfLimMinVinBox->setSuffix(QApplication::translate("MainWindow", " V", 0));
        mcconfLimMaxVinBox->setSuffix(QApplication::translate("MainWindow", " V", 0));
        label_87->setText(QApplication::translate("MainWindow", "Battery cutoff end", 0));
        mcconfLimBatteryCutStartBox->setSuffix(QApplication::translate("MainWindow", " V", 0));
        mcconfLimBatteryCutEndBox->setSuffix(QApplication::translate("MainWindow", " V", 0));
        groupBox_38->setTitle(QApplication::translate("MainWindow", "Other Limits", 0));
        label_83->setText(QApplication::translate("MainWindow", "Minimum duty cycle", 0));
        label_84->setText(QApplication::translate("MainWindow", "Maximum duty cycle", 0));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_12), QApplication::translate("MainWindow", "Motor", 0));
        groupBox_34->setTitle(QApplication::translate("MainWindow", "Sensor Mode", 0));
        mcconfSensorModeSensorlessButton->setText(QApplication::translate("MainWindow", "Sensorless", 0));
        mcconfSensorModeSensoredButton->setText(QApplication::translate("MainWindow", "Sensored", 0));
        mcconfSensorModeHybridButton->setText(QApplication::translate("MainWindow", "Hybrid", 0));
        mcconfSlBox->setTitle(QApplication::translate("MainWindow", "Sensorless", 0));
#ifndef QT_NO_TOOLTIP
        label_26->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Important for startup</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        label_26->setText(QApplication::translate("MainWindow", "Min ERPM", 0));
#ifndef QT_NO_TOOLTIP
        label_30->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>For phase advance, not so important</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        label_30->setText(QApplication::translate("MainWindow", "BR ERPM", 0));
#ifndef QT_NO_TOOLTIP
        label_29->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>For phase advance, not so important</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        label_29->setText(QApplication::translate("MainWindow", "Phase advance at BR ERPM", 0));
        label_61->setText(QApplication::translate("MainWindow", "Max brake current at dir change", 0));
        groupBox_16->setTitle(QApplication::translate("MainWindow", "Sensorless - Commutation Mode", 0));
        label_100->setText(QApplication::translate("MainWindow", "Comm Mode", 0));
        mcconfCommIntButton->setText(QApplication::translate("MainWindow", "Integrate", 0));
        mcconfCommDelayButton->setText(QApplication::translate("MainWindow", "Delay", 0));
#ifndef QT_NO_TOOLTIP
        label_28->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Important. The detection function below can be used to determine this parameter.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        label_28->setText(QApplication::translate("MainWindow", "Integrator Limit", 0));
#ifndef QT_NO_TOOLTIP
        label_27->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Important for startup</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        label_27->setText(QApplication::translate("MainWindow", "Int Limit Min ERPM", 0));
#ifndef QT_NO_TOOLTIP
        label_41->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Important. The detection function below can be used to determine this parameter.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        label_41->setText(QApplication::translate("MainWindow", "BEMF Coupling", 0));
        groupBox_12->setTitle(QApplication::translate("MainWindow", "Hall Sensors", 0));
        label_31->setText(QApplication::translate("MainWindow", "Table", 0));
        label_32->setText(QApplication::translate("MainWindow", "Sensorless ERPM (hybrid mode)", 0));
        groupBox_11->setTitle(QApplication::translate("MainWindow", "Detect Parameters", 0));
        mcconfDetectMotorParamButton->setText(QApplication::translate("MainWindow", "Start detection", 0));
        mcconfDetectApplyButton->setText(QApplication::translate("MainWindow", "Apply", 0));
        mcconfDetectCurrentBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        label_44->setText(QApplication::translate("MainWindow", "Min ERPM", 0));
#ifndef QT_NO_TOOLTIP
        label_42->setToolTip(QApplication::translate("MainWindow", "The duty cycle at which the BEMF coupling is measured. A value between 0.03 and 0.15 usually works.", 0));
#endif // QT_NO_TOOLTIP
        label_42->setText(QApplication::translate("MainWindow", "Low duty", 0));
        label_43->setText(QApplication::translate("MainWindow", "Current", 0));
        mcconfDetectResultBrowser->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:11pt;\">Detection results will be printed here.</span></p></body></html>", 0));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_13), QApplication::translate("MainWindow", "BLDC", 0));
        groupBox_39->setTitle(QApplication::translate("MainWindow", "General", 0));
        mcconfFocEncoderRatioBox->setPrefix(QApplication::translate("MainWindow", "Rat: ", 0));
        label_89->setText(QApplication::translate("MainWindow", "Current Control", 0));
        mcconfFocCurrKpBox->setPrefix(QApplication::translate("MainWindow", "Kp: ", 0));
        mcconfFocCurrKiBox->setPrefix(QApplication::translate("MainWindow", "Ki: ", 0));
        label_92->setText(QApplication::translate("MainWindow", "Encoder", 0));
        mcconfFocEncoderOffsetBox->setPrefix(QApplication::translate("MainWindow", "Ofs: ", 0));
        label_101->setText(QApplication::translate("MainWindow", "Sensor Mode", 0));
        mcconfFocEncoderInvertedBox->setText(QApplication::translate("MainWindow", "Invert Encoder", 0));
        mcconfFocModeEncoderButton->setText(QApplication::translate("MainWindow", "Encoder", 0));
        mcconfFocModeHallButton->setText(QApplication::translate("MainWindow", "Hall", 0));
        mcconfFocModeSensorlessButton->setText(QApplication::translate("MainWindow", "Sensorless", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocSlErpmBox->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>ERPM above which the hall sensors or encoder will be ignored and only the observer is used.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        label_96->setText(QApplication::translate("MainWindow", "Sensorless ERPM", 0));
        groupBox_41->setTitle(QApplication::translate("MainWindow", "General (cont)", 0));
        label_104->setText(QApplication::translate("MainWindow", "Openloop RPM", 0));
        mcconfFocPllKpBox->setPrefix(QApplication::translate("MainWindow", "Kp: ", 0));
        mcconfFocDutyDownrampKiBox->setPrefix(QApplication::translate("MainWindow", "Ki: ", 0));
        label_103->setText(QApplication::translate("MainWindow", "Duty Downramp", 0));
        mcconfFocPllKiBox->setPrefix(QApplication::translate("MainWindow", "Ki: ", 0));
        label_90->setText(QApplication::translate("MainWindow", "Speed Tracker", 0));
        mcconfFocOpenloopRpmBox->setPrefix(QString());
        mcconfFocOpenloopRpmBox->setSuffix(QApplication::translate("MainWindow", " RPM", 0));
        mcconfFocDutyDownrampKpBox->setPrefix(QApplication::translate("MainWindow", "Kp: ", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocFSwBox->setToolTip(QApplication::translate("MainWindow", "Switching Frequency", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocFSwBox->setSuffix(QApplication::translate("MainWindow", " Hz", 0));
        mcconfFocFSwBox->setPrefix(QApplication::translate("MainWindow", "F_SW: ", 0));
        label_94->setText(QApplication::translate("MainWindow", "F_SW and DTc", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocDtCompBox->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Dead time compensation. Getting this value right is important for the low speed performance of the sensorless observer.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocDtCompBox->setPrefix(QApplication::translate("MainWindow", "DTc: ", 0));
        mcconfFocDtCompBox->setSuffix(QApplication::translate("MainWindow", " \302\265S", 0));
        groupBox_40->setTitle(QApplication::translate("MainWindow", "Motor Parameters (for Sensorless and Hall Operation)", 0));
        label_98->setText(QApplication::translate("MainWindow", "Observer Gain (x1M)", 0));
        mcconfFocObserverGainCalcButton->setText(QApplication::translate("MainWindow", "Calc (Req: L)", 0));
        mcconfFocMotorRBox->setPrefix(QApplication::translate("MainWindow", "R: ", 0));
        mcconfFocMotorRBox->setSuffix(QApplication::translate("MainWindow", " \316\251", 0));
        mcconfFocMotorLBox->setPrefix(QApplication::translate("MainWindow", "L: ", 0));
        mcconfFocMotorLBox->setSuffix(QApplication::translate("MainWindow", " \302\265H", 0));
        mcconfFocMotorLinkageBox->setPrefix(QApplication::translate("MainWindow", "\316\273: ", 0));
        groupBox_43->setTitle(QApplication::translate("MainWindow", "Sensorless Startup and Low Speed", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocDCurrentFactorBox->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>The maximum factor between the D axis and Q axis current.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocDCurrentFactorBox->setPrefix(QApplication::translate("MainWindow", "Factor: ", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocSlOpenloopHystBox->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>If the filtered RPM has been below openloop RPM for this amount of time, the motor will rotate in open loop with openloop RPM.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocSlOpenloopHystBox->setPrefix(QApplication::translate("MainWindow", "Hyst: ", 0));
        mcconfFocSlOpenloopHystBox->setSuffix(QApplication::translate("MainWindow", " s", 0));
        label_105->setText(QApplication::translate("MainWindow", "Open Loop", 0));
        label_107->setText(QApplication::translate("MainWindow", "D Current Injection", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocDCurrentDutyBox->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Inject D axis current below this duty cycle.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocDCurrentDutyBox->setPrefix(QApplication::translate("MainWindow", "Duty: ", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocSlOpenloopTimeBox->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Time to remain in open loop before entering closed loop.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocSlOpenloopTimeBox->setPrefix(QApplication::translate("MainWindow", "Time: ", 0));
        mcconfFocSlOpenloopTimeBox->setSuffix(QApplication::translate("MainWindow", " s", 0));
        groupBox_46->setTitle(QApplication::translate("MainWindow", "Hall Sensors", 0));
        label_95->setText(QApplication::translate("MainWindow", "Table", 0));
        groupBox_44->setTitle(QApplication::translate("MainWindow", "Detect and Calculate Parameters", 0));
        mcconfFocCalcCCTcBox->setPrefix(QApplication::translate("MainWindow", "TC: ", 0));
        mcconfFocCalcCCTcBox->setSuffix(QApplication::translate("MainWindow", " \302\265S", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocMeasureLinkageButton->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Spin up the motor using BLDC delay commutation and measure the flux linkage. The motor resistance is required to compensate for load, so it should be measured or entered first.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocMeasureLinkageButton->setText(QApplication::translate("MainWindow", "Measure \316\273 (Req: R)", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocMeasureRLButton->setToolTip(QApplication::translate("MainWindow", "Measure the motor resistance and inductance.", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocMeasureRLButton->setText(QApplication::translate("MainWindow", "Measure R and L", 0));
        mcconfFocDetectRBox->setPrefix(QApplication::translate("MainWindow", "R: ", 0));
        mcconfFocDetectRBox->setSuffix(QApplication::translate("MainWindow", " \316\251", 0));
        mcconfFocDetectLBox->setPrefix(QApplication::translate("MainWindow", "L: ", 0));
        mcconfFocDetectLBox->setSuffix(QApplication::translate("MainWindow", " \302\265H", 0));
        mcconfFocApplyRLLambdaButton->setText(QApplication::translate("MainWindow", "Apply", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocCalcCCButton->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Calculate Kp and Ki for the current control loop based on the motor resistance and inductance, and a desired time constant (TC) of the system.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocCalcCCButton->setText(QApplication::translate("MainWindow", "Calc CC (Req: R and L)", 0));
        mcconfFocCalcCCApplyButton->setText(QApplication::translate("MainWindow", "Apply", 0));
        mcconfFocDetectLinkageBox->setPrefix(QApplication::translate("MainWindow", "\316\273: ", 0));
        mcconfFocCalcKiBox->setPrefix(QApplication::translate("MainWindow", "Ki: ", 0));
        mcconfFocCalcKpBox->setPrefix(QApplication::translate("MainWindow", "Kp: ", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocDetectCurrentBox->setToolTip(QApplication::translate("MainWindow", "For measuring flux linkage:  The current to use.", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocDetectCurrentBox->setPrefix(QApplication::translate("MainWindow", "I: ", 0));
        mcconfFocDetectCurrentBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocDetectDutyBox->setToolTip(QApplication::translate("MainWindow", "For measuring flux linkage:  Duty cycle to measure flux linkage at.", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocDetectDutyBox->setPrefix(QApplication::translate("MainWindow", "Duty: ", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocDetectMinRpmBox->setToolTip(QApplication::translate("MainWindow", "For measuring flux linkage: The minimum RPM to start the motor with.", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocDetectMinRpmBox->setPrefix(QApplication::translate("MainWindow", "RPM: ", 0));
        label_93->setText(QApplication::translate("MainWindow", "\342\206\220 To spin up for \316\273", 0));
        groupBox_42->setTitle(QApplication::translate("MainWindow", "Detect Encoder", 0));
#ifndef QT_NO_TOOLTIP
        mcconfFocMeasureEncoderButton->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Run the motor slowly in open loop using the selected current and try to figure out the encoder offset and ratio, and whether the encoder is inverted.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        mcconfFocMeasureEncoderButton->setText(QApplication::translate("MainWindow", "Measure", 0));
        mcconfFocMeasureEncoderCurrentBox->setPrefix(QApplication::translate("MainWindow", "I: ", 0));
        mcconfFocMeasureEncoderCurrentBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        mcconfFocMeasureEncoderOffsetBox->setPrefix(QApplication::translate("MainWindow", "Ofs: ", 0));
        mcconfFocMeasureEncoderOffsetBox->setSuffix(QString());
        mcconfFocMeasureEncoderRatioBox->setPrefix(QApplication::translate("MainWindow", "Rat: ", 0));
        mcconfFocMeasureEncoderRatioBox->setSuffix(QString());
        mcconfFocMeasureEncoderInvertedBox->setText(QApplication::translate("MainWindow", "Invert Encoder", 0));
        mcconfFocMeasureEncoderApplyButton->setText(QApplication::translate("MainWindow", "Apply", 0));
        groupBox_45->setTitle(QApplication::translate("MainWindow", "Detect Hall Sensors", 0));
        mcconfFocMeasureHallButton->setText(QApplication::translate("MainWindow", "Measure", 0));
        mcconfFocMeasureHallCurrentBox->setPrefix(QApplication::translate("MainWindow", "I: ", 0));
        mcconfFocMeasureHallCurrentBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        mcconfFocMeasureHallApplyButton->setText(QApplication::translate("MainWindow", "Apply", 0));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_24), QApplication::translate("MainWindow", "FOC", 0));
        groupBox_13->setTitle(QApplication::translate("MainWindow", "PWM mode (DC and BLDC only)", 0));
        mcconfPwmModeSyncButton->setText(QApplication::translate("MainWindow", "Synchronous", 0));
        mcconfPwmModeBipolarButton->setText(QApplication::translate("MainWindow", "Bipolar", 0));
        mcconfPwmModeNonsyncHiswButton->setText(QApplication::translate("MainWindow", "Nonsynchronous-HISW (Not recommended)", 0));
        groupBox_14->setTitle(QApplication::translate("MainWindow", "Current control", 0));
        label_34->setText(QApplication::translate("MainWindow", "Startup boost (BLDC only)", 0));
        label_35->setText(QApplication::translate("MainWindow", "Min current", 0));
#ifndef QT_NO_TOOLTIP
        label_36->setToolTip(QApplication::translate("MainWindow", "Only change this if you know what you are doing", 0));
#endif // QT_NO_TOOLTIP
        label_36->setText(QApplication::translate("MainWindow", "Gain (BLDC and DC only)", 0));
        groupBox_37->setTitle(QApplication::translate("MainWindow", "Backoff and ramping (DC and BLDC only)", 0));
        label_3->setText(QApplication::translate("MainWindow", "Duty ramp step (at 1 kHz)", 0));
        label_69->setText(QApplication::translate("MainWindow", "Max current ramp step (at 1 kHz)", 0));
        label_85->setText(QApplication::translate("MainWindow", "Current backoff gain", 0));
        label_33->setText(QApplication::translate("MainWindow", "Speed limit ramp step", 0));
        groupBox_15->setTitle(QApplication::translate("MainWindow", "Speed control", 0));
        label_37->setText(QApplication::translate("MainWindow", "KP", 0));
        label_38->setText(QApplication::translate("MainWindow", "KI", 0));
        label_39->setText(QApplication::translate("MainWindow", "KD", 0));
        label_40->setText(QApplication::translate("MainWindow", "MIN ERPM", 0));
        groupBox_30->setTitle(QApplication::translate("MainWindow", "Position control", 0));
        label_68->setText(QApplication::translate("MainWindow", "KP", 0));
        label_70->setText(QApplication::translate("MainWindow", "KI", 0));
        label_71->setText(QApplication::translate("MainWindow", "KD", 0));
        label_11->setText(QApplication::translate("MainWindow", "Angle division", 0));
        groupBox_17->setTitle(QApplication::translate("MainWindow", "Misc", 0));
        label_4->setText(QApplication::translate("MainWindow", "Fault stop time", 0));
        mcconfMFaultStopTimeBox->setSuffix(QApplication::translate("MainWindow", " ms", 0));
        label_91->setText(QApplication::translate("MainWindow", "Encoder Counts", 0));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "Hall/encoder port mode", 0));
        mcconfMSensorHallButton->setText(QApplication::translate("MainWindow", "Hall sensors", 0));
        mcconfMSensorAsSpiButton->setText(QApplication::translate("MainWindow", "AS5047/AS5048 SPI", 0));
        mcconfMSensorAbiButton->setText(QApplication::translate("MainWindow", "ABI encoder", 0));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_14), QApplication::translate("MainWindow", "Advanced", 0));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_4), QApplication::translate("MainWindow", "Description", 0));
        mcconfReadButton->setText(QApplication::translate("MainWindow", "Read configuration", 0));
        mcconfReadDefaultButton->setText(QApplication::translate("MainWindow", "Read default configuration", 0));
        mcconfWriteButton->setText(QApplication::translate("MainWindow", "Write configuration", 0));
        mcconfLoadXmlButton->setText(QApplication::translate("MainWindow", "Load XML", 0));
        mcconfSaveXmlButton->setText(QApplication::translate("MainWindow", "Save XML", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_11), QApplication::translate("MainWindow", "Motor Configuration", 0));
        groupBox_28->setTitle(QApplication::translate("MainWindow", "Settings", 0));
        label_65->setText(QApplication::translate("MainWindow", "Controller ID", 0));
        appconfSendCanStatusBox->setTitle(QApplication::translate("MainWindow", "Send status over CAN", 0));
        label_12->setText(QApplication::translate("MainWindow", "Rate (Hz)", 0));
        groupBox_18->setTitle(QApplication::translate("MainWindow", "App to use (Changing this requires a reboot)", 0));
        appconfUseUartButton->setText(QApplication::translate("MainWindow", "UART", 0));
        appconfUsePpmUartButton->setText(QApplication::translate("MainWindow", "PPM and UART", 0));
        appconfUseCustomButton->setText(QApplication::translate("MainWindow", "Custom user application", 0));
        appconfUseNoAppButton->setText(QApplication::translate("MainWindow", "No app", 0));
        appconfUseNrfButton->setText(QApplication::translate("MainWindow", "NRF", 0));
        appconfUseNunchukButton->setText(QApplication::translate("MainWindow", "Nunchuk", 0));
        appconfUsePpmButton->setText(QApplication::translate("MainWindow", "PPM", 0));
        appconfUseAdcButton->setText(QApplication::translate("MainWindow", "ADC", 0));
        appconfUseAdcUartButton->setText(QApplication::translate("MainWindow", "ADC and UART", 0));
        groupBox_22->setTitle(QApplication::translate("MainWindow", "Timeout (when no control signal is received)", 0));
        label_52->setText(QApplication::translate("MainWindow", "Timeout (ms)", 0));
        label_53->setText(QApplication::translate("MainWindow", "Brake current to use when a timeout occurs (A)", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_16), QApplication::translate("MainWindow", "General", 0));
        groupBox_19->setTitle(QApplication::translate("MainWindow", "Control mode", 0));
        appconfPpmDutyNorevButton->setText(QApplication::translate("MainWindow", "Duty cycle no reverse", 0));
        appconfPpmDutyButton->setText(QApplication::translate("MainWindow", "Duty cycle", 0));
        appconfPpmDisabledButton->setText(QApplication::translate("MainWindow", "Disabled", 0));
        appconfPpmPidNorevButton->setText(QApplication::translate("MainWindow", "PID speed control no reverse", 0));
        appconfPpmCurrentNorevBrakeButton->setText(QApplication::translate("MainWindow", "Current no reverse with brake", 0));
        appconfPpmCurrentButton->setText(QApplication::translate("MainWindow", "Current", 0));
        appconfPpmCurrentNorevButton->setText(QApplication::translate("MainWindow", "Current no reverse", 0));
        appconfPpmPidButton->setText(QApplication::translate("MainWindow", "PID speed control", 0));
        groupBox_20->setTitle(QApplication::translate("MainWindow", "Settings", 0));
#ifndef QT_NO_TOOLTIP
        appconfPpmMedianFilterBox->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Use a median filter to reject niose. This will introduce one sample delay.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        appconfPpmMedianFilterBox->setText(QApplication::translate("MainWindow", "Use Median Filter", 0));
        label_51->setText(QApplication::translate("MainWindow", "Maximum Pulsewidth (ms)", 0));
        label_49->setText(QApplication::translate("MainWindow", "Deadband", 0));
        label_50->setText(QApplication::translate("MainWindow", "Minimum Pulsewidth (ms)", 0));
        label_45->setText(QApplication::translate("MainWindow", "PID max ERPM", 0));
#ifndef QT_NO_TOOLTIP
        appconfPpmSafeStartBox->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Don't give throttle unless the received output has been 0 for at leas 50 pulses. The counter is reset on boot, every time a new configuration is loaded and when a timeout occurs.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        appconfPpmSafeStartBox->setText(QApplication::translate("MainWindow", "Safe Start", 0));
        appconfPpmRpmLimBox->setTitle(QApplication::translate("MainWindow", "Soft RPM limit (current mode only)", 0));
        label_47->setText(QApplication::translate("MainWindow", "ERPM limit start", 0));
        label_48->setText(QApplication::translate("MainWindow", "ERPM limit end", 0));
        appconfPpmMultiGroup->setTitle(QApplication::translate("MainWindow", "Multiple ESCs over CAN", 0));
        appconfPpmTcBox->setText(QApplication::translate("MainWindow", "Enable Traction Control (current mode only)", 0));
        label_67->setText(QApplication::translate("MainWindow", "Traction Control ERPM diff", 0));
        appconfUpdatePpmBox->setTitle(QApplication::translate("MainWindow", "Display", 0));
        appconfDecodedPpmBar->setFormat(QApplication::translate("MainWindow", "%p%", 0));
        label_80->setText(QApplication::translate("MainWindow", "Pulsewidth (ms):", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_17), QApplication::translate("MainWindow", "PPM", 0));
        groupBox_31->setTitle(QApplication::translate("MainWindow", "Control mode", 0));
        appconfAdcCurrentButtonButton->setText(QApplication::translate("MainWindow", "Current button", 0));
        appconfAdcDisabledButton->setText(QApplication::translate("MainWindow", "Disabled", 0));
        appconfAdcCurrentNorevCenterButton->setText(QApplication::translate("MainWindow", "Current norev center", 0));
        appconfAdcCurrentNorevButtonButton->setText(QApplication::translate("MainWindow", "Current norev button", 0));
        appconfAdcCurrentButton->setText(QApplication::translate("MainWindow", "Current", 0));
        appconfAdcCurrentCenterButton->setText(QApplication::translate("MainWindow", "Current center", 0));
        appconfAdcDutyCycleButtonButton->setText(QApplication::translate("MainWindow", "Duty cycle button", 0));
        appconfAdcDutyCycleCenterButton->setText(QApplication::translate("MainWindow", "Duty cycle center", 0));
        appconfAdcDutyCycleButton->setText(QApplication::translate("MainWindow", "Duty cycle", 0));
        appconfAdcCurrentNorevAdcButton->setText(QApplication::translate("MainWindow", "Current norev ADC2", 0));
        groupBox_33->setTitle(QApplication::translate("MainWindow", "Settings", 0));
        appconfAdcUpdateRateBox->setSuffix(QApplication::translate("MainWindow", " Hz", 0));
        label_78->setText(QApplication::translate("MainWindow", "Update Rate", 0));
#ifndef QT_NO_TOOLTIP
        appconfAdcFilterBox->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Use a median filter to reject niose. This will introduce one sample delay.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        appconfAdcFilterBox->setText(QApplication::translate("MainWindow", "Use Filter", 0));
        label_76->setText(QApplication::translate("MainWindow", "Deadband", 0));
#ifndef QT_NO_TOOLTIP
        appconfAdcSafeStartBox->setToolTip(QApplication::translate("MainWindow", "<html><head/><body><p>Don't give throttle unless the received output has been 0 for at leas 50 pulses. The counter is reset on boot, every time a new configuration is loaded and when a timeout occurs.</p></body></html>", 0));
#endif // QT_NO_TOOLTIP
        appconfAdcSafeStartBox->setText(QApplication::translate("MainWindow", "Safe Start", 0));
        appconfAdcVoltageStartBox->setSuffix(QApplication::translate("MainWindow", " V", 0));
        label_77->setText(QApplication::translate("MainWindow", "Minimum Voltage", 0));
        label_75->setText(QApplication::translate("MainWindow", "Maximum Voltage", 0));
        appconfAdcVoltageEndBox->setSuffix(QApplication::translate("MainWindow", " V", 0));
        appconfAdcInvertVoltageBox->setText(QApplication::translate("MainWindow", "Invert Voltage", 0));
        groupBox_36->setTitle(QApplication::translate("MainWindow", "Buttons", 0));
        appconfAdcInvertRevButtonBox->setText(QApplication::translate("MainWindow", "Invert reverse button", 0));
        appconfAdcInvertCcButtonBox->setText(QApplication::translate("MainWindow", "Invert cruise control button", 0));
        textBrowser_2->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:11pt;\">The cruise control button will maintain the current speed while pressed when current control is used and no throttle is given. The reverse button is used to reverse the throttle when one of the corresponding control modes is used.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:"
                        "0px;\"><span style=\" font-size:11pt;\">When only the ADC app is used, the TX pin is used for the cruise control button and the RX pin is used for the reverse button. When the ADC and UART apps are used at the same time, the servo input will be used as the button. In this case it will be used for the reverse button when a control mode with button is selected, otherwise it will be used for the cruise control button.</span></p></body></html>", 0));
        appconfAdcRpmLimBox->setTitle(QApplication::translate("MainWindow", "Soft RPM limit (current mode only)", 0));
        label_73->setText(QApplication::translate("MainWindow", "ERPM limit start", 0));
        label_74->setText(QApplication::translate("MainWindow", "ERPM limit end", 0));
        appconfAdcMultiGroup->setTitle(QApplication::translate("MainWindow", "Multiple ESCs over CAN", 0));
        appconfAdcTcBox->setText(QApplication::translate("MainWindow", "Enable Traction Control (current mode only)", 0));
        label_72->setText(QApplication::translate("MainWindow", "Traction Control ERPM diff", 0));
        appconfAdcUpdateBox->setTitle(QApplication::translate("MainWindow", "Display", 0));
        appconfAdcDecodedBar->setFormat(QApplication::translate("MainWindow", "%p%", 0));
        label_79->setText(QApplication::translate("MainWindow", "ADC (V):", 0));
        lblVoltage2->setText(QApplication::translate("MainWindow", "ADC2 (V):", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_22), QApplication::translate("MainWindow", "ADC", 0));
        groupBox_21->setTitle(QApplication::translate("MainWindow", "Settings", 0));
        label_46->setText(QApplication::translate("MainWindow", "Baud rate", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_18), QApplication::translate("MainWindow", "UART", 0));
        groupBox_24->setTitle(QApplication::translate("MainWindow", "Control mode", 0));
        appconfChukDisabledButton->setText(QApplication::translate("MainWindow", "Disabled", 0));
        appconfChukCurrentNorevButton->setText(QApplication::translate("MainWindow", "Current", 0));
        appconfChukCurrentButton->setText(QApplication::translate("MainWindow", "Current with reverse", 0));
        groupBox_25->setTitle(QApplication::translate("MainWindow", "Settings", 0));
        label_54->setText(QApplication::translate("MainWindow", "Deadband", 0));
        label_63->setText(QApplication::translate("MainWindow", "Positive ramping time constant", 0));
        label_56->setText(QApplication::translate("MainWindow", "ERPM limit start", 0));
        label_64->setText(QApplication::translate("MainWindow", "Negative ramping time constant", 0));
        label_55->setText(QApplication::translate("MainWindow", "ERPM limit end", 0));
        label_88->setText(QApplication::translate("MainWindow", "ERPM/S input in cruise control", 0));
        appconfChukMultiGroup->setTitle(QApplication::translate("MainWindow", "Multiple ESCs over CAN", 0));
        appconfChukTcBox->setText(QApplication::translate("MainWindow", "Enable Traction Control", 0));
        label_66->setText(QApplication::translate("MainWindow", "Traction Control ERPM diff", 0));
        appconfUpdateChukBox->setTitle(QApplication::translate("MainWindow", "Display", 0));
        appconfDecodedChukBar->setFormat(QApplication::translate("MainWindow", "%p%", 0));
        textBrowser->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:11pt;\">This has been tested with the wireless Nyko Kama nunchuk. The receiver can be connected directly to the I2C port on the ESC. The y-axis on the joystick is used for acceleration/braking. The buttons have the following functions:</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px"
                        ";\"><span style=\" font-size:11pt; font-weight:600;\">C-Button:</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:11pt;\">Cruise control. If the C-button is pressed, the ESC will maintail the current speed with a PID control loop. The joystick can still be used to accelerate and brake, but as soon as it is returned to the center position the new speed will be maintained, as long as the C-button remains pressed.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:11pt; font-weight:600;\">Z-Button:</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-inde"
                        "nt:0px;\"><span style=\" font-size:11pt;\">The Z-button is used to change the direction of the motor if reverse is activated. Without reverse, Z has no effect.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:11pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:11pt;\">There is also a safety function. If nothing received from the nunchuk (including the accelerometers) changes for longer than the timeout value in the </span><span style=\" font-size:11pt; font-style:italic;\">General</span><span style=\" font-size:11pt;\"> tab, the timeout function will be activated and either release the motor or brake with the current specified next to the timeout value.</span></p></body></html>", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_21), QApplication::translate("MainWindow", "Nunchuk", 0));
        groupBox_47->setTitle(QApplication::translate("MainWindow", "Speed", 0));
        appconfNrfSpeed250kButton->setText(QApplication::translate("MainWindow", "250K", 0));
        appconfNrfSpeed1mButton->setText(QApplication::translate("MainWindow", "1M", 0));
        appconfNrfSpeed2mButton->setText(QApplication::translate("MainWindow", "2M", 0));
        groupBox_48->setTitle(QApplication::translate("MainWindow", "Power", 0));
        appconfNrfPowerM18Button->setText(QApplication::translate("MainWindow", "-18 dBm", 0));
        appconfNrfPowerM12Button->setText(QApplication::translate("MainWindow", "-12 dBm", 0));
        appconfNrfPowerM6Button->setText(QApplication::translate("MainWindow", "-6 dBm", 0));
        appconfNrfPower0Button->setText(QApplication::translate("MainWindow", "0 dBm", 0));
        groupBox_50->setTitle(QApplication::translate("MainWindow", "CRC", 0));
        appconfNrfCrc1BButton->setText(QApplication::translate("MainWindow", "1 Byte", 0));
        appconfNrfCrc2BButton->setText(QApplication::translate("MainWindow", "2 Byte", 0));
        groupBox_49->setTitle(QApplication::translate("MainWindow", "Ack Retry", 0));
        appconfNrfUseAckBox->setText(QApplication::translate("MainWindow", "Use Ack", 0));
        label_97->setText(QApplication::translate("MainWindow", "Retries", 0));
        label_99->setText(QApplication::translate("MainWindow", "Delay", 0));
        appconfNrfRetrDelayBox->clear();
        appconfNrfRetrDelayBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "250 \302\265s", 0)
         << QApplication::translate("MainWindow", "500 \302\265s", 0)
         << QApplication::translate("MainWindow", "750 \302\265s", 0)
         << QApplication::translate("MainWindow", "1000 \302\265s", 0)
         << QApplication::translate("MainWindow", "1250 \302\265s", 0)
         << QApplication::translate("MainWindow", "1500 \302\265s", 0)
         << QApplication::translate("MainWindow", "1750 \302\265s", 0)
         << QApplication::translate("MainWindow", "2000 \302\265s", 0)
         << QApplication::translate("MainWindow", "2250 \302\265s", 0)
         << QApplication::translate("MainWindow", "2500 \302\265s", 0)
         << QApplication::translate("MainWindow", "2750 \302\265s", 0)
         << QApplication::translate("MainWindow", "3000 \302\265S", 0)
         << QApplication::translate("MainWindow", "3250 \302\265S", 0)
         << QApplication::translate("MainWindow", "3500 \302\265S", 0)
         << QApplication::translate("MainWindow", "3750 \302\265S", 0)
         << QApplication::translate("MainWindow", "4000 \302\265S", 0)
        );
        groupBox_51->setTitle(QApplication::translate("MainWindow", "Channel", 0));
        groupBox_52->setTitle(QApplication::translate("MainWindow", "Address", 0));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_25), QApplication::translate("MainWindow", "NRF", 0));
        appconfReadButton->setText(QApplication::translate("MainWindow", "Read configuration", 0));
        appconfReadDefaultButton->setText(QApplication::translate("MainWindow", "Read default configuration", 0));
        appconfWriteButton->setText(QApplication::translate("MainWindow", "Write configuration", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("MainWindow", "App Configuration", 0));
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_19), QApplication::translate("MainWindow", "Current/Duty", 0));
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_20), QApplication::translate("MainWindow", "Temperatures", 0));
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_28), QApplication::translate("MainWindow", "RPM", 0));
        realtimeAutoScaleBox->setText(QApplication::translate("MainWindow", "Auto Scale", 0));
        realtimeActivateBox->setText(QApplication::translate("MainWindow", "Activate sampling", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_6), QApplication::translate("MainWindow", "Realtime Data", 0));
        showPh1Box->setText(QApplication::translate("MainWindow", "Phase 1", 0));
        showPh2Box->setText(QApplication::translate("MainWindow", "Phase 2", 0));
        showPh3Box->setText(QApplication::translate("MainWindow", "Phase 3", 0));
        showVirtualGndBox->setText(QApplication::translate("MainWindow", "Virtual Ground", 0));
        showPosVoltageBox->setText(QApplication::translate("MainWindow", "Position", 0));
        truncateBox->setText(QApplication::translate("MainWindow", "Truncate non-conducting phases", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "BEMF Plot", 0));
        showCurrent1Box->setText(QApplication::translate("MainWindow", "Current 1", 0));
        showCurrent2Box->setText(QApplication::translate("MainWindow", "Current 2", 0));
        showCurrent3Box->setText(QApplication::translate("MainWindow", "Current 3", 0));
        showTotalCurrentBox->setText(QApplication::translate("MainWindow", "Total current", 0));
        showMcTotalCurrentBox->setText(QApplication::translate("MainWindow", "MC total current", 0));
        showPosCurrentBox->setText(QApplication::translate("MainWindow", "Position", 0));
        currentTimeButton->setText(QApplication::translate("MainWindow", "Time", 0));
        currentSpectrumButton->setText(QApplication::translate("MainWindow", "Spectrum", 0));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_7), QApplication::translate("MainWindow", "Plot", 0));
        filterLogScaleBox->setText(QApplication::translate("MainWindow", "Logscale", 0));
        filterScatterBox->setText(QApplication::translate("MainWindow", "Scatterplot", 0));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_8), QApplication::translate("MainWindow", "Filter 1", 0));
        filterLogScaleBox2->setText(QApplication::translate("MainWindow", "Logscale", 0));
        filterScatterBox2->setText(QApplication::translate("MainWindow", "Scatterplot", 0));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_9), QApplication::translate("MainWindow", "Filter 2", 0));
        groupBox_4->setTitle(QApplication::translate("MainWindow", "Filter 1", 0));
        currentFilterActiveBox->setText(QApplication::translate("MainWindow", "Activate", 0));
        firRadioButton->setText(QApplication::translate("MainWindow", "FIR", 0));
        meanRadioButton->setText(QApplication::translate("MainWindow", "Mean value", 0));
        compDelayBox->setText(QApplication::translate("MainWindow", "Delay Comp", 0));
        label_6->setText(QApplication::translate("MainWindow", "Stop Frequency", 0));
        label_7->setText(QApplication::translate("MainWindow", "Filter Taps (2^)", 0));
        hammingBox->setText(QApplication::translate("MainWindow", "Hammnig", 0));
        groupBox_7->setTitle(QApplication::translate("MainWindow", "Filter 2", 0));
        currentFilterActiveBox2->setText(QApplication::translate("MainWindow", "Activate", 0));
        firRadioButton2->setText(QApplication::translate("MainWindow", "FIR", 0));
        meanRadioButton2->setText(QApplication::translate("MainWindow", "Mean value", 0));
        label_8->setText(QApplication::translate("MainWindow", "Stop Frequency", 0));
        label_9->setText(QApplication::translate("MainWindow", "Filter Taps (2^)", 0));
        hammingBox2->setText(QApplication::translate("MainWindow", "Hamming", 0));
        label_10->setText(QApplication::translate("MainWindow", "Decimation", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Current Plot", 0));
        sendTerminalButton->setText(QApplication::translate("MainWindow", "Send", 0));
        clearTerminalButton->setText(QApplication::translate("MainWindow", "Clear", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_15), QApplication::translate("MainWindow", "Terminal", 0));
        groupBox_23->setTitle(QApplication::translate("MainWindow", "Upload New Firmware", 0));
        label_81->setText(QApplication::translate("MainWindow", "Path", 0));
        firmwareUploadButton->setText(QApplication::translate("MainWindow", "Upload", 0));
        firmwareUploadStatusLabel->setText(QApplication::translate("MainWindow", "FW Upload Status", 0));
        firmwareCancelButton->setText(QApplication::translate("MainWindow", "Cancel", 0));
        firmwareChooseButton->setText(QApplication::translate("MainWindow", "Choose...", 0));
        groupBox_26->setTitle(QApplication::translate("MainWindow", "Firmware Version", 0));
        label_82->setText(QApplication::translate("MainWindow", "Firmware version on connected VESC:", 0));
        firmwareVersionLabel->setText(QApplication::translate("MainWindow", "X.Y", 0));
        firmwareVersionReadButton->setText(QApplication::translate("MainWindow", "Read Firmware Version", 0));
        groupBox_32->setTitle(QApplication::translate("MainWindow", "Supported Firmwares (for this version of BLDC Tool)", 0));
        firmwareSupportedLabel->setText(QApplication::translate("MainWindow", "X.Y", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_23), QApplication::translate("MainWindow", "Firmware", 0));
        detectButton->setText(QApplication::translate("MainWindow", "Inductance", 0));
        stopDetectButton->setText(QApplication::translate("MainWindow", "Stop", 0));
        detectPidPosErrorButton->setText(QApplication::translate("MainWindow", "PID Pos Error", 0));
        detectEncoderButton->setText(QApplication::translate("MainWindow", "Encoder", 0));
        detectObserverButton->setText(QApplication::translate("MainWindow", "Observer", 0));
        detectEncoderObserverErrorButton->setText(QApplication::translate("MainWindow", "Encoder Observer Error", 0));
        detectPidPosButton->setText(QApplication::translate("MainWindow", "PID Pos", 0));
        rotorPosBar->setFormat(QApplication::translate("MainWindow", "%v Degrees", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "Rotor Position", 0));
        experimentSampleLabel->setText(QApplication::translate("MainWindow", "0 Samples", 0));
        experimentClearSamplesButton->setText(QApplication::translate("MainWindow", "Clear samples", 0));
        experimentSaveSamplesButton->setText(QApplication::translate("MainWindow", "Save samples to file...", 0));
        groupBox_6->setTitle(QApplication::translate("MainWindow", "Autosave Samples", 0));
        label_14->setText(QApplication::translate("MainWindow", "Path", 0));
        experimentAutosaveBox->setText(QApplication::translate("MainWindow", "Use autosave", 0));
        label_13->setText(QApplication::translate("MainWindow", "Autosave every", 0));
        label_15->setText(QApplication::translate("MainWindow", "samples", 0));
        groupBox_35->setTitle(QApplication::translate("MainWindow", "Servo Output", 0));
        tabWidget->setTabText(tabWidget->indexOf(tab_10), QApplication::translate("MainWindow", "Experiment", 0));
        refreshButton->setText(QString());
        serialConnectButton->setText(QApplication::translate("MainWindow", "Connect", 0));
        toolBox->setItemText(toolBox->indexOf(page), QApplication::translate("MainWindow", "Serial Connection", 0));
        udpConnectButton->setText(QApplication::translate("MainWindow", "Connect", 0));
        toolBox->setItemText(toolBox->indexOf(page_2), QApplication::translate("MainWindow", "UDP Connection", 0));
        disconnectButton->setText(QApplication::translate("MainWindow", "Disconnect", 0));
        appconfRebootButton->setText(QApplication::translate("MainWindow", "Reboot", 0));
        canFwdBox->setText(QApplication::translate("MainWindow", "CAN Fwd", 0));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Control", 0));
        dutyButton->setText(QApplication::translate("MainWindow", "Duty", 0));
        rpmButton->setText(QApplication::translate("MainWindow", "RPM", 0));
        currentBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        currentButton->setText(QApplication::translate("MainWindow", "Current", 0));
        currentBrakeButton->setText(QApplication::translate("MainWindow", "Brake", 0));
        posCtrlButton->setText(QApplication::translate("MainWindow", "Position", 0));
        currentBrakeBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        overrideKbBox->setText(QApplication::translate("MainWindow", "KB Ctrl", 0));
        arrowCurrentBox->setPrefix(QApplication::translate("MainWindow", "I: ", 0));
        arrowCurrentBox->setSuffix(QApplication::translate("MainWindow", " A", 0));
        offBrakeButton->setText(QApplication::translate("MainWindow", "Full Brake", 0));
        tabWidget_6->setTabText(tabWidget_6->indexOf(tab_26), QApplication::translate("MainWindow", "Control", 0));
        groupBox->setTitle(QApplication::translate("MainWindow", "BEMF and Current Sampling", 0));
        label->setText(QApplication::translate("MainWindow", "Samples", 0));
        label_2->setText(QApplication::translate("MainWindow", "Decimation", 0));
        label_5->setText(QApplication::translate("MainWindow", "Fs for FFT", 0));
        getDataButton->setText(QApplication::translate("MainWindow", "Now", 0));
        getDataStartButton->setText(QApplication::translate("MainWindow", "At start", 0));
        groupBox_5->setTitle(QApplication::translate("MainWindow", "Plot Control", 0));
        horizontalZoomBox->setText(QApplication::translate("MainWindow", "HZoom", 0));
        verticalZoomBox->setText(QApplication::translate("MainWindow", "VZoom", 0));
        rescaleButton->setText(QApplication::translate("MainWindow", "Rescale", 0));
        replotButton->setText(QApplication::translate("MainWindow", "Replot", 0));
        tabWidget_6->setTabText(tabWidget_6->indexOf(tab_27), QApplication::translate("MainWindow", "Plot and Sample", 0));
        offButton->setText(QApplication::translate("MainWindow", "Release Motor (ESC)", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
