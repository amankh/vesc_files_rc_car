/****************************************************************************
** Meta object code from reading C++ file 'qcustomplot.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "qcustomplot.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#include <QtCore/QVector>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qcustomplot.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_QCPScatterStyle_t {
    QByteArrayData data[20];
    char stringdata0[209];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPScatterStyle_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPScatterStyle_t qt_meta_stringdata_QCPScatterStyle = {
    {
QT_MOC_LITERAL(0, 0, 15), // "QCPScatterStyle"
QT_MOC_LITERAL(1, 16, 12), // "ScatterShape"
QT_MOC_LITERAL(2, 29, 6), // "ssNone"
QT_MOC_LITERAL(3, 36, 5), // "ssDot"
QT_MOC_LITERAL(4, 42, 7), // "ssCross"
QT_MOC_LITERAL(5, 50, 6), // "ssPlus"
QT_MOC_LITERAL(6, 57, 8), // "ssCircle"
QT_MOC_LITERAL(7, 66, 6), // "ssDisc"
QT_MOC_LITERAL(8, 73, 8), // "ssSquare"
QT_MOC_LITERAL(9, 82, 9), // "ssDiamond"
QT_MOC_LITERAL(10, 92, 6), // "ssStar"
QT_MOC_LITERAL(11, 99, 10), // "ssTriangle"
QT_MOC_LITERAL(12, 110, 18), // "ssTriangleInverted"
QT_MOC_LITERAL(13, 129, 13), // "ssCrossSquare"
QT_MOC_LITERAL(14, 143, 12), // "ssPlusSquare"
QT_MOC_LITERAL(15, 156, 13), // "ssCrossCircle"
QT_MOC_LITERAL(16, 170, 12), // "ssPlusCircle"
QT_MOC_LITERAL(17, 183, 7), // "ssPeace"
QT_MOC_LITERAL(18, 191, 8), // "ssPixmap"
QT_MOC_LITERAL(19, 200, 8) // "ssCustom"

    },
    "QCPScatterStyle\0ScatterShape\0ssNone\0"
    "ssDot\0ssCross\0ssPlus\0ssCircle\0ssDisc\0"
    "ssSquare\0ssDiamond\0ssStar\0ssTriangle\0"
    "ssTriangleInverted\0ssCrossSquare\0"
    "ssPlusSquare\0ssCrossCircle\0ssPlusCircle\0"
    "ssPeace\0ssPixmap\0ssCustom"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPScatterStyle[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       4,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,   18,   18,

 // enum data: key, value
       2, uint(QCPScatterStyle::ssNone),
       3, uint(QCPScatterStyle::ssDot),
       4, uint(QCPScatterStyle::ssCross),
       5, uint(QCPScatterStyle::ssPlus),
       6, uint(QCPScatterStyle::ssCircle),
       7, uint(QCPScatterStyle::ssDisc),
       8, uint(QCPScatterStyle::ssSquare),
       9, uint(QCPScatterStyle::ssDiamond),
      10, uint(QCPScatterStyle::ssStar),
      11, uint(QCPScatterStyle::ssTriangle),
      12, uint(QCPScatterStyle::ssTriangleInverted),
      13, uint(QCPScatterStyle::ssCrossSquare),
      14, uint(QCPScatterStyle::ssPlusSquare),
      15, uint(QCPScatterStyle::ssCrossCircle),
      16, uint(QCPScatterStyle::ssPlusCircle),
      17, uint(QCPScatterStyle::ssPeace),
      18, uint(QCPScatterStyle::ssPixmap),
      19, uint(QCPScatterStyle::ssCustom),

       0        // eod
};

const QMetaObject QCPScatterStyle::staticMetaObject = {
    { Q_NULLPTR, qt_meta_stringdata_QCPScatterStyle.data,
      qt_meta_data_QCPScatterStyle,  Q_NULLPTR, Q_NULLPTR, Q_NULLPTR}
};

struct qt_meta_stringdata_QCPPainter_t {
    QByteArrayData data[7];
    char stringdata0[85];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPPainter_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPPainter_t qt_meta_stringdata_QCPPainter = {
    {
QT_MOC_LITERAL(0, 0, 10), // "QCPPainter"
QT_MOC_LITERAL(1, 11, 11), // "PainterMode"
QT_MOC_LITERAL(2, 23, 9), // "pmDefault"
QT_MOC_LITERAL(3, 33, 12), // "pmVectorized"
QT_MOC_LITERAL(4, 46, 11), // "pmNoCaching"
QT_MOC_LITERAL(5, 58, 13), // "pmNonCosmetic"
QT_MOC_LITERAL(6, 72, 12) // "PainterModes"

    },
    "QCPPainter\0PainterMode\0pmDefault\0"
    "pmVectorized\0pmNoCaching\0pmNonCosmetic\0"
    "PainterModes"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPPainter[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       2,   14, // enums/sets
       0,    0, // constructors
       4,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x1,    4,   22,
       6, 0x1,    4,   30,

 // enum data: key, value
       2, uint(QCPPainter::pmDefault),
       3, uint(QCPPainter::pmVectorized),
       4, uint(QCPPainter::pmNoCaching),
       5, uint(QCPPainter::pmNonCosmetic),
       2, uint(QCPPainter::pmDefault),
       3, uint(QCPPainter::pmVectorized),
       4, uint(QCPPainter::pmNoCaching),
       5, uint(QCPPainter::pmNonCosmetic),

       0        // eod
};

const QMetaObject QCPPainter::staticMetaObject = {
    { &QPainter::staticMetaObject, qt_meta_stringdata_QCPPainter.data,
      qt_meta_data_QCPPainter,  Q_NULLPTR, Q_NULLPTR, Q_NULLPTR}
};

struct qt_meta_stringdata_QCPLayer_t {
    QByteArrayData data[8];
    char stringdata0[82];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayer_t qt_meta_stringdata_QCPLayer = {
    {
QT_MOC_LITERAL(0, 0, 8), // "QCPLayer"
QT_MOC_LITERAL(1, 9, 10), // "parentPlot"
QT_MOC_LITERAL(2, 20, 12), // "QCustomPlot*"
QT_MOC_LITERAL(3, 33, 4), // "name"
QT_MOC_LITERAL(4, 38, 5), // "index"
QT_MOC_LITERAL(5, 44, 8), // "children"
QT_MOC_LITERAL(6, 53, 20), // "QList<QCPLayerable*>"
QT_MOC_LITERAL(7, 74, 7) // "visible"

    },
    "QCPLayer\0parentPlot\0QCustomPlot*\0name\0"
    "index\0children\0QList<QCPLayerable*>\0"
    "visible"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayer[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       5,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x00095009,
       3, QMetaType::QString, 0x00095001,
       4, QMetaType::Int, 0x00095001,
       5, 0x80000000 | 6, 0x00095009,
       7, QMetaType::Bool, 0x00095103,

       0        // eod
};

void QCPLayer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCustomPlot* >(); break;
        case 3:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QCPLayerable*> >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPLayer *_t = static_cast<QCPLayer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCustomPlot**>(_v) = _t->parentPlot(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->name(); break;
        case 2: *reinterpret_cast< int*>(_v) = _t->index(); break;
        case 3: *reinterpret_cast< QList<QCPLayerable*>*>(_v) = _t->children(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->visible(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPLayer *_t = static_cast<QCPLayer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 4: _t->setVisible(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
}

const QMetaObject QCPLayer::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPLayer.data,
      qt_meta_data_QCPLayer,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPLayer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayer::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayer.stringdata0))
        return static_cast<void*>(const_cast< QCPLayer*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPLayer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPLayerable_t {
    QByteArrayData data[13];
    char stringdata0[135];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayerable_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayerable_t qt_meta_stringdata_QCPLayerable = {
    {
QT_MOC_LITERAL(0, 0, 12), // "QCPLayerable"
QT_MOC_LITERAL(1, 13, 12), // "layerChanged"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 9), // "QCPLayer*"
QT_MOC_LITERAL(4, 37, 8), // "newLayer"
QT_MOC_LITERAL(5, 46, 8), // "setLayer"
QT_MOC_LITERAL(6, 55, 5), // "layer"
QT_MOC_LITERAL(7, 61, 7), // "visible"
QT_MOC_LITERAL(8, 69, 10), // "parentPlot"
QT_MOC_LITERAL(9, 80, 12), // "QCustomPlot*"
QT_MOC_LITERAL(10, 93, 15), // "parentLayerable"
QT_MOC_LITERAL(11, 109, 13), // "QCPLayerable*"
QT_MOC_LITERAL(12, 123, 11) // "antialiased"

    },
    "QCPLayerable\0layerChanged\0\0QCPLayer*\0"
    "newLayer\0setLayer\0layer\0visible\0"
    "parentPlot\0QCustomPlot*\0parentLayerable\0"
    "QCPLayerable*\0antialiased"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayerable[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       5,   30, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   27,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Bool, 0x80000000 | 3,    6,

 // properties: name, type, flags
       7, QMetaType::Bool, 0x00095103,
       8, 0x80000000 | 9, 0x00095009,
      10, 0x80000000 | 11, 0x00095009,
       6, 0x80000000 | 3, 0x0049510b,
      12, QMetaType::Bool, 0x00095103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,

       0        // eod
};

void QCPLayerable::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPLayerable *_t = static_cast<QCPLayerable *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->layerChanged((*reinterpret_cast< QCPLayer*(*)>(_a[1]))); break;
        case 1: { bool _r = _t->setLayer((*reinterpret_cast< QCPLayer*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayer* >(); break;
            }
            break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayer* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPLayerable::*_t)(QCPLayer * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPLayerable::layerChanged)) {
                *result = 0;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 3:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayer* >(); break;
        case 2:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayerable* >(); break;
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCustomPlot* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPLayerable *_t = static_cast<QCPLayerable *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->visible(); break;
        case 1: *reinterpret_cast< QCustomPlot**>(_v) = _t->parentPlot(); break;
        case 2: *reinterpret_cast< QCPLayerable**>(_v) = _t->parentLayerable(); break;
        case 3: *reinterpret_cast< QCPLayer**>(_v) = _t->layer(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->antialiased(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPLayerable *_t = static_cast<QCPLayerable *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setVisible(*reinterpret_cast< bool*>(_v)); break;
        case 3: _t->setLayer(*reinterpret_cast< QCPLayer**>(_v)); break;
        case 4: _t->setAntialiased(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QCPLayerable::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPLayerable.data,
      qt_meta_data_QCPLayerable,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPLayerable::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayerable::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayerable.stringdata0))
        return static_cast<void*>(const_cast< QCPLayerable*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPLayerable::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPLayerable::layerChanged(QCPLayer * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
struct qt_meta_stringdata_QCPMarginGroup_t {
    QByteArrayData data[1];
    char stringdata0[15];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPMarginGroup_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPMarginGroup_t qt_meta_stringdata_QCPMarginGroup = {
    {
QT_MOC_LITERAL(0, 0, 14) // "QCPMarginGroup"

    },
    "QCPMarginGroup"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPMarginGroup[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QCPMarginGroup::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPMarginGroup::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPMarginGroup.data,
      qt_meta_data_QCPMarginGroup,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPMarginGroup::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPMarginGroup::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPMarginGroup.stringdata0))
        return static_cast<void*>(const_cast< QCPMarginGroup*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPMarginGroup::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QCPLayoutElement_t {
    QByteArrayData data[14];
    char stringdata0[151];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayoutElement_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayoutElement_t qt_meta_stringdata_QCPLayoutElement = {
    {
QT_MOC_LITERAL(0, 0, 16), // "QCPLayoutElement"
QT_MOC_LITERAL(1, 17, 6), // "layout"
QT_MOC_LITERAL(2, 24, 10), // "QCPLayout*"
QT_MOC_LITERAL(3, 35, 4), // "rect"
QT_MOC_LITERAL(4, 40, 9), // "outerRect"
QT_MOC_LITERAL(5, 50, 7), // "margins"
QT_MOC_LITERAL(6, 58, 8), // "QMargins"
QT_MOC_LITERAL(7, 67, 14), // "minimumMargins"
QT_MOC_LITERAL(8, 82, 11), // "minimumSize"
QT_MOC_LITERAL(9, 94, 11), // "maximumSize"
QT_MOC_LITERAL(10, 106, 11), // "UpdatePhase"
QT_MOC_LITERAL(11, 118, 13), // "upPreparation"
QT_MOC_LITERAL(12, 132, 9), // "upMargins"
QT_MOC_LITERAL(13, 142, 8) // "upLayout"

    },
    "QCPLayoutElement\0layout\0QCPLayout*\0"
    "rect\0outerRect\0margins\0QMargins\0"
    "minimumMargins\0minimumSize\0maximumSize\0"
    "UpdatePhase\0upPreparation\0upMargins\0"
    "upLayout"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayoutElement[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       7,   14, // properties
       1,   35, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x00095009,
       3, QMetaType::QRect, 0x00095001,
       4, QMetaType::QRect, 0x00095103,
       5, 0x80000000 | 6, 0x0009510b,
       7, 0x80000000 | 6, 0x0009510b,
       8, QMetaType::QSize, 0x00095103,
       9, QMetaType::QSize, 0x00095103,

 // enums: name, flags, count, data
      10, 0x0,    3,   39,

 // enum data: key, value
      11, uint(QCPLayoutElement::upPreparation),
      12, uint(QCPLayoutElement::upMargins),
      13, uint(QCPLayoutElement::upLayout),

       0        // eod
};

void QCPLayoutElement::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayout* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPLayoutElement *_t = static_cast<QCPLayoutElement *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPLayout**>(_v) = _t->layout(); break;
        case 1: *reinterpret_cast< QRect*>(_v) = _t->rect(); break;
        case 2: *reinterpret_cast< QRect*>(_v) = _t->outerRect(); break;
        case 3: *reinterpret_cast< QMargins*>(_v) = _t->margins(); break;
        case 4: *reinterpret_cast< QMargins*>(_v) = _t->minimumMargins(); break;
        case 5: *reinterpret_cast< QSize*>(_v) = _t->minimumSize(); break;
        case 6: *reinterpret_cast< QSize*>(_v) = _t->maximumSize(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPLayoutElement *_t = static_cast<QCPLayoutElement *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 2: _t->setOuterRect(*reinterpret_cast< QRect*>(_v)); break;
        case 3: _t->setMargins(*reinterpret_cast< QMargins*>(_v)); break;
        case 4: _t->setMinimumMargins(*reinterpret_cast< QMargins*>(_v)); break;
        case 5: _t->setMinimumSize(*reinterpret_cast< QSize*>(_v)); break;
        case 6: _t->setMaximumSize(*reinterpret_cast< QSize*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
}

const QMetaObject QCPLayoutElement::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPLayoutElement.data,
      qt_meta_data_QCPLayoutElement,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPLayoutElement::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayoutElement::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayoutElement.stringdata0))
        return static_cast<void*>(const_cast< QCPLayoutElement*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPLayoutElement::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPLayout_t {
    QByteArrayData data[1];
    char stringdata0[10];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayout_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayout_t qt_meta_stringdata_QCPLayout = {
    {
QT_MOC_LITERAL(0, 0, 9) // "QCPLayout"

    },
    "QCPLayout"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayout[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QCPLayout::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPLayout::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPLayout.data,
      qt_meta_data_QCPLayout,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPLayout::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayout::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayout.stringdata0))
        return static_cast<void*>(const_cast< QCPLayout*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPLayout::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QCPLayoutGrid_t {
    QByteArrayData data[8];
    char stringdata0[113];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayoutGrid_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayoutGrid_t qt_meta_stringdata_QCPLayoutGrid = {
    {
QT_MOC_LITERAL(0, 0, 13), // "QCPLayoutGrid"
QT_MOC_LITERAL(1, 14, 8), // "rowCount"
QT_MOC_LITERAL(2, 23, 11), // "columnCount"
QT_MOC_LITERAL(3, 35, 20), // "columnStretchFactors"
QT_MOC_LITERAL(4, 56, 13), // "QList<double>"
QT_MOC_LITERAL(5, 70, 17), // "rowStretchFactors"
QT_MOC_LITERAL(6, 88, 13), // "columnSpacing"
QT_MOC_LITERAL(7, 102, 10) // "rowSpacing"

    },
    "QCPLayoutGrid\0rowCount\0columnCount\0"
    "columnStretchFactors\0QList<double>\0"
    "rowStretchFactors\0columnSpacing\0"
    "rowSpacing"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayoutGrid[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       6,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::Int, 0x00095001,
       2, QMetaType::Int, 0x00095001,
       3, 0x80000000 | 4, 0x0009510b,
       5, 0x80000000 | 4, 0x0009510b,
       6, QMetaType::Int, 0x00095103,
       7, QMetaType::Int, 0x00095103,

       0        // eod
};

void QCPLayoutGrid::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 3:
        case 2:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<double> >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPLayoutGrid *_t = static_cast<QCPLayoutGrid *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->rowCount(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->columnCount(); break;
        case 2: *reinterpret_cast< QList<double>*>(_v) = _t->columnStretchFactors(); break;
        case 3: *reinterpret_cast< QList<double>*>(_v) = _t->rowStretchFactors(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->columnSpacing(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->rowSpacing(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPLayoutGrid *_t = static_cast<QCPLayoutGrid *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 2: _t->setColumnStretchFactors(*reinterpret_cast< QList<double>*>(_v)); break;
        case 3: _t->setRowStretchFactors(*reinterpret_cast< QList<double>*>(_v)); break;
        case 4: _t->setColumnSpacing(*reinterpret_cast< int*>(_v)); break;
        case 5: _t->setRowSpacing(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
}

const QMetaObject QCPLayoutGrid::staticMetaObject = {
    { &QCPLayout::staticMetaObject, qt_meta_stringdata_QCPLayoutGrid.data,
      qt_meta_data_QCPLayoutGrid,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPLayoutGrid::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayoutGrid::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayoutGrid.stringdata0))
        return static_cast<void*>(const_cast< QCPLayoutGrid*>(this));
    return QCPLayout::qt_metacast(_clname);
}

int QCPLayoutGrid::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayout::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPLayoutInset_t {
    QByteArrayData data[1];
    char stringdata0[15];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayoutInset_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayoutInset_t qt_meta_stringdata_QCPLayoutInset = {
    {
QT_MOC_LITERAL(0, 0, 14) // "QCPLayoutInset"

    },
    "QCPLayoutInset"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayoutInset[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QCPLayoutInset::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPLayoutInset::staticMetaObject = {
    { &QCPLayout::staticMetaObject, qt_meta_stringdata_QCPLayoutInset.data,
      qt_meta_data_QCPLayoutInset,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPLayoutInset::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayoutInset::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayoutInset.stringdata0))
        return static_cast<void*>(const_cast< QCPLayoutInset*>(this));
    return QCPLayout::qt_metacast(_clname);
}

int QCPLayoutInset::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayout::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QCPLineEnding_t {
    QByteArrayData data[12];
    char stringdata0[124];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLineEnding_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLineEnding_t qt_meta_stringdata_QCPLineEnding = {
    {
QT_MOC_LITERAL(0, 0, 13), // "QCPLineEnding"
QT_MOC_LITERAL(1, 14, 11), // "EndingStyle"
QT_MOC_LITERAL(2, 26, 6), // "esNone"
QT_MOC_LITERAL(3, 33, 11), // "esFlatArrow"
QT_MOC_LITERAL(4, 45, 12), // "esSpikeArrow"
QT_MOC_LITERAL(5, 58, 11), // "esLineArrow"
QT_MOC_LITERAL(6, 70, 6), // "esDisc"
QT_MOC_LITERAL(7, 77, 8), // "esSquare"
QT_MOC_LITERAL(8, 86, 9), // "esDiamond"
QT_MOC_LITERAL(9, 96, 5), // "esBar"
QT_MOC_LITERAL(10, 102, 9), // "esHalfBar"
QT_MOC_LITERAL(11, 112, 11) // "esSkewedBar"

    },
    "QCPLineEnding\0EndingStyle\0esNone\0"
    "esFlatArrow\0esSpikeArrow\0esLineArrow\0"
    "esDisc\0esSquare\0esDiamond\0esBar\0"
    "esHalfBar\0esSkewedBar"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLineEnding[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       4,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,   10,   18,

 // enum data: key, value
       2, uint(QCPLineEnding::esNone),
       3, uint(QCPLineEnding::esFlatArrow),
       4, uint(QCPLineEnding::esSpikeArrow),
       5, uint(QCPLineEnding::esLineArrow),
       6, uint(QCPLineEnding::esDisc),
       7, uint(QCPLineEnding::esSquare),
       8, uint(QCPLineEnding::esDiamond),
       9, uint(QCPLineEnding::esBar),
      10, uint(QCPLineEnding::esHalfBar),
      11, uint(QCPLineEnding::esSkewedBar),

       0        // eod
};

const QMetaObject QCPLineEnding::staticMetaObject = {
    { Q_NULLPTR, qt_meta_stringdata_QCPLineEnding.data,
      qt_meta_data_QCPLineEnding,  Q_NULLPTR, Q_NULLPTR, Q_NULLPTR}
};

struct qt_meta_stringdata_QCPGrid_t {
    QByteArrayData data[7];
    char stringdata0[89];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPGrid_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPGrid_t qt_meta_stringdata_QCPGrid = {
    {
QT_MOC_LITERAL(0, 0, 7), // "QCPGrid"
QT_MOC_LITERAL(1, 8, 14), // "subGridVisible"
QT_MOC_LITERAL(2, 23, 18), // "antialiasedSubGrid"
QT_MOC_LITERAL(3, 42, 19), // "antialiasedZeroLine"
QT_MOC_LITERAL(4, 62, 3), // "pen"
QT_MOC_LITERAL(5, 66, 10), // "subGridPen"
QT_MOC_LITERAL(6, 77, 11) // "zeroLinePen"

    },
    "QCPGrid\0subGridVisible\0antialiasedSubGrid\0"
    "antialiasedZeroLine\0pen\0subGridPen\0"
    "zeroLinePen"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPGrid[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       6,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::Bool, 0x00095103,
       2, QMetaType::Bool, 0x00095103,
       3, QMetaType::Bool, 0x00095103,
       4, QMetaType::QPen, 0x00095103,
       5, QMetaType::QPen, 0x00095103,
       6, QMetaType::QPen, 0x00095103,

       0        // eod
};

void QCPGrid::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPGrid *_t = static_cast<QCPGrid *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->subGridVisible(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->antialiasedSubGrid(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->antialiasedZeroLine(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 4: *reinterpret_cast< QPen*>(_v) = _t->subGridPen(); break;
        case 5: *reinterpret_cast< QPen*>(_v) = _t->zeroLinePen(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPGrid *_t = static_cast<QCPGrid *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setSubGridVisible(*reinterpret_cast< bool*>(_v)); break;
        case 1: _t->setAntialiasedSubGrid(*reinterpret_cast< bool*>(_v)); break;
        case 2: _t->setAntialiasedZeroLine(*reinterpret_cast< bool*>(_v)); break;
        case 3: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: _t->setSubGridPen(*reinterpret_cast< QPen*>(_v)); break;
        case 5: _t->setZeroLinePen(*reinterpret_cast< QPen*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPGrid::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPGrid.data,
      qt_meta_data_QCPGrid,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPGrid::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPGrid::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPGrid.stringdata0))
        return static_cast<void*>(const_cast< QCPGrid*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPGrid::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPAxis_t {
    QByteArrayData data[93];
    char stringdata0[1153];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAxis_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAxis_t qt_meta_stringdata_QCPAxis = {
    {
QT_MOC_LITERAL(0, 0, 7), // "QCPAxis"
QT_MOC_LITERAL(1, 8, 12), // "ticksRequest"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 12), // "rangeChanged"
QT_MOC_LITERAL(4, 35, 8), // "QCPRange"
QT_MOC_LITERAL(5, 44, 8), // "newRange"
QT_MOC_LITERAL(6, 53, 8), // "oldRange"
QT_MOC_LITERAL(7, 62, 16), // "scaleTypeChanged"
QT_MOC_LITERAL(8, 79, 18), // "QCPAxis::ScaleType"
QT_MOC_LITERAL(9, 98, 9), // "scaleType"
QT_MOC_LITERAL(10, 108, 16), // "selectionChanged"
QT_MOC_LITERAL(11, 125, 24), // "QCPAxis::SelectableParts"
QT_MOC_LITERAL(12, 150, 5), // "parts"
QT_MOC_LITERAL(13, 156, 17), // "selectableChanged"
QT_MOC_LITERAL(14, 174, 12), // "setScaleType"
QT_MOC_LITERAL(15, 187, 4), // "type"
QT_MOC_LITERAL(16, 192, 8), // "setRange"
QT_MOC_LITERAL(17, 201, 5), // "range"
QT_MOC_LITERAL(18, 207, 18), // "setSelectableParts"
QT_MOC_LITERAL(19, 226, 15), // "selectableParts"
QT_MOC_LITERAL(20, 242, 16), // "setSelectedParts"
QT_MOC_LITERAL(21, 259, 13), // "selectedParts"
QT_MOC_LITERAL(22, 273, 8), // "axisType"
QT_MOC_LITERAL(23, 282, 8), // "AxisType"
QT_MOC_LITERAL(24, 291, 8), // "axisRect"
QT_MOC_LITERAL(25, 300, 12), // "QCPAxisRect*"
QT_MOC_LITERAL(26, 313, 9), // "ScaleType"
QT_MOC_LITERAL(27, 323, 12), // "scaleLogBase"
QT_MOC_LITERAL(28, 336, 13), // "rangeReversed"
QT_MOC_LITERAL(29, 350, 9), // "autoTicks"
QT_MOC_LITERAL(30, 360, 13), // "autoTickCount"
QT_MOC_LITERAL(31, 374, 14), // "autoTickLabels"
QT_MOC_LITERAL(32, 389, 12), // "autoTickStep"
QT_MOC_LITERAL(33, 402, 12), // "autoSubTicks"
QT_MOC_LITERAL(34, 415, 5), // "ticks"
QT_MOC_LITERAL(35, 421, 10), // "tickLabels"
QT_MOC_LITERAL(36, 432, 16), // "tickLabelPadding"
QT_MOC_LITERAL(37, 449, 13), // "tickLabelType"
QT_MOC_LITERAL(38, 463, 9), // "LabelType"
QT_MOC_LITERAL(39, 473, 13), // "tickLabelFont"
QT_MOC_LITERAL(40, 487, 14), // "tickLabelColor"
QT_MOC_LITERAL(41, 502, 17), // "tickLabelRotation"
QT_MOC_LITERAL(42, 520, 14), // "dateTimeFormat"
QT_MOC_LITERAL(43, 535, 12), // "dateTimeSpec"
QT_MOC_LITERAL(44, 548, 12), // "Qt::TimeSpec"
QT_MOC_LITERAL(45, 561, 12), // "numberFormat"
QT_MOC_LITERAL(46, 574, 15), // "numberPrecision"
QT_MOC_LITERAL(47, 590, 8), // "tickStep"
QT_MOC_LITERAL(48, 599, 10), // "tickVector"
QT_MOC_LITERAL(49, 610, 15), // "QVector<double>"
QT_MOC_LITERAL(50, 626, 16), // "tickVectorLabels"
QT_MOC_LITERAL(51, 643, 16), // "QVector<QString>"
QT_MOC_LITERAL(52, 660, 12), // "tickLengthIn"
QT_MOC_LITERAL(53, 673, 13), // "tickLengthOut"
QT_MOC_LITERAL(54, 687, 12), // "subTickCount"
QT_MOC_LITERAL(55, 700, 15), // "subTickLengthIn"
QT_MOC_LITERAL(56, 716, 16), // "subTickLengthOut"
QT_MOC_LITERAL(57, 733, 7), // "basePen"
QT_MOC_LITERAL(58, 741, 7), // "tickPen"
QT_MOC_LITERAL(59, 749, 10), // "subTickPen"
QT_MOC_LITERAL(60, 760, 9), // "labelFont"
QT_MOC_LITERAL(61, 770, 10), // "labelColor"
QT_MOC_LITERAL(62, 781, 5), // "label"
QT_MOC_LITERAL(63, 787, 12), // "labelPadding"
QT_MOC_LITERAL(64, 800, 7), // "padding"
QT_MOC_LITERAL(65, 808, 6), // "offset"
QT_MOC_LITERAL(66, 815, 15), // "SelectableParts"
QT_MOC_LITERAL(67, 831, 21), // "selectedTickLabelFont"
QT_MOC_LITERAL(68, 853, 17), // "selectedLabelFont"
QT_MOC_LITERAL(69, 871, 22), // "selectedTickLabelColor"
QT_MOC_LITERAL(70, 894, 18), // "selectedLabelColor"
QT_MOC_LITERAL(71, 913, 15), // "selectedBasePen"
QT_MOC_LITERAL(72, 929, 15), // "selectedTickPen"
QT_MOC_LITERAL(73, 945, 18), // "selectedSubTickPen"
QT_MOC_LITERAL(74, 964, 11), // "lowerEnding"
QT_MOC_LITERAL(75, 976, 13), // "QCPLineEnding"
QT_MOC_LITERAL(76, 990, 11), // "upperEnding"
QT_MOC_LITERAL(77, 1002, 4), // "grid"
QT_MOC_LITERAL(78, 1007, 8), // "QCPGrid*"
QT_MOC_LITERAL(79, 1016, 6), // "atLeft"
QT_MOC_LITERAL(80, 1023, 7), // "atRight"
QT_MOC_LITERAL(81, 1031, 5), // "atTop"
QT_MOC_LITERAL(82, 1037, 8), // "atBottom"
QT_MOC_LITERAL(83, 1046, 9), // "AxisTypes"
QT_MOC_LITERAL(84, 1056, 8), // "ltNumber"
QT_MOC_LITERAL(85, 1065, 10), // "ltDateTime"
QT_MOC_LITERAL(86, 1076, 8), // "stLinear"
QT_MOC_LITERAL(87, 1085, 13), // "stLogarithmic"
QT_MOC_LITERAL(88, 1099, 14), // "SelectablePart"
QT_MOC_LITERAL(89, 1114, 6), // "spNone"
QT_MOC_LITERAL(90, 1121, 6), // "spAxis"
QT_MOC_LITERAL(91, 1128, 12), // "spTickLabels"
QT_MOC_LITERAL(92, 1141, 11) // "spAxisLabel"

    },
    "QCPAxis\0ticksRequest\0\0rangeChanged\0"
    "QCPRange\0newRange\0oldRange\0scaleTypeChanged\0"
    "QCPAxis::ScaleType\0scaleType\0"
    "selectionChanged\0QCPAxis::SelectableParts\0"
    "parts\0selectableChanged\0setScaleType\0"
    "type\0setRange\0range\0setSelectableParts\0"
    "selectableParts\0setSelectedParts\0"
    "selectedParts\0axisType\0AxisType\0"
    "axisRect\0QCPAxisRect*\0ScaleType\0"
    "scaleLogBase\0rangeReversed\0autoTicks\0"
    "autoTickCount\0autoTickLabels\0autoTickStep\0"
    "autoSubTicks\0ticks\0tickLabels\0"
    "tickLabelPadding\0tickLabelType\0LabelType\0"
    "tickLabelFont\0tickLabelColor\0"
    "tickLabelRotation\0dateTimeFormat\0"
    "dateTimeSpec\0Qt::TimeSpec\0numberFormat\0"
    "numberPrecision\0tickStep\0tickVector\0"
    "QVector<double>\0tickVectorLabels\0"
    "QVector<QString>\0tickLengthIn\0"
    "tickLengthOut\0subTickCount\0subTickLengthIn\0"
    "subTickLengthOut\0basePen\0tickPen\0"
    "subTickPen\0labelFont\0labelColor\0label\0"
    "labelPadding\0padding\0offset\0SelectableParts\0"
    "selectedTickLabelFont\0selectedLabelFont\0"
    "selectedTickLabelColor\0selectedLabelColor\0"
    "selectedBasePen\0selectedTickPen\0"
    "selectedSubTickPen\0lowerEnding\0"
    "QCPLineEnding\0upperEnding\0grid\0QCPGrid*\0"
    "atLeft\0atRight\0atTop\0atBottom\0AxisTypes\0"
    "ltNumber\0ltDateTime\0stLinear\0stLogarithmic\0"
    "SelectablePart\0spNone\0spAxis\0spTickLabels\0"
    "spAxisLabel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAxis[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
      51,   94, // properties
       6,  298, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   64,    2, 0x06 /* Public */,
       3,    1,   65,    2, 0x06 /* Public */,
       3,    2,   68,    2, 0x06 /* Public */,
       7,    1,   73,    2, 0x06 /* Public */,
      10,    1,   76,    2, 0x06 /* Public */,
      13,    1,   79,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      14,    1,   82,    2, 0x0a /* Public */,
      16,    1,   85,    2, 0x0a /* Public */,
      18,    1,   88,    2, 0x0a /* Public */,
      20,    1,   91,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void, 0x80000000 | 4, 0x80000000 | 4,    5,    6,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void, 0x80000000 | 11,   12,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 8,   15,
    QMetaType::Void, 0x80000000 | 4,   17,
    QMetaType::Void, 0x80000000 | 11,   19,
    QMetaType::Void, 0x80000000 | 11,   21,

 // properties: name, type, flags
      22, 0x80000000 | 23, 0x00095009,
      24, 0x80000000 | 25, 0x00095009,
       9, 0x80000000 | 26, 0x0049510b,
      27, QMetaType::Double, 0x00095103,
      17, 0x80000000 | 4, 0x0049510b,
      28, QMetaType::Bool, 0x00095103,
      29, QMetaType::Bool, 0x00095103,
      30, QMetaType::Int, 0x00095103,
      31, QMetaType::Bool, 0x00095103,
      32, QMetaType::Bool, 0x00095103,
      33, QMetaType::Bool, 0x00095103,
      34, QMetaType::Bool, 0x00095103,
      35, QMetaType::Bool, 0x00095103,
      36, QMetaType::Int, 0x00095103,
      37, 0x80000000 | 38, 0x0009510b,
      39, QMetaType::QFont, 0x00095103,
      40, QMetaType::QColor, 0x00095103,
      41, QMetaType::Double, 0x00095103,
      42, QMetaType::QString, 0x00095103,
      43, 0x80000000 | 44, 0x0009510b,
      45, QMetaType::QString, 0x00095103,
      46, QMetaType::Int, 0x00095103,
      47, QMetaType::Double, 0x00095103,
      48, 0x80000000 | 49, 0x0009510b,
      50, 0x80000000 | 51, 0x0009510b,
      52, QMetaType::Int, 0x00095103,
      53, QMetaType::Int, 0x00095103,
      54, QMetaType::Int, 0x00095103,
      55, QMetaType::Int, 0x00095103,
      56, QMetaType::Int, 0x00095103,
      57, QMetaType::QPen, 0x00095103,
      58, QMetaType::QPen, 0x00095103,
      59, QMetaType::QPen, 0x00095103,
      60, QMetaType::QFont, 0x00095103,
      61, QMetaType::QColor, 0x00095103,
      62, QMetaType::QString, 0x00095103,
      63, QMetaType::Int, 0x00095103,
      64, QMetaType::Int, 0x00095103,
      65, QMetaType::Int, 0x00095103,
      21, 0x80000000 | 66, 0x0049510b,
      19, 0x80000000 | 66, 0x0049510b,
      67, QMetaType::QFont, 0x00095103,
      68, QMetaType::QFont, 0x00095103,
      69, QMetaType::QColor, 0x00095103,
      70, QMetaType::QColor, 0x00095103,
      71, QMetaType::QPen, 0x00095103,
      72, QMetaType::QPen, 0x00095103,
      73, QMetaType::QPen, 0x00095103,
      74, 0x80000000 | 75, 0x0009510b,
      76, 0x80000000 | 75, 0x0009510b,
      77, 0x80000000 | 78, 0x00095009,

 // properties: notify_signal_id
       0,
       0,
       3,
       0,
       1,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       4,
       5,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,

 // enums: name, flags, count, data
      23, 0x1,    4,  322,
      83, 0x1,    4,  330,
      38, 0x0,    2,  338,
      26, 0x0,    2,  342,
      88, 0x1,    4,  346,
      66, 0x1,    4,  354,

 // enum data: key, value
      79, uint(QCPAxis::atLeft),
      80, uint(QCPAxis::atRight),
      81, uint(QCPAxis::atTop),
      82, uint(QCPAxis::atBottom),
      79, uint(QCPAxis::atLeft),
      80, uint(QCPAxis::atRight),
      81, uint(QCPAxis::atTop),
      82, uint(QCPAxis::atBottom),
      84, uint(QCPAxis::ltNumber),
      85, uint(QCPAxis::ltDateTime),
      86, uint(QCPAxis::stLinear),
      87, uint(QCPAxis::stLogarithmic),
      89, uint(QCPAxis::spNone),
      90, uint(QCPAxis::spAxis),
      91, uint(QCPAxis::spTickLabels),
      92, uint(QCPAxis::spAxisLabel),
      89, uint(QCPAxis::spNone),
      90, uint(QCPAxis::spAxis),
      91, uint(QCPAxis::spTickLabels),
      92, uint(QCPAxis::spAxisLabel),

       0        // eod
};

void QCPAxis::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPAxis *_t = static_cast<QCPAxis *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->ticksRequest(); break;
        case 1: _t->rangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 2: _t->rangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1])),(*reinterpret_cast< const QCPRange(*)>(_a[2]))); break;
        case 3: _t->scaleTypeChanged((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 4: _t->selectionChanged((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 5: _t->selectableChanged((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 6: _t->setScaleType((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 7: _t->setRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 8: _t->setSelectableParts((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 9: _t->setSelectedParts((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPAxis::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::ticksRequest)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPAxis::*_t)(const QCPRange & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::rangeChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (QCPAxis::*_t)(const QCPRange & , const QCPRange & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::rangeChanged)) {
                *result = 2;
            }
        }
        {
            typedef void (QCPAxis::*_t)(QCPAxis::ScaleType );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::scaleTypeChanged)) {
                *result = 3;
            }
        }
        {
            typedef void (QCPAxis::*_t)(const QCPAxis::SelectableParts & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::selectionChanged)) {
                *result = 4;
            }
        }
        {
            typedef void (QCPAxis::*_t)(const QCPAxis::SelectableParts & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::selectableChanged)) {
                *result = 5;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxisRect* >(); break;
        case 50:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPGrid* >(); break;
        case 24:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QVector<QString> >(); break;
        case 23:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QVector<double> >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPAxis *_t = static_cast<QCPAxis *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast<int*>(_v) = QFlag(_t->axisType()); break;
        case 1: *reinterpret_cast< QCPAxisRect**>(_v) = _t->axisRect(); break;
        case 2: *reinterpret_cast< ScaleType*>(_v) = _t->scaleType(); break;
        case 3: *reinterpret_cast< double*>(_v) = _t->scaleLogBase(); break;
        case 4: *reinterpret_cast< QCPRange*>(_v) = _t->range(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->rangeReversed(); break;
        case 6: *reinterpret_cast< bool*>(_v) = _t->autoTicks(); break;
        case 7: *reinterpret_cast< int*>(_v) = _t->autoTickCount(); break;
        case 8: *reinterpret_cast< bool*>(_v) = _t->autoTickLabels(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->autoTickStep(); break;
        case 10: *reinterpret_cast< bool*>(_v) = _t->autoSubTicks(); break;
        case 11: *reinterpret_cast< bool*>(_v) = _t->ticks(); break;
        case 12: *reinterpret_cast< bool*>(_v) = _t->tickLabels(); break;
        case 13: *reinterpret_cast< int*>(_v) = _t->tickLabelPadding(); break;
        case 14: *reinterpret_cast< LabelType*>(_v) = _t->tickLabelType(); break;
        case 15: *reinterpret_cast< QFont*>(_v) = _t->tickLabelFont(); break;
        case 16: *reinterpret_cast< QColor*>(_v) = _t->tickLabelColor(); break;
        case 17: *reinterpret_cast< double*>(_v) = _t->tickLabelRotation(); break;
        case 18: *reinterpret_cast< QString*>(_v) = _t->dateTimeFormat(); break;
        case 19: *reinterpret_cast< Qt::TimeSpec*>(_v) = _t->dateTimeSpec(); break;
        case 20: *reinterpret_cast< QString*>(_v) = _t->numberFormat(); break;
        case 21: *reinterpret_cast< int*>(_v) = _t->numberPrecision(); break;
        case 22: *reinterpret_cast< double*>(_v) = _t->tickStep(); break;
        case 23: *reinterpret_cast< QVector<double>*>(_v) = _t->tickVector(); break;
        case 24: *reinterpret_cast< QVector<QString>*>(_v) = _t->tickVectorLabels(); break;
        case 25: *reinterpret_cast< int*>(_v) = _t->tickLengthIn(); break;
        case 26: *reinterpret_cast< int*>(_v) = _t->tickLengthOut(); break;
        case 27: *reinterpret_cast< int*>(_v) = _t->subTickCount(); break;
        case 28: *reinterpret_cast< int*>(_v) = _t->subTickLengthIn(); break;
        case 29: *reinterpret_cast< int*>(_v) = _t->subTickLengthOut(); break;
        case 30: *reinterpret_cast< QPen*>(_v) = _t->basePen(); break;
        case 31: *reinterpret_cast< QPen*>(_v) = _t->tickPen(); break;
        case 32: *reinterpret_cast< QPen*>(_v) = _t->subTickPen(); break;
        case 33: *reinterpret_cast< QFont*>(_v) = _t->labelFont(); break;
        case 34: *reinterpret_cast< QColor*>(_v) = _t->labelColor(); break;
        case 35: *reinterpret_cast< QString*>(_v) = _t->label(); break;
        case 36: *reinterpret_cast< int*>(_v) = _t->labelPadding(); break;
        case 37: *reinterpret_cast< int*>(_v) = _t->padding(); break;
        case 38: *reinterpret_cast< int*>(_v) = _t->offset(); break;
        case 39: *reinterpret_cast<int*>(_v) = QFlag(_t->selectedParts()); break;
        case 40: *reinterpret_cast<int*>(_v) = QFlag(_t->selectableParts()); break;
        case 41: *reinterpret_cast< QFont*>(_v) = _t->selectedTickLabelFont(); break;
        case 42: *reinterpret_cast< QFont*>(_v) = _t->selectedLabelFont(); break;
        case 43: *reinterpret_cast< QColor*>(_v) = _t->selectedTickLabelColor(); break;
        case 44: *reinterpret_cast< QColor*>(_v) = _t->selectedLabelColor(); break;
        case 45: *reinterpret_cast< QPen*>(_v) = _t->selectedBasePen(); break;
        case 46: *reinterpret_cast< QPen*>(_v) = _t->selectedTickPen(); break;
        case 47: *reinterpret_cast< QPen*>(_v) = _t->selectedSubTickPen(); break;
        case 48: *reinterpret_cast< QCPLineEnding*>(_v) = _t->lowerEnding(); break;
        case 49: *reinterpret_cast< QCPLineEnding*>(_v) = _t->upperEnding(); break;
        case 50: *reinterpret_cast< QCPGrid**>(_v) = _t->grid(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPAxis *_t = static_cast<QCPAxis *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 2: _t->setScaleType(*reinterpret_cast< ScaleType*>(_v)); break;
        case 3: _t->setScaleLogBase(*reinterpret_cast< double*>(_v)); break;
        case 4: _t->setRange(*reinterpret_cast< QCPRange*>(_v)); break;
        case 5: _t->setRangeReversed(*reinterpret_cast< bool*>(_v)); break;
        case 6: _t->setAutoTicks(*reinterpret_cast< bool*>(_v)); break;
        case 7: _t->setAutoTickCount(*reinterpret_cast< int*>(_v)); break;
        case 8: _t->setAutoTickLabels(*reinterpret_cast< bool*>(_v)); break;
        case 9: _t->setAutoTickStep(*reinterpret_cast< bool*>(_v)); break;
        case 10: _t->setAutoSubTicks(*reinterpret_cast< bool*>(_v)); break;
        case 11: _t->setTicks(*reinterpret_cast< bool*>(_v)); break;
        case 12: _t->setTickLabels(*reinterpret_cast< bool*>(_v)); break;
        case 13: _t->setTickLabelPadding(*reinterpret_cast< int*>(_v)); break;
        case 14: _t->setTickLabelType(*reinterpret_cast< LabelType*>(_v)); break;
        case 15: _t->setTickLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 16: _t->setTickLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 17: _t->setTickLabelRotation(*reinterpret_cast< double*>(_v)); break;
        case 18: _t->setDateTimeFormat(*reinterpret_cast< QString*>(_v)); break;
        case 19: _t->setDateTimeSpec(*reinterpret_cast< Qt::TimeSpec*>(_v)); break;
        case 20: _t->setNumberFormat(*reinterpret_cast< QString*>(_v)); break;
        case 21: _t->setNumberPrecision(*reinterpret_cast< int*>(_v)); break;
        case 22: _t->setTickStep(*reinterpret_cast< double*>(_v)); break;
        case 23: _t->setTickVector(*reinterpret_cast< QVector<double>*>(_v)); break;
        case 24: _t->setTickVectorLabels(*reinterpret_cast< QVector<QString>*>(_v)); break;
        case 25: _t->setTickLengthIn(*reinterpret_cast< int*>(_v)); break;
        case 26: _t->setTickLengthOut(*reinterpret_cast< int*>(_v)); break;
        case 27: _t->setSubTickCount(*reinterpret_cast< int*>(_v)); break;
        case 28: _t->setSubTickLengthIn(*reinterpret_cast< int*>(_v)); break;
        case 29: _t->setSubTickLengthOut(*reinterpret_cast< int*>(_v)); break;
        case 30: _t->setBasePen(*reinterpret_cast< QPen*>(_v)); break;
        case 31: _t->setTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 32: _t->setSubTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 33: _t->setLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 34: _t->setLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 35: _t->setLabel(*reinterpret_cast< QString*>(_v)); break;
        case 36: _t->setLabelPadding(*reinterpret_cast< int*>(_v)); break;
        case 37: _t->setPadding(*reinterpret_cast< int*>(_v)); break;
        case 38: _t->setOffset(*reinterpret_cast< int*>(_v)); break;
        case 39: _t->setSelectedParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 40: _t->setSelectableParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 41: _t->setSelectedTickLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 42: _t->setSelectedLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 43: _t->setSelectedTickLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 44: _t->setSelectedLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 45: _t->setSelectedBasePen(*reinterpret_cast< QPen*>(_v)); break;
        case 46: _t->setSelectedTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 47: _t->setSelectedSubTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 48: _t->setLowerEnding(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        case 49: _t->setUpperEnding(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QCPAxis::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPAxis.data,
      qt_meta_data_QCPAxis,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPAxis::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPAxis::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAxis.stringdata0))
        return static_cast<void*>(const_cast< QCPAxis*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPAxis::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 51;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 51;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 51;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 51;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 51;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 51;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAxis::ticksRequest()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void QCPAxis::rangeChanged(const QCPRange & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPAxis::rangeChanged(const QCPRange & _t1, const QCPRange & _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCPAxis::scaleTypeChanged(QCPAxis::ScaleType _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QCPAxis::selectionChanged(const QCPAxis::SelectableParts & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void QCPAxis::selectableChanged(const QCPAxis::SelectableParts & _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
struct qt_meta_stringdata_QCPAbstractPlottable_t {
    QByteArrayData data[19];
    char stringdata0[228];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAbstractPlottable_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAbstractPlottable_t qt_meta_stringdata_QCPAbstractPlottable = {
    {
QT_MOC_LITERAL(0, 0, 20), // "QCPAbstractPlottable"
QT_MOC_LITERAL(1, 21, 16), // "selectionChanged"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 8), // "selected"
QT_MOC_LITERAL(4, 48, 17), // "selectableChanged"
QT_MOC_LITERAL(5, 66, 10), // "selectable"
QT_MOC_LITERAL(6, 77, 13), // "setSelectable"
QT_MOC_LITERAL(7, 91, 11), // "setSelected"
QT_MOC_LITERAL(8, 103, 4), // "name"
QT_MOC_LITERAL(9, 108, 15), // "antialiasedFill"
QT_MOC_LITERAL(10, 124, 19), // "antialiasedScatters"
QT_MOC_LITERAL(11, 144, 20), // "antialiasedErrorBars"
QT_MOC_LITERAL(12, 165, 3), // "pen"
QT_MOC_LITERAL(13, 169, 11), // "selectedPen"
QT_MOC_LITERAL(14, 181, 5), // "brush"
QT_MOC_LITERAL(15, 187, 13), // "selectedBrush"
QT_MOC_LITERAL(16, 201, 7), // "keyAxis"
QT_MOC_LITERAL(17, 209, 8), // "QCPAxis*"
QT_MOC_LITERAL(18, 218, 9) // "valueAxis"

    },
    "QCPAbstractPlottable\0selectionChanged\0"
    "\0selected\0selectableChanged\0selectable\0"
    "setSelectable\0setSelected\0name\0"
    "antialiasedFill\0antialiasedScatters\0"
    "antialiasedErrorBars\0pen\0selectedPen\0"
    "brush\0selectedBrush\0keyAxis\0QCPAxis*\0"
    "valueAxis"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAbstractPlottable[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
      12,   46, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   34,    2, 0x06 /* Public */,
       4,    1,   37,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,   40,    2, 0x0a /* Public */,
       7,    1,   43,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    3,

 // properties: name, type, flags
       8, QMetaType::QString, 0x00095103,
       9, QMetaType::Bool, 0x00095103,
      10, QMetaType::Bool, 0x00095103,
      11, QMetaType::Bool, 0x00095103,
      12, QMetaType::QPen, 0x00095103,
      13, QMetaType::QPen, 0x00095103,
      14, QMetaType::QBrush, 0x00095103,
      15, QMetaType::QBrush, 0x00095103,
      16, 0x80000000 | 17, 0x0009510b,
      18, 0x80000000 | 17, 0x0009510b,
       5, QMetaType::Bool, 0x00495103,
       3, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       1,
       0,

       0        // eod
};

void QCPAbstractPlottable::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPAbstractPlottable *_t = static_cast<QCPAbstractPlottable *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->selectableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->setSelectable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->setSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPAbstractPlottable::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractPlottable::selectionChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPAbstractPlottable::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractPlottable::selectableChanged)) {
                *result = 1;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 9:
        case 8:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPAbstractPlottable *_t = static_cast<QCPAbstractPlottable *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->name(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->antialiasedFill(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->antialiasedScatters(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->antialiasedErrorBars(); break;
        case 4: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 5: *reinterpret_cast< QPen*>(_v) = _t->selectedPen(); break;
        case 6: *reinterpret_cast< QBrush*>(_v) = _t->brush(); break;
        case 7: *reinterpret_cast< QBrush*>(_v) = _t->selectedBrush(); break;
        case 8: *reinterpret_cast< QCPAxis**>(_v) = _t->keyAxis(); break;
        case 9: *reinterpret_cast< QCPAxis**>(_v) = _t->valueAxis(); break;
        case 10: *reinterpret_cast< bool*>(_v) = _t->selectable(); break;
        case 11: *reinterpret_cast< bool*>(_v) = _t->selected(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPAbstractPlottable *_t = static_cast<QCPAbstractPlottable *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setName(*reinterpret_cast< QString*>(_v)); break;
        case 1: _t->setAntialiasedFill(*reinterpret_cast< bool*>(_v)); break;
        case 2: _t->setAntialiasedScatters(*reinterpret_cast< bool*>(_v)); break;
        case 3: _t->setAntialiasedErrorBars(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 5: _t->setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 6: _t->setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 7: _t->setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 8: _t->setKeyAxis(*reinterpret_cast< QCPAxis**>(_v)); break;
        case 9: _t->setValueAxis(*reinterpret_cast< QCPAxis**>(_v)); break;
        case 10: _t->setSelectable(*reinterpret_cast< bool*>(_v)); break;
        case 11: _t->setSelected(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QCPAbstractPlottable::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPAbstractPlottable.data,
      qt_meta_data_QCPAbstractPlottable,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPAbstractPlottable::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPAbstractPlottable::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAbstractPlottable.stringdata0))
        return static_cast<void*>(const_cast< QCPAbstractPlottable*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPAbstractPlottable::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 12;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAbstractPlottable::selectionChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAbstractPlottable::selectableChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_QCPAbstractItem_t {
    QByteArrayData data[11];
    char stringdata0[139];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAbstractItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAbstractItem_t qt_meta_stringdata_QCPAbstractItem = {
    {
QT_MOC_LITERAL(0, 0, 15), // "QCPAbstractItem"
QT_MOC_LITERAL(1, 16, 16), // "selectionChanged"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 8), // "selected"
QT_MOC_LITERAL(4, 43, 17), // "selectableChanged"
QT_MOC_LITERAL(5, 61, 10), // "selectable"
QT_MOC_LITERAL(6, 72, 13), // "setSelectable"
QT_MOC_LITERAL(7, 86, 11), // "setSelected"
QT_MOC_LITERAL(8, 98, 14), // "clipToAxisRect"
QT_MOC_LITERAL(9, 113, 12), // "clipAxisRect"
QT_MOC_LITERAL(10, 126, 12) // "QCPAxisRect*"

    },
    "QCPAbstractItem\0selectionChanged\0\0"
    "selected\0selectableChanged\0selectable\0"
    "setSelectable\0setSelected\0clipToAxisRect\0"
    "clipAxisRect\0QCPAxisRect*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAbstractItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       4,   46, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   34,    2, 0x06 /* Public */,
       4,    1,   37,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,   40,    2, 0x0a /* Public */,
       7,    1,   43,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    3,

 // properties: name, type, flags
       8, QMetaType::Bool, 0x00095103,
       9, 0x80000000 | 10, 0x0009510b,
       5, QMetaType::Bool, 0x00495103,
       3, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       0,
       0,
       1,
       0,

       0        // eod
};

void QCPAbstractItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPAbstractItem *_t = static_cast<QCPAbstractItem *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->selectableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->setSelectable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->setSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPAbstractItem::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractItem::selectionChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPAbstractItem::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractItem::selectableChanged)) {
                *result = 1;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxisRect* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPAbstractItem *_t = static_cast<QCPAbstractItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->clipToAxisRect(); break;
        case 1: *reinterpret_cast< QCPAxisRect**>(_v) = _t->clipAxisRect(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->selectable(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->selected(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPAbstractItem *_t = static_cast<QCPAbstractItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setClipToAxisRect(*reinterpret_cast< bool*>(_v)); break;
        case 1: _t->setClipAxisRect(*reinterpret_cast< QCPAxisRect**>(_v)); break;
        case 2: _t->setSelectable(*reinterpret_cast< bool*>(_v)); break;
        case 3: _t->setSelected(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QCPAbstractItem::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPAbstractItem.data,
      qt_meta_data_QCPAbstractItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPAbstractItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPAbstractItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAbstractItem.stringdata0))
        return static_cast<void*>(const_cast< QCPAbstractItem*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPAbstractItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAbstractItem::selectionChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAbstractItem::selectableChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_QCustomPlot_t {
    QByteArrayData data[57];
    char stringdata0[801];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCustomPlot_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCustomPlot_t qt_meta_stringdata_QCustomPlot = {
    {
QT_MOC_LITERAL(0, 0, 11), // "QCustomPlot"
QT_MOC_LITERAL(1, 12, 16), // "mouseDoubleClick"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 12), // "QMouseEvent*"
QT_MOC_LITERAL(4, 43, 5), // "event"
QT_MOC_LITERAL(5, 49, 10), // "mousePress"
QT_MOC_LITERAL(6, 60, 9), // "mouseMove"
QT_MOC_LITERAL(7, 70, 12), // "mouseRelease"
QT_MOC_LITERAL(8, 83, 10), // "mouseWheel"
QT_MOC_LITERAL(9, 94, 12), // "QWheelEvent*"
QT_MOC_LITERAL(10, 107, 14), // "plottableClick"
QT_MOC_LITERAL(11, 122, 21), // "QCPAbstractPlottable*"
QT_MOC_LITERAL(12, 144, 9), // "plottable"
QT_MOC_LITERAL(13, 154, 20), // "plottableDoubleClick"
QT_MOC_LITERAL(14, 175, 9), // "itemClick"
QT_MOC_LITERAL(15, 185, 16), // "QCPAbstractItem*"
QT_MOC_LITERAL(16, 202, 4), // "item"
QT_MOC_LITERAL(17, 207, 15), // "itemDoubleClick"
QT_MOC_LITERAL(18, 223, 9), // "axisClick"
QT_MOC_LITERAL(19, 233, 8), // "QCPAxis*"
QT_MOC_LITERAL(20, 242, 4), // "axis"
QT_MOC_LITERAL(21, 247, 23), // "QCPAxis::SelectablePart"
QT_MOC_LITERAL(22, 271, 4), // "part"
QT_MOC_LITERAL(23, 276, 15), // "axisDoubleClick"
QT_MOC_LITERAL(24, 292, 11), // "legendClick"
QT_MOC_LITERAL(25, 304, 10), // "QCPLegend*"
QT_MOC_LITERAL(26, 315, 6), // "legend"
QT_MOC_LITERAL(27, 322, 22), // "QCPAbstractLegendItem*"
QT_MOC_LITERAL(28, 345, 17), // "legendDoubleClick"
QT_MOC_LITERAL(29, 363, 10), // "titleClick"
QT_MOC_LITERAL(30, 374, 13), // "QCPPlotTitle*"
QT_MOC_LITERAL(31, 388, 5), // "title"
QT_MOC_LITERAL(32, 394, 16), // "titleDoubleClick"
QT_MOC_LITERAL(33, 411, 22), // "selectionChangedByUser"
QT_MOC_LITERAL(34, 434, 12), // "beforeReplot"
QT_MOC_LITERAL(35, 447, 11), // "afterReplot"
QT_MOC_LITERAL(36, 459, 11), // "rescaleAxes"
QT_MOC_LITERAL(37, 471, 21), // "onlyVisiblePlottables"
QT_MOC_LITERAL(38, 493, 11), // "deselectAll"
QT_MOC_LITERAL(39, 505, 6), // "replot"
QT_MOC_LITERAL(40, 512, 28), // "QCustomPlot::RefreshPriority"
QT_MOC_LITERAL(41, 541, 15), // "refreshPriority"
QT_MOC_LITERAL(42, 557, 8), // "viewport"
QT_MOC_LITERAL(43, 566, 10), // "background"
QT_MOC_LITERAL(44, 577, 16), // "backgroundScaled"
QT_MOC_LITERAL(45, 594, 20), // "backgroundScaledMode"
QT_MOC_LITERAL(46, 615, 19), // "Qt::AspectRatioMode"
QT_MOC_LITERAL(47, 635, 10), // "plotLayout"
QT_MOC_LITERAL(48, 646, 14), // "QCPLayoutGrid*"
QT_MOC_LITERAL(49, 661, 24), // "autoAddPlottableToLegend"
QT_MOC_LITERAL(50, 686, 18), // "selectionTolerance"
QT_MOC_LITERAL(51, 705, 20), // "noAntialiasingOnDrag"
QT_MOC_LITERAL(52, 726, 19), // "multiSelectModifier"
QT_MOC_LITERAL(53, 746, 20), // "Qt::KeyboardModifier"
QT_MOC_LITERAL(54, 767, 15), // "LayerInsertMode"
QT_MOC_LITERAL(55, 783, 8), // "limBelow"
QT_MOC_LITERAL(56, 792, 8) // "limAbove"

    },
    "QCustomPlot\0mouseDoubleClick\0\0"
    "QMouseEvent*\0event\0mousePress\0mouseMove\0"
    "mouseRelease\0mouseWheel\0QWheelEvent*\0"
    "plottableClick\0QCPAbstractPlottable*\0"
    "plottable\0plottableDoubleClick\0itemClick\0"
    "QCPAbstractItem*\0item\0itemDoubleClick\0"
    "axisClick\0QCPAxis*\0axis\0QCPAxis::SelectablePart\0"
    "part\0axisDoubleClick\0legendClick\0"
    "QCPLegend*\0legend\0QCPAbstractLegendItem*\0"
    "legendDoubleClick\0titleClick\0QCPPlotTitle*\0"
    "title\0titleDoubleClick\0selectionChangedByUser\0"
    "beforeReplot\0afterReplot\0rescaleAxes\0"
    "onlyVisiblePlottables\0deselectAll\0"
    "replot\0QCustomPlot::RefreshPriority\0"
    "refreshPriority\0viewport\0background\0"
    "backgroundScaled\0backgroundScaledMode\0"
    "Qt::AspectRatioMode\0plotLayout\0"
    "QCPLayoutGrid*\0autoAddPlottableToLegend\0"
    "selectionTolerance\0noAntialiasingOnDrag\0"
    "multiSelectModifier\0Qt::KeyboardModifier\0"
    "LayerInsertMode\0limBelow\0limAbove"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCustomPlot[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       9,  214, // properties
       1,  241, // enums/sets
       0,    0, // constructors
       0,       // flags
      18,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  129,    2, 0x06 /* Public */,
       5,    1,  132,    2, 0x06 /* Public */,
       6,    1,  135,    2, 0x06 /* Public */,
       7,    1,  138,    2, 0x06 /* Public */,
       8,    1,  141,    2, 0x06 /* Public */,
      10,    2,  144,    2, 0x06 /* Public */,
      13,    2,  149,    2, 0x06 /* Public */,
      14,    2,  154,    2, 0x06 /* Public */,
      17,    2,  159,    2, 0x06 /* Public */,
      18,    3,  164,    2, 0x06 /* Public */,
      23,    3,  171,    2, 0x06 /* Public */,
      24,    3,  178,    2, 0x06 /* Public */,
      28,    3,  185,    2, 0x06 /* Public */,
      29,    2,  192,    2, 0x06 /* Public */,
      32,    2,  197,    2, 0x06 /* Public */,
      33,    0,  202,    2, 0x06 /* Public */,
      34,    0,  203,    2, 0x06 /* Public */,
      35,    0,  204,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      36,    1,  205,    2, 0x0a /* Public */,
      36,    0,  208,    2, 0x2a /* Public | MethodCloned */,
      38,    0,  209,    2, 0x0a /* Public */,
      39,    1,  210,    2, 0x0a /* Public */,
      39,    0,  213,    2, 0x2a /* Public | MethodCloned */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 9,    4,
    QMetaType::Void, 0x80000000 | 11, 0x80000000 | 3,   12,    4,
    QMetaType::Void, 0x80000000 | 11, 0x80000000 | 3,   12,    4,
    QMetaType::Void, 0x80000000 | 15, 0x80000000 | 3,   16,    4,
    QMetaType::Void, 0x80000000 | 15, 0x80000000 | 3,   16,    4,
    QMetaType::Void, 0x80000000 | 19, 0x80000000 | 21, 0x80000000 | 3,   20,   22,    4,
    QMetaType::Void, 0x80000000 | 19, 0x80000000 | 21, 0x80000000 | 3,   20,   22,    4,
    QMetaType::Void, 0x80000000 | 25, 0x80000000 | 27, 0x80000000 | 3,   26,   16,    4,
    QMetaType::Void, 0x80000000 | 25, 0x80000000 | 27, 0x80000000 | 3,   26,   16,    4,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 30,    4,   31,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 30,    4,   31,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,   37,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 40,   41,
    QMetaType::Void,

 // properties: name, type, flags
      42, QMetaType::QRect, 0x00095103,
      43, QMetaType::QPixmap, 0x00095103,
      44, QMetaType::Bool, 0x00095103,
      45, 0x80000000 | 46, 0x0009510b,
      47, 0x80000000 | 48, 0x00095009,
      49, QMetaType::Bool, 0x00095103,
      50, QMetaType::Int, 0x00095103,
      51, QMetaType::Bool, 0x00095103,
      52, 0x80000000 | 53, 0x0009510b,

 // enums: name, flags, count, data
      54, 0x0,    2,  245,

 // enum data: key, value
      55, uint(QCustomPlot::limBelow),
      56, uint(QCustomPlot::limAbove),

       0        // eod
};

void QCustomPlot::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCustomPlot *_t = static_cast<QCustomPlot *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->mouseDoubleClick((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 1: _t->mousePress((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 2: _t->mouseMove((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 3: _t->mouseRelease((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 4: _t->mouseWheel((*reinterpret_cast< QWheelEvent*(*)>(_a[1]))); break;
        case 5: _t->plottableClick((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 6: _t->plottableDoubleClick((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 7: _t->itemClick((*reinterpret_cast< QCPAbstractItem*(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 8: _t->itemDoubleClick((*reinterpret_cast< QCPAbstractItem*(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 9: _t->axisClick((*reinterpret_cast< QCPAxis*(*)>(_a[1])),(*reinterpret_cast< QCPAxis::SelectablePart(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 10: _t->axisDoubleClick((*reinterpret_cast< QCPAxis*(*)>(_a[1])),(*reinterpret_cast< QCPAxis::SelectablePart(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 11: _t->legendClick((*reinterpret_cast< QCPLegend*(*)>(_a[1])),(*reinterpret_cast< QCPAbstractLegendItem*(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 12: _t->legendDoubleClick((*reinterpret_cast< QCPLegend*(*)>(_a[1])),(*reinterpret_cast< QCPAbstractLegendItem*(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 13: _t->titleClick((*reinterpret_cast< QMouseEvent*(*)>(_a[1])),(*reinterpret_cast< QCPPlotTitle*(*)>(_a[2]))); break;
        case 14: _t->titleDoubleClick((*reinterpret_cast< QMouseEvent*(*)>(_a[1])),(*reinterpret_cast< QCPPlotTitle*(*)>(_a[2]))); break;
        case 15: _t->selectionChangedByUser(); break;
        case 16: _t->beforeReplot(); break;
        case 17: _t->afterReplot(); break;
        case 18: _t->rescaleAxes((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: _t->rescaleAxes(); break;
        case 20: _t->deselectAll(); break;
        case 21: _t->replot((*reinterpret_cast< QCustomPlot::RefreshPriority(*)>(_a[1]))); break;
        case 22: _t->replot(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
            }
            break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractItem* >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractItem* >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis* >(); break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::SelectablePart >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis* >(); break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::SelectablePart >(); break;
            }
            break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractLegendItem* >(); break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLegend* >(); break;
            }
            break;
        case 12:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractLegendItem* >(); break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLegend* >(); break;
            }
            break;
        case 13:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPPlotTitle* >(); break;
            }
            break;
        case 14:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPPlotTitle* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCustomPlot::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::mouseDoubleClick)) {
                *result = 0;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::mousePress)) {
                *result = 1;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::mouseMove)) {
                *result = 2;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::mouseRelease)) {
                *result = 3;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QWheelEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::mouseWheel)) {
                *result = 4;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAbstractPlottable * , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::plottableClick)) {
                *result = 5;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAbstractPlottable * , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::plottableDoubleClick)) {
                *result = 6;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAbstractItem * , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::itemClick)) {
                *result = 7;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAbstractItem * , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::itemDoubleClick)) {
                *result = 8;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAxis * , QCPAxis::SelectablePart , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::axisClick)) {
                *result = 9;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAxis * , QCPAxis::SelectablePart , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::axisDoubleClick)) {
                *result = 10;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPLegend * , QCPAbstractLegendItem * , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::legendClick)) {
                *result = 11;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPLegend * , QCPAbstractLegendItem * , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::legendDoubleClick)) {
                *result = 12;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QMouseEvent * , QCPPlotTitle * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::titleClick)) {
                *result = 13;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QMouseEvent * , QCPPlotTitle * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::titleDoubleClick)) {
                *result = 14;
            }
        }
        {
            typedef void (QCustomPlot::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::selectionChangedByUser)) {
                *result = 15;
            }
        }
        {
            typedef void (QCustomPlot::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::beforeReplot)) {
                *result = 16;
            }
        }
        {
            typedef void (QCustomPlot::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::afterReplot)) {
                *result = 17;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 4:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayoutGrid* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCustomPlot *_t = static_cast<QCustomPlot *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QRect*>(_v) = _t->viewport(); break;
        case 1: *reinterpret_cast< QPixmap*>(_v) = _t->background(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->backgroundScaled(); break;
        case 3: *reinterpret_cast< Qt::AspectRatioMode*>(_v) = _t->backgroundScaledMode(); break;
        case 4: *reinterpret_cast< QCPLayoutGrid**>(_v) = _t->plotLayout(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->autoAddPlottableToLegend(); break;
        case 6: *reinterpret_cast< int*>(_v) = _t->selectionTolerance(); break;
        case 7: *reinterpret_cast< bool*>(_v) = _t->noAntialiasingOnDrag(); break;
        case 8: *reinterpret_cast< Qt::KeyboardModifier*>(_v) = _t->multiSelectModifier(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCustomPlot *_t = static_cast<QCustomPlot *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setViewport(*reinterpret_cast< QRect*>(_v)); break;
        case 1: _t->setBackground(*reinterpret_cast< QPixmap*>(_v)); break;
        case 2: _t->setBackgroundScaled(*reinterpret_cast< bool*>(_v)); break;
        case 3: _t->setBackgroundScaledMode(*reinterpret_cast< Qt::AspectRatioMode*>(_v)); break;
        case 5: _t->setAutoAddPlottableToLegend(*reinterpret_cast< bool*>(_v)); break;
        case 6: _t->setSelectionTolerance(*reinterpret_cast< int*>(_v)); break;
        case 7: _t->setNoAntialiasingOnDrag(*reinterpret_cast< bool*>(_v)); break;
        case 8: _t->setMultiSelectModifier(*reinterpret_cast< Qt::KeyboardModifier*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QCustomPlot::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_QCustomPlot.data,
      qt_meta_data_QCustomPlot,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCustomPlot::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCustomPlot::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCustomPlot.stringdata0))
        return static_cast<void*>(const_cast< QCustomPlot*>(this));
    return QWidget::qt_metacast(_clname);
}

int QCustomPlot::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 9;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCustomPlot::mouseDoubleClick(QMouseEvent * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCustomPlot::mousePress(QMouseEvent * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCustomPlot::mouseMove(QMouseEvent * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCustomPlot::mouseRelease(QMouseEvent * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QCustomPlot::mouseWheel(QWheelEvent * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void QCustomPlot::plottableClick(QCPAbstractPlottable * _t1, QMouseEvent * _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void QCustomPlot::plottableDoubleClick(QCPAbstractPlottable * _t1, QMouseEvent * _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void QCustomPlot::itemClick(QCPAbstractItem * _t1, QMouseEvent * _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void QCustomPlot::itemDoubleClick(QCPAbstractItem * _t1, QMouseEvent * _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void QCustomPlot::axisClick(QCPAxis * _t1, QCPAxis::SelectablePart _t2, QMouseEvent * _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void QCustomPlot::axisDoubleClick(QCPAxis * _t1, QCPAxis::SelectablePart _t2, QMouseEvent * _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void QCustomPlot::legendClick(QCPLegend * _t1, QCPAbstractLegendItem * _t2, QMouseEvent * _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void QCustomPlot::legendDoubleClick(QCPLegend * _t1, QCPAbstractLegendItem * _t2, QMouseEvent * _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void QCustomPlot::titleClick(QMouseEvent * _t1, QCPPlotTitle * _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void QCustomPlot::titleDoubleClick(QMouseEvent * _t1, QCPPlotTitle * _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void QCustomPlot::selectionChangedByUser()
{
    QMetaObject::activate(this, &staticMetaObject, 15, Q_NULLPTR);
}

// SIGNAL 16
void QCustomPlot::beforeReplot()
{
    QMetaObject::activate(this, &staticMetaObject, 16, Q_NULLPTR);
}

// SIGNAL 17
void QCustomPlot::afterReplot()
{
    QMetaObject::activate(this, &staticMetaObject, 17, Q_NULLPTR);
}
struct qt_meta_stringdata_QCPColorGradient_t {
    QByteArrayData data[17];
    char stringdata0[164];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPColorGradient_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPColorGradient_t qt_meta_stringdata_QCPColorGradient = {
    {
QT_MOC_LITERAL(0, 0, 16), // "QCPColorGradient"
QT_MOC_LITERAL(1, 17, 18), // "ColorInterpolation"
QT_MOC_LITERAL(2, 36, 5), // "ciRGB"
QT_MOC_LITERAL(3, 42, 5), // "ciHSV"
QT_MOC_LITERAL(4, 48, 14), // "GradientPreset"
QT_MOC_LITERAL(5, 63, 11), // "gpGrayscale"
QT_MOC_LITERAL(6, 75, 5), // "gpHot"
QT_MOC_LITERAL(7, 81, 6), // "gpCold"
QT_MOC_LITERAL(8, 88, 7), // "gpNight"
QT_MOC_LITERAL(9, 96, 7), // "gpCandy"
QT_MOC_LITERAL(10, 104, 11), // "gpGeography"
QT_MOC_LITERAL(11, 116, 5), // "gpIon"
QT_MOC_LITERAL(12, 122, 9), // "gpThermal"
QT_MOC_LITERAL(13, 132, 7), // "gpPolar"
QT_MOC_LITERAL(14, 140, 10), // "gpSpectrum"
QT_MOC_LITERAL(15, 151, 5), // "gpJet"
QT_MOC_LITERAL(16, 157, 6) // "gpHues"

    },
    "QCPColorGradient\0ColorInterpolation\0"
    "ciRGB\0ciHSV\0GradientPreset\0gpGrayscale\0"
    "gpHot\0gpCold\0gpNight\0gpCandy\0gpGeography\0"
    "gpIon\0gpThermal\0gpPolar\0gpSpectrum\0"
    "gpJet\0gpHues"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPColorGradient[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       2,   14, // enums/sets
       0,    0, // constructors
       4,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    2,   22,
       4, 0x0,   12,   26,

 // enum data: key, value
       2, uint(QCPColorGradient::ciRGB),
       3, uint(QCPColorGradient::ciHSV),
       5, uint(QCPColorGradient::gpGrayscale),
       6, uint(QCPColorGradient::gpHot),
       7, uint(QCPColorGradient::gpCold),
       8, uint(QCPColorGradient::gpNight),
       9, uint(QCPColorGradient::gpCandy),
      10, uint(QCPColorGradient::gpGeography),
      11, uint(QCPColorGradient::gpIon),
      12, uint(QCPColorGradient::gpThermal),
      13, uint(QCPColorGradient::gpPolar),
      14, uint(QCPColorGradient::gpSpectrum),
      15, uint(QCPColorGradient::gpJet),
      16, uint(QCPColorGradient::gpHues),

       0        // eod
};

const QMetaObject QCPColorGradient::staticMetaObject = {
    { Q_NULLPTR, qt_meta_stringdata_QCPColorGradient.data,
      qt_meta_data_QCPColorGradient,  Q_NULLPTR, Q_NULLPTR, Q_NULLPTR}
};

struct qt_meta_stringdata_QCPAxisRect_t {
    QByteArrayData data[8];
    char stringdata0[118];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAxisRect_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAxisRect_t qt_meta_stringdata_QCPAxisRect = {
    {
QT_MOC_LITERAL(0, 0, 11), // "QCPAxisRect"
QT_MOC_LITERAL(1, 12, 10), // "background"
QT_MOC_LITERAL(2, 23, 16), // "backgroundScaled"
QT_MOC_LITERAL(3, 40, 20), // "backgroundScaledMode"
QT_MOC_LITERAL(4, 61, 19), // "Qt::AspectRatioMode"
QT_MOC_LITERAL(5, 81, 9), // "rangeDrag"
QT_MOC_LITERAL(6, 91, 16), // "Qt::Orientations"
QT_MOC_LITERAL(7, 108, 9) // "rangeZoom"

    },
    "QCPAxisRect\0background\0backgroundScaled\0"
    "backgroundScaledMode\0Qt::AspectRatioMode\0"
    "rangeDrag\0Qt::Orientations\0rangeZoom"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAxisRect[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       5,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPixmap, 0x00095103,
       2, QMetaType::Bool, 0x00095103,
       3, 0x80000000 | 4, 0x0009510b,
       5, 0x80000000 | 6, 0x0009510b,
       7, 0x80000000 | 6, 0x0009510b,

       0        // eod
};

void QCPAxisRect::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPAxisRect *_t = static_cast<QCPAxisRect *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPixmap*>(_v) = _t->background(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->backgroundScaled(); break;
        case 2: *reinterpret_cast< Qt::AspectRatioMode*>(_v) = _t->backgroundScaledMode(); break;
        case 3: *reinterpret_cast< Qt::Orientations*>(_v) = _t->rangeDrag(); break;
        case 4: *reinterpret_cast< Qt::Orientations*>(_v) = _t->rangeZoom(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPAxisRect *_t = static_cast<QCPAxisRect *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setBackground(*reinterpret_cast< QPixmap*>(_v)); break;
        case 1: _t->setBackgroundScaled(*reinterpret_cast< bool*>(_v)); break;
        case 2: _t->setBackgroundScaledMode(*reinterpret_cast< Qt::AspectRatioMode*>(_v)); break;
        case 3: _t->setRangeDrag(*reinterpret_cast< Qt::Orientations*>(_v)); break;
        case 4: _t->setRangeZoom(*reinterpret_cast< Qt::Orientations*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPAxisRect::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPAxisRect.data,
      qt_meta_data_QCPAxisRect,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPAxisRect::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPAxisRect::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAxisRect.stringdata0))
        return static_cast<void*>(const_cast< QCPAxisRect*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPAxisRect::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPAbstractLegendItem_t {
    QByteArrayData data[14];
    char stringdata0[174];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAbstractLegendItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAbstractLegendItem_t qt_meta_stringdata_QCPAbstractLegendItem = {
    {
QT_MOC_LITERAL(0, 0, 21), // "QCPAbstractLegendItem"
QT_MOC_LITERAL(1, 22, 16), // "selectionChanged"
QT_MOC_LITERAL(2, 39, 0), // ""
QT_MOC_LITERAL(3, 40, 8), // "selected"
QT_MOC_LITERAL(4, 49, 17), // "selectableChanged"
QT_MOC_LITERAL(5, 67, 10), // "selectable"
QT_MOC_LITERAL(6, 78, 13), // "setSelectable"
QT_MOC_LITERAL(7, 92, 11), // "setSelected"
QT_MOC_LITERAL(8, 104, 12), // "parentLegend"
QT_MOC_LITERAL(9, 117, 10), // "QCPLegend*"
QT_MOC_LITERAL(10, 128, 4), // "font"
QT_MOC_LITERAL(11, 133, 9), // "textColor"
QT_MOC_LITERAL(12, 143, 12), // "selectedFont"
QT_MOC_LITERAL(13, 156, 17) // "selectedTextColor"

    },
    "QCPAbstractLegendItem\0selectionChanged\0"
    "\0selected\0selectableChanged\0selectable\0"
    "setSelectable\0setSelected\0parentLegend\0"
    "QCPLegend*\0font\0textColor\0selectedFont\0"
    "selectedTextColor"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAbstractLegendItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       7,   46, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   34,    2, 0x06 /* Public */,
       4,    1,   37,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,   40,    2, 0x0a /* Public */,
       7,    1,   43,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    3,

 // properties: name, type, flags
       8, 0x80000000 | 9, 0x00095009,
      10, QMetaType::QFont, 0x00095103,
      11, QMetaType::QColor, 0x00095103,
      12, QMetaType::QFont, 0x00095103,
      13, QMetaType::QColor, 0x00095103,
       5, QMetaType::Bool, 0x00495103,
       3, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       1,

       0        // eod
};

void QCPAbstractLegendItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPAbstractLegendItem *_t = static_cast<QCPAbstractLegendItem *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->selectableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->setSelectable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->setSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPAbstractLegendItem::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractLegendItem::selectionChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPAbstractLegendItem::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractLegendItem::selectableChanged)) {
                *result = 1;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLegend* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPAbstractLegendItem *_t = static_cast<QCPAbstractLegendItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPLegend**>(_v) = _t->parentLegend(); break;
        case 1: *reinterpret_cast< QFont*>(_v) = _t->font(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->textColor(); break;
        case 3: *reinterpret_cast< QFont*>(_v) = _t->selectedFont(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->selectedTextColor(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->selectable(); break;
        case 6: *reinterpret_cast< bool*>(_v) = _t->selected(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPAbstractLegendItem *_t = static_cast<QCPAbstractLegendItem *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 1: _t->setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 2: _t->setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: _t->setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 4: _t->setSelectedTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setSelectable(*reinterpret_cast< bool*>(_v)); break;
        case 6: _t->setSelected(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QCPAbstractLegendItem::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPAbstractLegendItem.data,
      qt_meta_data_QCPAbstractLegendItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPAbstractLegendItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPAbstractLegendItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAbstractLegendItem.stringdata0))
        return static_cast<void*>(const_cast< QCPAbstractLegendItem*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPAbstractLegendItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAbstractLegendItem::selectionChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAbstractLegendItem::selectableChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_QCPPlottableLegendItem_t {
    QByteArrayData data[1];
    char stringdata0[23];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPPlottableLegendItem_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPPlottableLegendItem_t qt_meta_stringdata_QCPPlottableLegendItem = {
    {
QT_MOC_LITERAL(0, 0, 22) // "QCPPlottableLegendItem"

    },
    "QCPPlottableLegendItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPPlottableLegendItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QCPPlottableLegendItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPPlottableLegendItem::staticMetaObject = {
    { &QCPAbstractLegendItem::staticMetaObject, qt_meta_stringdata_QCPPlottableLegendItem.data,
      qt_meta_data_QCPPlottableLegendItem,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPPlottableLegendItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPPlottableLegendItem::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPPlottableLegendItem.stringdata0))
        return static_cast<void*>(const_cast< QCPPlottableLegendItem*>(this));
    return QCPAbstractLegendItem::qt_metacast(_clname);
}

int QCPPlottableLegendItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractLegendItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QCPLegend_t {
    QByteArrayData data[27];
    char stringdata0[358];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLegend_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLegend_t qt_meta_stringdata_QCPLegend = {
    {
QT_MOC_LITERAL(0, 0, 9), // "QCPLegend"
QT_MOC_LITERAL(1, 10, 16), // "selectionChanged"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 26), // "QCPLegend::SelectableParts"
QT_MOC_LITERAL(4, 55, 5), // "parts"
QT_MOC_LITERAL(5, 61, 17), // "selectableChanged"
QT_MOC_LITERAL(6, 79, 18), // "setSelectableParts"
QT_MOC_LITERAL(7, 98, 15), // "SelectableParts"
QT_MOC_LITERAL(8, 114, 15), // "selectableParts"
QT_MOC_LITERAL(9, 130, 16), // "setSelectedParts"
QT_MOC_LITERAL(10, 147, 13), // "selectedParts"
QT_MOC_LITERAL(11, 161, 9), // "borderPen"
QT_MOC_LITERAL(12, 171, 5), // "brush"
QT_MOC_LITERAL(13, 177, 4), // "font"
QT_MOC_LITERAL(14, 182, 9), // "textColor"
QT_MOC_LITERAL(15, 192, 8), // "iconSize"
QT_MOC_LITERAL(16, 201, 15), // "iconTextPadding"
QT_MOC_LITERAL(17, 217, 13), // "iconBorderPen"
QT_MOC_LITERAL(18, 231, 17), // "selectedBorderPen"
QT_MOC_LITERAL(19, 249, 21), // "selectedIconBorderPen"
QT_MOC_LITERAL(20, 271, 13), // "selectedBrush"
QT_MOC_LITERAL(21, 285, 12), // "selectedFont"
QT_MOC_LITERAL(22, 298, 17), // "selectedTextColor"
QT_MOC_LITERAL(23, 316, 14), // "SelectablePart"
QT_MOC_LITERAL(24, 331, 6), // "spNone"
QT_MOC_LITERAL(25, 338, 11), // "spLegendBox"
QT_MOC_LITERAL(26, 350, 7) // "spItems"

    },
    "QCPLegend\0selectionChanged\0\0"
    "QCPLegend::SelectableParts\0parts\0"
    "selectableChanged\0setSelectableParts\0"
    "SelectableParts\0selectableParts\0"
    "setSelectedParts\0selectedParts\0borderPen\0"
    "brush\0font\0textColor\0iconSize\0"
    "iconTextPadding\0iconBorderPen\0"
    "selectedBorderPen\0selectedIconBorderPen\0"
    "selectedBrush\0selectedFont\0selectedTextColor\0"
    "SelectablePart\0spNone\0spLegendBox\0"
    "spItems"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLegend[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
      14,   46, // properties
       2,  102, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   34,    2, 0x06 /* Public */,
       5,    1,   37,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,   40,    2, 0x0a /* Public */,
       9,    1,   43,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, 0x80000000 | 7,   10,

 // properties: name, type, flags
      11, QMetaType::QPen, 0x00095103,
      12, QMetaType::QBrush, 0x00095103,
      13, QMetaType::QFont, 0x00095103,
      14, QMetaType::QColor, 0x00095103,
      15, QMetaType::QSize, 0x00095103,
      16, QMetaType::Int, 0x00095103,
      17, QMetaType::QPen, 0x00095103,
       8, 0x80000000 | 7, 0x0049510b,
      10, 0x80000000 | 7, 0x0049510b,
      18, QMetaType::QPen, 0x00095103,
      19, QMetaType::QPen, 0x00095103,
      20, QMetaType::QBrush, 0x00095103,
      21, QMetaType::QFont, 0x00095103,
      22, QMetaType::QColor, 0x00095103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       1,
       0,
       0,
       0,
       0,
       0,

 // enums: name, flags, count, data
      23, 0x1,    3,  110,
       7, 0x1,    3,  116,

 // enum data: key, value
      24, uint(QCPLegend::spNone),
      25, uint(QCPLegend::spLegendBox),
      26, uint(QCPLegend::spItems),
      24, uint(QCPLegend::spNone),
      25, uint(QCPLegend::spLegendBox),
      26, uint(QCPLegend::spItems),

       0        // eod
};

void QCPLegend::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPLegend *_t = static_cast<QCPLegend *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< QCPLegend::SelectableParts(*)>(_a[1]))); break;
        case 1: _t->selectableChanged((*reinterpret_cast< QCPLegend::SelectableParts(*)>(_a[1]))); break;
        case 2: _t->setSelectableParts((*reinterpret_cast< const SelectableParts(*)>(_a[1]))); break;
        case 3: _t->setSelectedParts((*reinterpret_cast< const SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPLegend::*_t)(QCPLegend::SelectableParts );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPLegend::selectionChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPLegend::*_t)(QCPLegend::SelectableParts );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPLegend::selectableChanged)) {
                *result = 1;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPLegend *_t = static_cast<QCPLegend *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = _t->borderPen(); break;
        case 1: *reinterpret_cast< QBrush*>(_v) = _t->brush(); break;
        case 2: *reinterpret_cast< QFont*>(_v) = _t->font(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = _t->textColor(); break;
        case 4: *reinterpret_cast< QSize*>(_v) = _t->iconSize(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->iconTextPadding(); break;
        case 6: *reinterpret_cast< QPen*>(_v) = _t->iconBorderPen(); break;
        case 7: *reinterpret_cast<int*>(_v) = QFlag(_t->selectableParts()); break;
        case 8: *reinterpret_cast<int*>(_v) = QFlag(_t->selectedParts()); break;
        case 9: *reinterpret_cast< QPen*>(_v) = _t->selectedBorderPen(); break;
        case 10: *reinterpret_cast< QPen*>(_v) = _t->selectedIconBorderPen(); break;
        case 11: *reinterpret_cast< QBrush*>(_v) = _t->selectedBrush(); break;
        case 12: *reinterpret_cast< QFont*>(_v) = _t->selectedFont(); break;
        case 13: *reinterpret_cast< QColor*>(_v) = _t->selectedTextColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPLegend *_t = static_cast<QCPLegend *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: _t->setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 2: _t->setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 3: _t->setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 4: _t->setIconSize(*reinterpret_cast< QSize*>(_v)); break;
        case 5: _t->setIconTextPadding(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setIconBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 7: _t->setSelectableParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 8: _t->setSelectedParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 9: _t->setSelectedBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 10: _t->setSelectedIconBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 11: _t->setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 12: _t->setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 13: _t->setSelectedTextColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QCPLegend::staticMetaObject = {
    { &QCPLayoutGrid::staticMetaObject, qt_meta_stringdata_QCPLegend.data,
      qt_meta_data_QCPLegend,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPLegend::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLegend::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLegend.stringdata0))
        return static_cast<void*>(const_cast< QCPLegend*>(this));
    return QCPLayoutGrid::qt_metacast(_clname);
}

int QCPLegend::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutGrid::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 14;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPLegend::selectionChanged(QCPLegend::SelectableParts _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPLegend::selectableChanged(QCPLegend::SelectableParts _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_QCPPlotTitle_t {
    QByteArrayData data[13];
    char stringdata0[146];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPPlotTitle_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPPlotTitle_t qt_meta_stringdata_QCPPlotTitle = {
    {
QT_MOC_LITERAL(0, 0, 12), // "QCPPlotTitle"
QT_MOC_LITERAL(1, 13, 16), // "selectionChanged"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 8), // "selected"
QT_MOC_LITERAL(4, 40, 17), // "selectableChanged"
QT_MOC_LITERAL(5, 58, 10), // "selectable"
QT_MOC_LITERAL(6, 69, 13), // "setSelectable"
QT_MOC_LITERAL(7, 83, 11), // "setSelected"
QT_MOC_LITERAL(8, 95, 4), // "text"
QT_MOC_LITERAL(9, 100, 4), // "font"
QT_MOC_LITERAL(10, 105, 9), // "textColor"
QT_MOC_LITERAL(11, 115, 12), // "selectedFont"
QT_MOC_LITERAL(12, 128, 17) // "selectedTextColor"

    },
    "QCPPlotTitle\0selectionChanged\0\0selected\0"
    "selectableChanged\0selectable\0setSelectable\0"
    "setSelected\0text\0font\0textColor\0"
    "selectedFont\0selectedTextColor"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPPlotTitle[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       7,   46, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   34,    2, 0x06 /* Public */,
       4,    1,   37,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,   40,    2, 0x0a /* Public */,
       7,    1,   43,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    3,

 // properties: name, type, flags
       8, QMetaType::QString, 0x00095103,
       9, QMetaType::QFont, 0x00095103,
      10, QMetaType::QColor, 0x00095103,
      11, QMetaType::QFont, 0x00095103,
      12, QMetaType::QColor, 0x00095103,
       5, QMetaType::Bool, 0x00495103,
       3, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       1,
       0,

       0        // eod
};

void QCPPlotTitle::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPPlotTitle *_t = static_cast<QCPPlotTitle *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->selectableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->setSelectable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->setSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPPlotTitle::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPPlotTitle::selectionChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPPlotTitle::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPPlotTitle::selectableChanged)) {
                *result = 1;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPPlotTitle *_t = static_cast<QCPPlotTitle *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->text(); break;
        case 1: *reinterpret_cast< QFont*>(_v) = _t->font(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->textColor(); break;
        case 3: *reinterpret_cast< QFont*>(_v) = _t->selectedFont(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->selectedTextColor(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->selectable(); break;
        case 6: *reinterpret_cast< bool*>(_v) = _t->selected(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPPlotTitle *_t = static_cast<QCPPlotTitle *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setText(*reinterpret_cast< QString*>(_v)); break;
        case 1: _t->setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 2: _t->setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: _t->setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 4: _t->setSelectedTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setSelectable(*reinterpret_cast< bool*>(_v)); break;
        case 6: _t->setSelected(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject QCPPlotTitle::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPPlotTitle.data,
      qt_meta_data_QCPPlotTitle,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPPlotTitle::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPPlotTitle::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPPlotTitle.stringdata0))
        return static_cast<void*>(const_cast< QCPPlotTitle*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPPlotTitle::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPPlotTitle::selectionChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPPlotTitle::selectableChanged(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_QCPColorScaleAxisRectPrivate_t {
    QByteArrayData data[7];
    char stringdata0[128];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPColorScaleAxisRectPrivate_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPColorScaleAxisRectPrivate_t qt_meta_stringdata_QCPColorScaleAxisRectPrivate = {
    {
QT_MOC_LITERAL(0, 0, 28), // "QCPColorScaleAxisRectPrivate"
QT_MOC_LITERAL(1, 29, 20), // "axisSelectionChanged"
QT_MOC_LITERAL(2, 50, 0), // ""
QT_MOC_LITERAL(3, 51, 24), // "QCPAxis::SelectableParts"
QT_MOC_LITERAL(4, 76, 13), // "selectedParts"
QT_MOC_LITERAL(5, 90, 21), // "axisSelectableChanged"
QT_MOC_LITERAL(6, 112, 15) // "selectableParts"

    },
    "QCPColorScaleAxisRectPrivate\0"
    "axisSelectionChanged\0\0QCPAxis::SelectableParts\0"
    "selectedParts\0axisSelectableChanged\0"
    "selectableParts"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPColorScaleAxisRectPrivate[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x09 /* Protected */,
       5,    1,   27,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    6,

       0        // eod
};

void QCPColorScaleAxisRectPrivate::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPColorScaleAxisRectPrivate *_t = static_cast<QCPColorScaleAxisRectPrivate *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->axisSelectionChanged((*reinterpret_cast< QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 1: _t->axisSelectableChanged((*reinterpret_cast< QCPAxis::SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject QCPColorScaleAxisRectPrivate::staticMetaObject = {
    { &QCPAxisRect::staticMetaObject, qt_meta_stringdata_QCPColorScaleAxisRectPrivate.data,
      qt_meta_data_QCPColorScaleAxisRectPrivate,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPColorScaleAxisRectPrivate::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPColorScaleAxisRectPrivate::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPColorScaleAxisRectPrivate.stringdata0))
        return static_cast<void*>(const_cast< QCPColorScaleAxisRectPrivate*>(this));
    return QCPAxisRect::qt_metacast(_clname);
}

int QCPColorScaleAxisRectPrivate::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAxisRect::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
struct qt_meta_stringdata_QCPColorScale_t {
    QByteArrayData data[23];
    char stringdata0[278];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPColorScale_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPColorScale_t qt_meta_stringdata_QCPColorScale = {
    {
QT_MOC_LITERAL(0, 0, 13), // "QCPColorScale"
QT_MOC_LITERAL(1, 14, 16), // "dataRangeChanged"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 8), // "QCPRange"
QT_MOC_LITERAL(4, 41, 8), // "newRange"
QT_MOC_LITERAL(5, 50, 20), // "dataScaleTypeChanged"
QT_MOC_LITERAL(6, 71, 18), // "QCPAxis::ScaleType"
QT_MOC_LITERAL(7, 90, 9), // "scaleType"
QT_MOC_LITERAL(8, 100, 15), // "gradientChanged"
QT_MOC_LITERAL(9, 116, 16), // "QCPColorGradient"
QT_MOC_LITERAL(10, 133, 11), // "newGradient"
QT_MOC_LITERAL(11, 145, 12), // "setDataRange"
QT_MOC_LITERAL(12, 158, 9), // "dataRange"
QT_MOC_LITERAL(13, 168, 16), // "setDataScaleType"
QT_MOC_LITERAL(14, 185, 11), // "setGradient"
QT_MOC_LITERAL(15, 197, 8), // "gradient"
QT_MOC_LITERAL(16, 206, 4), // "type"
QT_MOC_LITERAL(17, 211, 17), // "QCPAxis::AxisType"
QT_MOC_LITERAL(18, 229, 13), // "dataScaleType"
QT_MOC_LITERAL(19, 243, 5), // "label"
QT_MOC_LITERAL(20, 249, 8), // "barWidth"
QT_MOC_LITERAL(21, 258, 9), // "rangeDrag"
QT_MOC_LITERAL(22, 268, 9) // "rangeZoom"

    },
    "QCPColorScale\0dataRangeChanged\0\0"
    "QCPRange\0newRange\0dataScaleTypeChanged\0"
    "QCPAxis::ScaleType\0scaleType\0"
    "gradientChanged\0QCPColorGradient\0"
    "newGradient\0setDataRange\0dataRange\0"
    "setDataScaleType\0setGradient\0gradient\0"
    "type\0QCPAxis::AxisType\0dataScaleType\0"
    "label\0barWidth\0rangeDrag\0rangeZoom"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPColorScale[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       8,   62, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   44,    2, 0x06 /* Public */,
       5,    1,   47,    2, 0x06 /* Public */,
       8,    1,   50,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      11,    1,   53,    2, 0x0a /* Public */,
      13,    1,   56,    2, 0x0a /* Public */,
      14,    1,   59,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,   10,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,   12,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,   15,

 // properties: name, type, flags
      16, 0x80000000 | 17, 0x0009510b,
      12, 0x80000000 | 3, 0x0049510b,
      18, 0x80000000 | 6, 0x0049510b,
      15, 0x80000000 | 9, 0x0049510b,
      19, QMetaType::QString, 0x00095103,
      20, QMetaType::Int, 0x00095103,
      21, QMetaType::Bool, 0x00095103,
      22, QMetaType::Bool, 0x00095103,

 // properties: notify_signal_id
       0,
       0,
       1,
       2,
       0,
       0,
       0,
       0,

       0        // eod
};

void QCPColorScale::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPColorScale *_t = static_cast<QCPColorScale *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->dataRangeChanged((*reinterpret_cast< QCPRange(*)>(_a[1]))); break;
        case 1: _t->dataScaleTypeChanged((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 2: _t->gradientChanged((*reinterpret_cast< QCPColorGradient(*)>(_a[1]))); break;
        case 3: _t->setDataRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 4: _t->setDataScaleType((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 5: _t->setGradient((*reinterpret_cast< const QCPColorGradient(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPColorScale::*_t)(QCPRange );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorScale::dataRangeChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPColorScale::*_t)(QCPAxis::ScaleType );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorScale::dataScaleTypeChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (QCPColorScale::*_t)(QCPColorGradient );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorScale::gradientChanged)) {
                *result = 2;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPColorScale *_t = static_cast<QCPColorScale *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPAxis::AxisType*>(_v) = _t->type(); break;
        case 1: *reinterpret_cast< QCPRange*>(_v) = _t->dataRange(); break;
        case 2: *reinterpret_cast< QCPAxis::ScaleType*>(_v) = _t->dataScaleType(); break;
        case 3: *reinterpret_cast< QCPColorGradient*>(_v) = _t->gradient(); break;
        case 4: *reinterpret_cast< QString*>(_v) = _t->label(); break;
        case 5: *reinterpret_cast< int*>(_v) = _t->barWidth(); break;
        case 6: *reinterpret_cast< bool*>(_v) = _t->rangeDrag(); break;
        case 7: *reinterpret_cast< bool*>(_v) = _t->rangeZoom(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPColorScale *_t = static_cast<QCPColorScale *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setType(*reinterpret_cast< QCPAxis::AxisType*>(_v)); break;
        case 1: _t->setDataRange(*reinterpret_cast< QCPRange*>(_v)); break;
        case 2: _t->setDataScaleType(*reinterpret_cast< QCPAxis::ScaleType*>(_v)); break;
        case 3: _t->setGradient(*reinterpret_cast< QCPColorGradient*>(_v)); break;
        case 4: _t->setLabel(*reinterpret_cast< QString*>(_v)); break;
        case 5: _t->setBarWidth(*reinterpret_cast< int*>(_v)); break;
        case 6: _t->setRangeDrag(*reinterpret_cast< bool*>(_v)); break;
        case 7: _t->setRangeZoom(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

static const QMetaObject * const qt_meta_extradata_QCPColorScale[] = {
        &QCPAxis::staticMetaObject,
    Q_NULLPTR
};

const QMetaObject QCPColorScale::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPColorScale.data,
      qt_meta_data_QCPColorScale,  qt_static_metacall, qt_meta_extradata_QCPColorScale, Q_NULLPTR}
};


const QMetaObject *QCPColorScale::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPColorScale::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPColorScale.stringdata0))
        return static_cast<void*>(const_cast< QCPColorScale*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPColorScale::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPColorScale::dataRangeChanged(QCPRange _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPColorScale::dataScaleTypeChanged(QCPAxis::ScaleType _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPColorScale::gradientChanged(QCPColorGradient _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
struct qt_meta_stringdata_QCPGraph_t {
    QByteArrayData data[23];
    char stringdata0[251];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPGraph_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPGraph_t qt_meta_stringdata_QCPGraph = {
    {
QT_MOC_LITERAL(0, 0, 8), // "QCPGraph"
QT_MOC_LITERAL(1, 9, 9), // "lineStyle"
QT_MOC_LITERAL(2, 19, 9), // "LineStyle"
QT_MOC_LITERAL(3, 29, 12), // "scatterStyle"
QT_MOC_LITERAL(4, 42, 15), // "QCPScatterStyle"
QT_MOC_LITERAL(5, 58, 9), // "errorType"
QT_MOC_LITERAL(6, 68, 9), // "ErrorType"
QT_MOC_LITERAL(7, 78, 8), // "errorPen"
QT_MOC_LITERAL(8, 87, 12), // "errorBarSize"
QT_MOC_LITERAL(9, 100, 18), // "errorBarSkipSymbol"
QT_MOC_LITERAL(10, 119, 16), // "channelFillGraph"
QT_MOC_LITERAL(11, 136, 9), // "QCPGraph*"
QT_MOC_LITERAL(12, 146, 16), // "adaptiveSampling"
QT_MOC_LITERAL(13, 163, 6), // "lsNone"
QT_MOC_LITERAL(14, 170, 6), // "lsLine"
QT_MOC_LITERAL(15, 177, 10), // "lsStepLeft"
QT_MOC_LITERAL(16, 188, 11), // "lsStepRight"
QT_MOC_LITERAL(17, 200, 12), // "lsStepCenter"
QT_MOC_LITERAL(18, 213, 9), // "lsImpulse"
QT_MOC_LITERAL(19, 223, 6), // "etNone"
QT_MOC_LITERAL(20, 230, 5), // "etKey"
QT_MOC_LITERAL(21, 236, 7), // "etValue"
QT_MOC_LITERAL(22, 244, 6) // "etBoth"

    },
    "QCPGraph\0lineStyle\0LineStyle\0scatterStyle\0"
    "QCPScatterStyle\0errorType\0ErrorType\0"
    "errorPen\0errorBarSize\0errorBarSkipSymbol\0"
    "channelFillGraph\0QCPGraph*\0adaptiveSampling\0"
    "lsNone\0lsLine\0lsStepLeft\0lsStepRight\0"
    "lsStepCenter\0lsImpulse\0etNone\0etKey\0"
    "etValue\0etBoth"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPGraph[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       8,   14, // properties
       2,   38, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x0009510b,
       3, 0x80000000 | 4, 0x0009510b,
       5, 0x80000000 | 6, 0x0009510b,
       7, QMetaType::QPen, 0x00095103,
       8, QMetaType::Double, 0x00095103,
       9, QMetaType::Bool, 0x00095103,
      10, 0x80000000 | 11, 0x0009510b,
      12, QMetaType::Bool, 0x00095103,

 // enums: name, flags, count, data
       2, 0x0,    6,   46,
       6, 0x0,    4,   58,

 // enum data: key, value
      13, uint(QCPGraph::lsNone),
      14, uint(QCPGraph::lsLine),
      15, uint(QCPGraph::lsStepLeft),
      16, uint(QCPGraph::lsStepRight),
      17, uint(QCPGraph::lsStepCenter),
      18, uint(QCPGraph::lsImpulse),
      19, uint(QCPGraph::etNone),
      20, uint(QCPGraph::etKey),
      21, uint(QCPGraph::etValue),
      22, uint(QCPGraph::etBoth),

       0        // eod
};

void QCPGraph::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPGraph* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPGraph *_t = static_cast<QCPGraph *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< LineStyle*>(_v) = _t->lineStyle(); break;
        case 1: *reinterpret_cast< QCPScatterStyle*>(_v) = _t->scatterStyle(); break;
        case 2: *reinterpret_cast< ErrorType*>(_v) = _t->errorType(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = _t->errorPen(); break;
        case 4: *reinterpret_cast< double*>(_v) = _t->errorBarSize(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->errorBarSkipSymbol(); break;
        case 6: *reinterpret_cast< QCPGraph**>(_v) = _t->channelFillGraph(); break;
        case 7: *reinterpret_cast< bool*>(_v) = _t->adaptiveSampling(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPGraph *_t = static_cast<QCPGraph *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setLineStyle(*reinterpret_cast< LineStyle*>(_v)); break;
        case 1: _t->setScatterStyle(*reinterpret_cast< QCPScatterStyle*>(_v)); break;
        case 2: _t->setErrorType(*reinterpret_cast< ErrorType*>(_v)); break;
        case 3: _t->setErrorPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: _t->setErrorBarSize(*reinterpret_cast< double*>(_v)); break;
        case 5: _t->setErrorBarSkipSymbol(*reinterpret_cast< bool*>(_v)); break;
        case 6: _t->setChannelFillGraph(*reinterpret_cast< QCPGraph**>(_v)); break;
        case 7: _t->setAdaptiveSampling(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
}

const QMetaObject QCPGraph::staticMetaObject = {
    { &QCPAbstractPlottable::staticMetaObject, qt_meta_stringdata_QCPGraph.data,
      qt_meta_data_QCPGraph,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPGraph::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPGraph::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPGraph.stringdata0))
        return static_cast<void*>(const_cast< QCPGraph*>(this));
    return QCPAbstractPlottable::qt_metacast(_clname);
}

int QCPGraph::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPCurve_t {
    QByteArrayData data[5];
    char stringdata0[58];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPCurve_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPCurve_t qt_meta_stringdata_QCPCurve = {
    {
QT_MOC_LITERAL(0, 0, 8), // "QCPCurve"
QT_MOC_LITERAL(1, 9, 12), // "scatterStyle"
QT_MOC_LITERAL(2, 22, 15), // "QCPScatterStyle"
QT_MOC_LITERAL(3, 38, 9), // "lineStyle"
QT_MOC_LITERAL(4, 48, 9) // "LineStyle"

    },
    "QCPCurve\0scatterStyle\0QCPScatterStyle\0"
    "lineStyle\0LineStyle"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPCurve[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       2,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x0009510b,
       3, 0x80000000 | 4, 0x0009510b,

       0        // eod
};

void QCPCurve::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPCurve *_t = static_cast<QCPCurve *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPScatterStyle*>(_v) = _t->scatterStyle(); break;
        case 1: *reinterpret_cast< LineStyle*>(_v) = _t->lineStyle(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPCurve *_t = static_cast<QCPCurve *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setScatterStyle(*reinterpret_cast< QCPScatterStyle*>(_v)); break;
        case 1: _t->setLineStyle(*reinterpret_cast< LineStyle*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPCurve::staticMetaObject = {
    { &QCPAbstractPlottable::staticMetaObject, qt_meta_stringdata_QCPCurve.data,
      qt_meta_data_QCPCurve,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPCurve::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPCurve::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPCurve.stringdata0))
        return static_cast<void*>(const_cast< QCPCurve*>(this));
    return QCPAbstractPlottable::qt_metacast(_clname);
}

int QCPCurve::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPBars_t {
    QByteArrayData data[5];
    char stringdata0[41];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPBars_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPBars_t qt_meta_stringdata_QCPBars = {
    {
QT_MOC_LITERAL(0, 0, 7), // "QCPBars"
QT_MOC_LITERAL(1, 8, 5), // "width"
QT_MOC_LITERAL(2, 14, 8), // "barBelow"
QT_MOC_LITERAL(3, 23, 8), // "QCPBars*"
QT_MOC_LITERAL(4, 32, 8) // "barAbove"

    },
    "QCPBars\0width\0barBelow\0QCPBars*\0"
    "barAbove"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPBars[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       3,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::Double, 0x00095103,
       2, 0x80000000 | 3, 0x00095009,
       4, 0x80000000 | 3, 0x00095009,

       0        // eod
};

void QCPBars::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 2:
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPBars* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPBars *_t = static_cast<QCPBars *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = _t->width(); break;
        case 1: *reinterpret_cast< QCPBars**>(_v) = _t->barBelow(); break;
        case 2: *reinterpret_cast< QCPBars**>(_v) = _t->barAbove(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPBars *_t = static_cast<QCPBars *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setWidth(*reinterpret_cast< double*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
}

const QMetaObject QCPBars::staticMetaObject = {
    { &QCPAbstractPlottable::staticMetaObject, qt_meta_stringdata_QCPBars.data,
      qt_meta_data_QCPBars,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPBars::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPBars::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPBars.stringdata0))
        return static_cast<void*>(const_cast< QCPBars*>(this));
    return QCPAbstractPlottable::qt_metacast(_clname);
}

int QCPBars::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 3;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPStatisticalBox_t {
    QByteArrayData data[16];
    char stringdata0[181];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPStatisticalBox_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPStatisticalBox_t qt_meta_stringdata_QCPStatisticalBox = {
    {
QT_MOC_LITERAL(0, 0, 17), // "QCPStatisticalBox"
QT_MOC_LITERAL(1, 18, 3), // "key"
QT_MOC_LITERAL(2, 22, 7), // "minimum"
QT_MOC_LITERAL(3, 30, 13), // "lowerQuartile"
QT_MOC_LITERAL(4, 44, 6), // "median"
QT_MOC_LITERAL(5, 51, 13), // "upperQuartile"
QT_MOC_LITERAL(6, 65, 7), // "maximum"
QT_MOC_LITERAL(7, 73, 8), // "outliers"
QT_MOC_LITERAL(8, 82, 15), // "QVector<double>"
QT_MOC_LITERAL(9, 98, 5), // "width"
QT_MOC_LITERAL(10, 104, 12), // "whiskerWidth"
QT_MOC_LITERAL(11, 117, 10), // "whiskerPen"
QT_MOC_LITERAL(12, 128, 13), // "whiskerBarPen"
QT_MOC_LITERAL(13, 142, 9), // "medianPen"
QT_MOC_LITERAL(14, 152, 12), // "outlierStyle"
QT_MOC_LITERAL(15, 165, 15) // "QCPScatterStyle"

    },
    "QCPStatisticalBox\0key\0minimum\0"
    "lowerQuartile\0median\0upperQuartile\0"
    "maximum\0outliers\0QVector<double>\0width\0"
    "whiskerWidth\0whiskerPen\0whiskerBarPen\0"
    "medianPen\0outlierStyle\0QCPScatterStyle"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPStatisticalBox[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
      13,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::Double, 0x00095103,
       2, QMetaType::Double, 0x00095103,
       3, QMetaType::Double, 0x00095103,
       4, QMetaType::Double, 0x00095103,
       5, QMetaType::Double, 0x00095103,
       6, QMetaType::Double, 0x00095103,
       7, 0x80000000 | 8, 0x0009510b,
       9, QMetaType::Double, 0x00095103,
      10, QMetaType::Double, 0x00095103,
      11, QMetaType::QPen, 0x00095103,
      12, QMetaType::QPen, 0x00095103,
      13, QMetaType::QPen, 0x00095103,
      14, 0x80000000 | 15, 0x0009510b,

       0        // eod
};

void QCPStatisticalBox::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QVector<double> >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPStatisticalBox *_t = static_cast<QCPStatisticalBox *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = _t->key(); break;
        case 1: *reinterpret_cast< double*>(_v) = _t->minimum(); break;
        case 2: *reinterpret_cast< double*>(_v) = _t->lowerQuartile(); break;
        case 3: *reinterpret_cast< double*>(_v) = _t->median(); break;
        case 4: *reinterpret_cast< double*>(_v) = _t->upperQuartile(); break;
        case 5: *reinterpret_cast< double*>(_v) = _t->maximum(); break;
        case 6: *reinterpret_cast< QVector<double>*>(_v) = _t->outliers(); break;
        case 7: *reinterpret_cast< double*>(_v) = _t->width(); break;
        case 8: *reinterpret_cast< double*>(_v) = _t->whiskerWidth(); break;
        case 9: *reinterpret_cast< QPen*>(_v) = _t->whiskerPen(); break;
        case 10: *reinterpret_cast< QPen*>(_v) = _t->whiskerBarPen(); break;
        case 11: *reinterpret_cast< QPen*>(_v) = _t->medianPen(); break;
        case 12: *reinterpret_cast< QCPScatterStyle*>(_v) = _t->outlierStyle(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPStatisticalBox *_t = static_cast<QCPStatisticalBox *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setKey(*reinterpret_cast< double*>(_v)); break;
        case 1: _t->setMinimum(*reinterpret_cast< double*>(_v)); break;
        case 2: _t->setLowerQuartile(*reinterpret_cast< double*>(_v)); break;
        case 3: _t->setMedian(*reinterpret_cast< double*>(_v)); break;
        case 4: _t->setUpperQuartile(*reinterpret_cast< double*>(_v)); break;
        case 5: _t->setMaximum(*reinterpret_cast< double*>(_v)); break;
        case 6: _t->setOutliers(*reinterpret_cast< QVector<double>*>(_v)); break;
        case 7: _t->setWidth(*reinterpret_cast< double*>(_v)); break;
        case 8: _t->setWhiskerWidth(*reinterpret_cast< double*>(_v)); break;
        case 9: _t->setWhiskerPen(*reinterpret_cast< QPen*>(_v)); break;
        case 10: _t->setWhiskerBarPen(*reinterpret_cast< QPen*>(_v)); break;
        case 11: _t->setMedianPen(*reinterpret_cast< QPen*>(_v)); break;
        case 12: _t->setOutlierStyle(*reinterpret_cast< QCPScatterStyle*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
}

const QMetaObject QCPStatisticalBox::staticMetaObject = {
    { &QCPAbstractPlottable::staticMetaObject, qt_meta_stringdata_QCPStatisticalBox.data,
      qt_meta_data_QCPStatisticalBox,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPStatisticalBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPStatisticalBox::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPStatisticalBox.stringdata0))
        return static_cast<void*>(const_cast< QCPStatisticalBox*>(this));
    return QCPAbstractPlottable::qt_metacast(_clname);
}

int QCPStatisticalBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 13;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPColorMap_t {
    QByteArrayData data[25];
    char stringdata0[334];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPColorMap_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPColorMap_t qt_meta_stringdata_QCPColorMap = {
    {
QT_MOC_LITERAL(0, 0, 11), // "QCPColorMap"
QT_MOC_LITERAL(1, 12, 16), // "dataRangeChanged"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 8), // "QCPRange"
QT_MOC_LITERAL(4, 39, 8), // "newRange"
QT_MOC_LITERAL(5, 48, 20), // "dataScaleTypeChanged"
QT_MOC_LITERAL(6, 69, 18), // "QCPAxis::ScaleType"
QT_MOC_LITERAL(7, 88, 9), // "scaleType"
QT_MOC_LITERAL(8, 98, 15), // "gradientChanged"
QT_MOC_LITERAL(9, 114, 16), // "QCPColorGradient"
QT_MOC_LITERAL(10, 131, 11), // "newGradient"
QT_MOC_LITERAL(11, 143, 12), // "setDataRange"
QT_MOC_LITERAL(12, 156, 9), // "dataRange"
QT_MOC_LITERAL(13, 166, 16), // "setDataScaleType"
QT_MOC_LITERAL(14, 183, 11), // "setGradient"
QT_MOC_LITERAL(15, 195, 8), // "gradient"
QT_MOC_LITERAL(16, 204, 16), // "updateLegendIcon"
QT_MOC_LITERAL(17, 221, 22), // "Qt::TransformationMode"
QT_MOC_LITERAL(18, 244, 13), // "transformMode"
QT_MOC_LITERAL(19, 258, 9), // "thumbSize"
QT_MOC_LITERAL(20, 268, 13), // "dataScaleType"
QT_MOC_LITERAL(21, 282, 11), // "interpolate"
QT_MOC_LITERAL(22, 294, 13), // "tightBoundary"
QT_MOC_LITERAL(23, 308, 10), // "colorScale"
QT_MOC_LITERAL(24, 319, 14) // "QCPColorScale*"

    },
    "QCPColorMap\0dataRangeChanged\0\0QCPRange\0"
    "newRange\0dataScaleTypeChanged\0"
    "QCPAxis::ScaleType\0scaleType\0"
    "gradientChanged\0QCPColorGradient\0"
    "newGradient\0setDataRange\0dataRange\0"
    "setDataScaleType\0setGradient\0gradient\0"
    "updateLegendIcon\0Qt::TransformationMode\0"
    "transformMode\0thumbSize\0dataScaleType\0"
    "interpolate\0tightBoundary\0colorScale\0"
    "QCPColorScale*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPColorMap[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       6,   86, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x06 /* Public */,
       5,    1,   62,    2, 0x06 /* Public */,
       8,    1,   65,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      11,    1,   68,    2, 0x0a /* Public */,
      13,    1,   71,    2, 0x0a /* Public */,
      14,    1,   74,    2, 0x0a /* Public */,
      16,    2,   77,    2, 0x0a /* Public */,
      16,    1,   82,    2, 0x2a /* Public | MethodCloned */,
      16,    0,   85,    2, 0x2a /* Public | MethodCloned */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,   10,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,   12,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,   15,
    QMetaType::Void, 0x80000000 | 17, QMetaType::QSize,   18,   19,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void,

 // properties: name, type, flags
      12, 0x80000000 | 3, 0x0049510b,
      20, 0x80000000 | 6, 0x0049510b,
      15, 0x80000000 | 9, 0x0049510b,
      21, QMetaType::Bool, 0x00095103,
      22, QMetaType::Bool, 0x00095103,
      23, 0x80000000 | 24, 0x0009510b,

 // properties: notify_signal_id
       0,
       1,
       2,
       0,
       0,
       0,

       0        // eod
};

void QCPColorMap::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPColorMap *_t = static_cast<QCPColorMap *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->dataRangeChanged((*reinterpret_cast< QCPRange(*)>(_a[1]))); break;
        case 1: _t->dataScaleTypeChanged((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 2: _t->gradientChanged((*reinterpret_cast< QCPColorGradient(*)>(_a[1]))); break;
        case 3: _t->setDataRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 4: _t->setDataScaleType((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 5: _t->setGradient((*reinterpret_cast< const QCPColorGradient(*)>(_a[1]))); break;
        case 6: _t->updateLegendIcon((*reinterpret_cast< Qt::TransformationMode(*)>(_a[1])),(*reinterpret_cast< const QSize(*)>(_a[2]))); break;
        case 7: _t->updateLegendIcon((*reinterpret_cast< Qt::TransformationMode(*)>(_a[1]))); break;
        case 8: _t->updateLegendIcon(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPColorMap::*_t)(QCPRange );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorMap::dataRangeChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPColorMap::*_t)(QCPAxis::ScaleType );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorMap::dataScaleTypeChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (QCPColorMap::*_t)(QCPColorGradient );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorMap::gradientChanged)) {
                *result = 2;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 5:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPColorScale* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPColorMap *_t = static_cast<QCPColorMap *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPRange*>(_v) = _t->dataRange(); break;
        case 1: *reinterpret_cast< QCPAxis::ScaleType*>(_v) = _t->dataScaleType(); break;
        case 2: *reinterpret_cast< QCPColorGradient*>(_v) = _t->gradient(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->interpolate(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->tightBoundary(); break;
        case 5: *reinterpret_cast< QCPColorScale**>(_v) = _t->colorScale(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPColorMap *_t = static_cast<QCPColorMap *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setDataRange(*reinterpret_cast< QCPRange*>(_v)); break;
        case 1: _t->setDataScaleType(*reinterpret_cast< QCPAxis::ScaleType*>(_v)); break;
        case 2: _t->setGradient(*reinterpret_cast< QCPColorGradient*>(_v)); break;
        case 3: _t->setInterpolate(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->setTightBoundary(*reinterpret_cast< bool*>(_v)); break;
        case 5: _t->setColorScale(*reinterpret_cast< QCPColorScale**>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

static const QMetaObject * const qt_meta_extradata_QCPColorMap[] = {
        &QCPAxis::staticMetaObject,
    Q_NULLPTR
};

const QMetaObject QCPColorMap::staticMetaObject = {
    { &QCPAbstractPlottable::staticMetaObject, qt_meta_stringdata_QCPColorMap.data,
      qt_meta_data_QCPColorMap,  qt_static_metacall, qt_meta_extradata_QCPColorMap, Q_NULLPTR}
};


const QMetaObject *QCPColorMap::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPColorMap::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPColorMap.stringdata0))
        return static_cast<void*>(const_cast< QCPColorMap*>(this));
    return QCPAbstractPlottable::qt_metacast(_clname);
}

int QCPColorMap::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPColorMap::dataRangeChanged(QCPRange _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPColorMap::dataScaleTypeChanged(QCPAxis::ScaleType _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPColorMap::gradientChanged(QCPColorGradient _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
struct qt_meta_stringdata_QCPItemStraightLine_t {
    QByteArrayData data[3];
    char stringdata0[36];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemStraightLine_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemStraightLine_t qt_meta_stringdata_QCPItemStraightLine = {
    {
QT_MOC_LITERAL(0, 0, 19), // "QCPItemStraightLine"
QT_MOC_LITERAL(1, 20, 3), // "pen"
QT_MOC_LITERAL(2, 24, 11) // "selectedPen"

    },
    "QCPItemStraightLine\0pen\0selectedPen"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemStraightLine[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       2,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,

       0        // eod
};

void QCPItemStraightLine::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPItemStraightLine *_t = static_cast<QCPItemStraightLine *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = _t->selectedPen(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPItemStraightLine *_t = static_cast<QCPItemStraightLine *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: _t->setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemStraightLine::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemStraightLine.data,
      qt_meta_data_QCPItemStraightLine,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPItemStraightLine::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemStraightLine::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemStraightLine.stringdata0))
        return static_cast<void*>(const_cast< QCPItemStraightLine*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemStraightLine::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemLine_t {
    QByteArrayData data[6];
    char stringdata0[52];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemLine_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemLine_t qt_meta_stringdata_QCPItemLine = {
    {
QT_MOC_LITERAL(0, 0, 11), // "QCPItemLine"
QT_MOC_LITERAL(1, 12, 3), // "pen"
QT_MOC_LITERAL(2, 16, 11), // "selectedPen"
QT_MOC_LITERAL(3, 28, 4), // "head"
QT_MOC_LITERAL(4, 33, 13), // "QCPLineEnding"
QT_MOC_LITERAL(5, 47, 4) // "tail"

    },
    "QCPItemLine\0pen\0selectedPen\0head\0"
    "QCPLineEnding\0tail"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemLine[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, 0x80000000 | 4, 0x0009510b,
       5, 0x80000000 | 4, 0x0009510b,

       0        // eod
};

void QCPItemLine::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPItemLine *_t = static_cast<QCPItemLine *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = _t->selectedPen(); break;
        case 2: *reinterpret_cast< QCPLineEnding*>(_v) = _t->head(); break;
        case 3: *reinterpret_cast< QCPLineEnding*>(_v) = _t->tail(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPItemLine *_t = static_cast<QCPItemLine *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: _t->setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: _t->setHead(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        case 3: _t->setTail(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemLine::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemLine.data,
      qt_meta_data_QCPItemLine,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPItemLine::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemLine::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemLine.stringdata0))
        return static_cast<void*>(const_cast< QCPItemLine*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemLine::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemCurve_t {
    QByteArrayData data[6];
    char stringdata0[53];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemCurve_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemCurve_t qt_meta_stringdata_QCPItemCurve = {
    {
QT_MOC_LITERAL(0, 0, 12), // "QCPItemCurve"
QT_MOC_LITERAL(1, 13, 3), // "pen"
QT_MOC_LITERAL(2, 17, 11), // "selectedPen"
QT_MOC_LITERAL(3, 29, 4), // "head"
QT_MOC_LITERAL(4, 34, 13), // "QCPLineEnding"
QT_MOC_LITERAL(5, 48, 4) // "tail"

    },
    "QCPItemCurve\0pen\0selectedPen\0head\0"
    "QCPLineEnding\0tail"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemCurve[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, 0x80000000 | 4, 0x0009510b,
       5, 0x80000000 | 4, 0x0009510b,

       0        // eod
};

void QCPItemCurve::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPItemCurve *_t = static_cast<QCPItemCurve *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = _t->selectedPen(); break;
        case 2: *reinterpret_cast< QCPLineEnding*>(_v) = _t->head(); break;
        case 3: *reinterpret_cast< QCPLineEnding*>(_v) = _t->tail(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPItemCurve *_t = static_cast<QCPItemCurve *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: _t->setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: _t->setHead(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        case 3: _t->setTail(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemCurve::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemCurve.data,
      qt_meta_data_QCPItemCurve,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPItemCurve::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemCurve::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemCurve.stringdata0))
        return static_cast<void*>(const_cast< QCPItemCurve*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemCurve::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemRect_t {
    QByteArrayData data[5];
    char stringdata0[48];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemRect_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemRect_t qt_meta_stringdata_QCPItemRect = {
    {
QT_MOC_LITERAL(0, 0, 11), // "QCPItemRect"
QT_MOC_LITERAL(1, 12, 3), // "pen"
QT_MOC_LITERAL(2, 16, 11), // "selectedPen"
QT_MOC_LITERAL(3, 28, 5), // "brush"
QT_MOC_LITERAL(4, 34, 13) // "selectedBrush"

    },
    "QCPItemRect\0pen\0selectedPen\0brush\0"
    "selectedBrush"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemRect[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, QMetaType::QBrush, 0x00095103,
       4, QMetaType::QBrush, 0x00095103,

       0        // eod
};

void QCPItemRect::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPItemRect *_t = static_cast<QCPItemRect *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = _t->selectedPen(); break;
        case 2: *reinterpret_cast< QBrush*>(_v) = _t->brush(); break;
        case 3: *reinterpret_cast< QBrush*>(_v) = _t->selectedBrush(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPItemRect *_t = static_cast<QCPItemRect *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: _t->setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: _t->setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 3: _t->setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemRect::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemRect.data,
      qt_meta_data_QCPItemRect,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPItemRect::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemRect::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemRect.stringdata0))
        return static_cast<void*>(const_cast< QCPItemRect*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemRect::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemText_t {
    QByteArrayData data[16];
    char stringdata0[163];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemText_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemText_t qt_meta_stringdata_QCPItemText = {
    {
QT_MOC_LITERAL(0, 0, 11), // "QCPItemText"
QT_MOC_LITERAL(1, 12, 5), // "color"
QT_MOC_LITERAL(2, 18, 13), // "selectedColor"
QT_MOC_LITERAL(3, 32, 3), // "pen"
QT_MOC_LITERAL(4, 36, 11), // "selectedPen"
QT_MOC_LITERAL(5, 48, 5), // "brush"
QT_MOC_LITERAL(6, 54, 13), // "selectedBrush"
QT_MOC_LITERAL(7, 68, 4), // "font"
QT_MOC_LITERAL(8, 73, 12), // "selectedFont"
QT_MOC_LITERAL(9, 86, 4), // "text"
QT_MOC_LITERAL(10, 91, 17), // "positionAlignment"
QT_MOC_LITERAL(11, 109, 13), // "Qt::Alignment"
QT_MOC_LITERAL(12, 123, 13), // "textAlignment"
QT_MOC_LITERAL(13, 137, 8), // "rotation"
QT_MOC_LITERAL(14, 146, 7), // "padding"
QT_MOC_LITERAL(15, 154, 8) // "QMargins"

    },
    "QCPItemText\0color\0selectedColor\0pen\0"
    "selectedPen\0brush\0selectedBrush\0font\0"
    "selectedFont\0text\0positionAlignment\0"
    "Qt::Alignment\0textAlignment\0rotation\0"
    "padding\0QMargins"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemText[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
      13,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QColor, 0x00095103,
       2, QMetaType::QColor, 0x00095103,
       3, QMetaType::QPen, 0x00095103,
       4, QMetaType::QPen, 0x00095103,
       5, QMetaType::QBrush, 0x00095103,
       6, QMetaType::QBrush, 0x00095103,
       7, QMetaType::QFont, 0x00095103,
       8, QMetaType::QFont, 0x00095103,
       9, QMetaType::QString, 0x00095103,
      10, 0x80000000 | 11, 0x0009510b,
      12, 0x80000000 | 11, 0x0009510b,
      13, QMetaType::Double, 0x00095103,
      14, 0x80000000 | 15, 0x0009510b,

       0        // eod
};

void QCPItemText::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPItemText *_t = static_cast<QCPItemText *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->color(); break;
        case 1: *reinterpret_cast< QColor*>(_v) = _t->selectedColor(); break;
        case 2: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = _t->selectedPen(); break;
        case 4: *reinterpret_cast< QBrush*>(_v) = _t->brush(); break;
        case 5: *reinterpret_cast< QBrush*>(_v) = _t->selectedBrush(); break;
        case 6: *reinterpret_cast< QFont*>(_v) = _t->font(); break;
        case 7: *reinterpret_cast< QFont*>(_v) = _t->selectedFont(); break;
        case 8: *reinterpret_cast< QString*>(_v) = _t->text(); break;
        case 9: *reinterpret_cast< Qt::Alignment*>(_v) = _t->positionAlignment(); break;
        case 10: *reinterpret_cast< Qt::Alignment*>(_v) = _t->textAlignment(); break;
        case 11: *reinterpret_cast< double*>(_v) = _t->rotation(); break;
        case 12: *reinterpret_cast< QMargins*>(_v) = _t->padding(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPItemText *_t = static_cast<QCPItemText *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setColor(*reinterpret_cast< QColor*>(_v)); break;
        case 1: _t->setSelectedColor(*reinterpret_cast< QColor*>(_v)); break;
        case 2: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 3: _t->setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: _t->setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 5: _t->setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 6: _t->setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 7: _t->setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 8: _t->setText(*reinterpret_cast< QString*>(_v)); break;
        case 9: _t->setPositionAlignment(*reinterpret_cast< Qt::Alignment*>(_v)); break;
        case 10: _t->setTextAlignment(*reinterpret_cast< Qt::Alignment*>(_v)); break;
        case 11: _t->setRotation(*reinterpret_cast< double*>(_v)); break;
        case 12: _t->setPadding(*reinterpret_cast< QMargins*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemText::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemText.data,
      qt_meta_data_QCPItemText,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPItemText::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemText::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemText.stringdata0))
        return static_cast<void*>(const_cast< QCPItemText*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemText::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 13;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemEllipse_t {
    QByteArrayData data[5];
    char stringdata0[51];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemEllipse_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemEllipse_t qt_meta_stringdata_QCPItemEllipse = {
    {
QT_MOC_LITERAL(0, 0, 14), // "QCPItemEllipse"
QT_MOC_LITERAL(1, 15, 3), // "pen"
QT_MOC_LITERAL(2, 19, 11), // "selectedPen"
QT_MOC_LITERAL(3, 31, 5), // "brush"
QT_MOC_LITERAL(4, 37, 13) // "selectedBrush"

    },
    "QCPItemEllipse\0pen\0selectedPen\0brush\0"
    "selectedBrush"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemEllipse[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, QMetaType::QBrush, 0x00095103,
       4, QMetaType::QBrush, 0x00095103,

       0        // eod
};

void QCPItemEllipse::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPItemEllipse *_t = static_cast<QCPItemEllipse *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = _t->selectedPen(); break;
        case 2: *reinterpret_cast< QBrush*>(_v) = _t->brush(); break;
        case 3: *reinterpret_cast< QBrush*>(_v) = _t->selectedBrush(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPItemEllipse *_t = static_cast<QCPItemEllipse *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: _t->setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: _t->setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 3: _t->setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemEllipse::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemEllipse.data,
      qt_meta_data_QCPItemEllipse,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPItemEllipse::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemEllipse::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemEllipse.stringdata0))
        return static_cast<void*>(const_cast< QCPItemEllipse*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemEllipse::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemPixmap_t {
    QByteArrayData data[7];
    char stringdata0[80];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemPixmap_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemPixmap_t qt_meta_stringdata_QCPItemPixmap = {
    {
QT_MOC_LITERAL(0, 0, 13), // "QCPItemPixmap"
QT_MOC_LITERAL(1, 14, 6), // "pixmap"
QT_MOC_LITERAL(2, 21, 6), // "scaled"
QT_MOC_LITERAL(3, 28, 15), // "aspectRatioMode"
QT_MOC_LITERAL(4, 44, 19), // "Qt::AspectRatioMode"
QT_MOC_LITERAL(5, 64, 3), // "pen"
QT_MOC_LITERAL(6, 68, 11) // "selectedPen"

    },
    "QCPItemPixmap\0pixmap\0scaled\0aspectRatioMode\0"
    "Qt::AspectRatioMode\0pen\0selectedPen"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemPixmap[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       5,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPixmap, 0x00095103,
       2, QMetaType::Bool, 0x00095103,
       3, 0x80000000 | 4, 0x00095009,
       5, QMetaType::QPen, 0x00095103,
       6, QMetaType::QPen, 0x00095103,

       0        // eod
};

void QCPItemPixmap::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPItemPixmap *_t = static_cast<QCPItemPixmap *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPixmap*>(_v) = _t->pixmap(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->scaled(); break;
        case 2: *reinterpret_cast< Qt::AspectRatioMode*>(_v) = _t->aspectRatioMode(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 4: *reinterpret_cast< QPen*>(_v) = _t->selectedPen(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPItemPixmap *_t = static_cast<QCPItemPixmap *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setPixmap(*reinterpret_cast< QPixmap*>(_v)); break;
        case 1: _t->setScaled(*reinterpret_cast< bool*>(_v)); break;
        case 3: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: _t->setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemPixmap::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemPixmap.data,
      qt_meta_data_QCPItemPixmap,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPItemPixmap::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemPixmap::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemPixmap.stringdata0))
        return static_cast<void*>(const_cast< QCPItemPixmap*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemPixmap::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemTracer_t {
    QByteArrayData data[17];
    char stringdata0[156];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemTracer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemTracer_t qt_meta_stringdata_QCPItemTracer = {
    {
QT_MOC_LITERAL(0, 0, 13), // "QCPItemTracer"
QT_MOC_LITERAL(1, 14, 3), // "pen"
QT_MOC_LITERAL(2, 18, 11), // "selectedPen"
QT_MOC_LITERAL(3, 30, 5), // "brush"
QT_MOC_LITERAL(4, 36, 13), // "selectedBrush"
QT_MOC_LITERAL(5, 50, 4), // "size"
QT_MOC_LITERAL(6, 55, 5), // "style"
QT_MOC_LITERAL(7, 61, 11), // "TracerStyle"
QT_MOC_LITERAL(8, 73, 5), // "graph"
QT_MOC_LITERAL(9, 79, 9), // "QCPGraph*"
QT_MOC_LITERAL(10, 89, 8), // "graphKey"
QT_MOC_LITERAL(11, 98, 13), // "interpolating"
QT_MOC_LITERAL(12, 112, 6), // "tsNone"
QT_MOC_LITERAL(13, 119, 6), // "tsPlus"
QT_MOC_LITERAL(14, 126, 11), // "tsCrosshair"
QT_MOC_LITERAL(15, 138, 8), // "tsCircle"
QT_MOC_LITERAL(16, 147, 8) // "tsSquare"

    },
    "QCPItemTracer\0pen\0selectedPen\0brush\0"
    "selectedBrush\0size\0style\0TracerStyle\0"
    "graph\0QCPGraph*\0graphKey\0interpolating\0"
    "tsNone\0tsPlus\0tsCrosshair\0tsCircle\0"
    "tsSquare"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemTracer[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       9,   14, // properties
       1,   41, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, QMetaType::QBrush, 0x00095103,
       4, QMetaType::QBrush, 0x00095103,
       5, QMetaType::Double, 0x00095103,
       6, 0x80000000 | 7, 0x0009510b,
       8, 0x80000000 | 9, 0x0009510b,
      10, QMetaType::Double, 0x00095103,
      11, QMetaType::Bool, 0x00095103,

 // enums: name, flags, count, data
       7, 0x0,    5,   45,

 // enum data: key, value
      12, uint(QCPItemTracer::tsNone),
      13, uint(QCPItemTracer::tsPlus),
      14, uint(QCPItemTracer::tsCrosshair),
      15, uint(QCPItemTracer::tsCircle),
      16, uint(QCPItemTracer::tsSquare),

       0        // eod
};

void QCPItemTracer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPGraph* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QCPItemTracer *_t = static_cast<QCPItemTracer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = _t->selectedPen(); break;
        case 2: *reinterpret_cast< QBrush*>(_v) = _t->brush(); break;
        case 3: *reinterpret_cast< QBrush*>(_v) = _t->selectedBrush(); break;
        case 4: *reinterpret_cast< double*>(_v) = _t->size(); break;
        case 5: *reinterpret_cast< TracerStyle*>(_v) = _t->style(); break;
        case 6: *reinterpret_cast< QCPGraph**>(_v) = _t->graph(); break;
        case 7: *reinterpret_cast< double*>(_v) = _t->graphKey(); break;
        case 8: *reinterpret_cast< bool*>(_v) = _t->interpolating(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPItemTracer *_t = static_cast<QCPItemTracer *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: _t->setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: _t->setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 3: _t->setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 4: _t->setSize(*reinterpret_cast< double*>(_v)); break;
        case 5: _t->setStyle(*reinterpret_cast< TracerStyle*>(_v)); break;
        case 6: _t->setGraph(*reinterpret_cast< QCPGraph**>(_v)); break;
        case 7: _t->setGraphKey(*reinterpret_cast< double*>(_v)); break;
        case 8: _t->setInterpolating(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
}

const QMetaObject QCPItemTracer::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemTracer.data,
      qt_meta_data_QCPItemTracer,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPItemTracer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemTracer::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemTracer.stringdata0))
        return static_cast<void*>(const_cast< QCPItemTracer*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemTracer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 9;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemBracket_t {
    QByteArrayData data[6];
    char stringdata0[57];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemBracket_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemBracket_t qt_meta_stringdata_QCPItemBracket = {
    {
QT_MOC_LITERAL(0, 0, 14), // "QCPItemBracket"
QT_MOC_LITERAL(1, 15, 3), // "pen"
QT_MOC_LITERAL(2, 19, 11), // "selectedPen"
QT_MOC_LITERAL(3, 31, 6), // "length"
QT_MOC_LITERAL(4, 38, 5), // "style"
QT_MOC_LITERAL(5, 44, 12) // "BracketStyle"

    },
    "QCPItemBracket\0pen\0selectedPen\0length\0"
    "style\0BracketStyle"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemBracket[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, QMetaType::Double, 0x00095103,
       4, 0x80000000 | 5, 0x0009510b,

       0        // eod
};

void QCPItemBracket::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        QCPItemBracket *_t = static_cast<QCPItemBracket *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = _t->pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = _t->selectedPen(); break;
        case 2: *reinterpret_cast< double*>(_v) = _t->length(); break;
        case 3: *reinterpret_cast< BracketStyle*>(_v) = _t->style(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QCPItemBracket *_t = static_cast<QCPItemBracket *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: _t->setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: _t->setLength(*reinterpret_cast< double*>(_v)); break;
        case 3: _t->setStyle(*reinterpret_cast< BracketStyle*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemBracket::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemBracket.data,
      qt_meta_data_QCPItemBracket,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *QCPItemBracket::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemBracket::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemBracket.stringdata0))
        return static_cast<void*>(const_cast< QCPItemBracket*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemBracket::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
